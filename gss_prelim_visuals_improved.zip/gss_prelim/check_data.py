"""
Sanity-check script for the GSS 2024 data pipeline.

Runs ingestion and preparation, then prints summary statistics and
validates outcome distributions.

Usage:
    python check_data.py [--config config.yaml]
"""

from __future__ import annotations

import argparse

import pandas as pd
import yaml

from src.gss.ingest import ingest
from src.gss.prep import prepare_canonical


def main(config_path: str = "config.yaml") -> None:
    """Run the data pipeline and print diagnostic summaries.

    Args:
        config_path: Path to the YAML configuration file.
    """
    cfg = yaml.safe_load(open(config_path, "r", encoding="utf-8"))
    stata_path = cfg["data"]["gss_stata"]
    interim_dir = cfg["data"]["interim_dir"]

    # 1) Ingest
    raw_parquet = ingest(stata_path, interim_dir)
    print(f"[ingest] raw parquet → {raw_parquet}")

    # 2) Prepare
    prep = prepare_canonical(raw_parquet, interim_dir)
    print(f"[prep] A1 n={len(prep.a1_df)}, A2 n={len(prep.a2_df)}, A3 n={len(prep.a3_df)}")

    # 3) Per-hypothesis summaries
    outcome_map = {"A1": "y_dwelown", "A2": "y_satfin", "A3": "y_class"}
    for tag, df in [("A1", prep.a1_df), ("A2", prep.a2_df), ("A3", prep.a3_df)]:
        print(f"\n{'='*50}")
        print(f"[{tag}] {len(df)} rows × {len(df.columns)} cols")

        outcome = outcome_map[tag]
        if outcome in df.columns:
            vc = df[outcome].value_counts(dropna=False).sort_index()
            vals = set(df[outcome].dropna().unique())
            if vals.issubset({0, 1}):
                print(f"  [OK] {outcome} is binary (0/1)")
            else:
                print(f"  [WARN] {outcome} unexpected values: {sorted(vals)}")
            print(f"  Distribution: {dict(vc)}")

        # Subgroup bin coverage
        for col in ["age_bin", "income_tert", "educ_bin", "gender_bin", "capability_bin"]:
            if col in df.columns and df[col].notna().any():
                counts = df[col].value_counts(dropna=False)
                print(f"  {col}: {dict(counts)}")

    # 4) Ballot structure
    full = prep.full_df
    if "ballot" in full.columns:
        print(f"\n{'='*50}")
        print("[Ballot distribution]")
        print(full["ballot"].value_counts().sort_index().to_string())

    # 5) Preview
    print(f"\n[preview A1]")
    print(prep.a1_df.head(3).to_string(index=False, max_colwidth=20))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.yaml")
    args = parser.parse_args()
    main(args.config)
