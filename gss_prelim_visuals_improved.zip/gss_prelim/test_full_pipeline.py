"""
Comprehensive end-to-end pipeline test with a mock LLM.

This test replaces the VLLMClient with a mock that generates semi-realistic
predictions based on prompt content. It exercises the entire pipeline:
ingestion → prep → sampling → LLM queries (Type A + Type B + H_mem) →
metrics → stability → trees → consistency → artifacts → report.

The mock LLM parses prompt text to extract demographic signals and produces
predictions correlated with them — simulating an LLM that has learned
real-world associations but with realistic noise and imperfection.
"""

import asyncio
import hashlib
import json
import logging
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from unittest.mock import patch

import numpy as np
import pandas as pd
import yaml

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-8s %(message)s")
logger = logging.getLogger("test")


# ── Mock LLM ─────────────────────────────────────────────────────────────────

@dataclass
class MockLLMResponse:
    p_hat: float | None
    raw_text: str
    valid: bool
    retried: bool


def _prompt_to_p(system_prompt: str, user_prompt: str, temperature: float = 0.7) -> float:
    """Generate a deterministic-ish p_hat from prompt content.

    Parses the user prompt for demographic signals and returns a
    probability that correlates with real-world patterns.
    """
    # Use prompt hash as seed for reproducible noise.
    h = int(hashlib.sha256((system_prompt + user_prompt).encode()).hexdigest()[:8], 16)
    rng = np.random.RandomState(h)

    base = 0.5
    text = user_prompt.lower()

    age_match = re.search(r"age:\s*(\d+) years old", text)
    income_match = re.search(r"income:\s*approximately \$(\d[\d,]*)/year", text)
    educ_match = re.search(r"education:\s*(\d+) years of schooling", text)
    wordsum_match = re.search(r"wordsum\):\s*(\d+) out of 10", text)

    age = int(age_match.group(1)) if age_match else None
    income = int(income_match.group(1).replace(",", "")) if income_match else None
    educ = int(educ_match.group(1)) if educ_match else None
    wordsum = int(wordsum_match.group(1)) if wordsum_match else None

    # Homeownership signals (A1 question)
    if "owns or is buying their home" in text:
        if income is not None and income >= 80000: base += 0.15
        if income is not None and income < 40000: base -= 0.15
        if age is not None and age >= 60: base += 0.10
        if age is not None and age < 40: base -= 0.10
        if educ is not None and educ >= 16: base += 0.08
        if educ is not None and educ < 12: base -= 0.08
        if wordsum is not None and wordsum >= 7: base += 0.05

    # Financial satisfaction signals (A2 question)
    elif "satisfied with their current financial" in text:
        base = 0.25  # Low base rate to match 24% prevalence
        if income is not None and income >= 80000: base += 0.20
        if income is not None and income < 40000: base -= 0.10
        if educ is not None and educ >= 16: base += 0.08
        if "overconfident flag: yes" in text: base += 0.05

    # Subjective class signals (A3 question)
    elif "middle class or upper class" in text:
        if income is not None and income >= 80000: base += 0.20
        if income is not None and income < 40000: base -= 0.15
        if educ is not None and educ >= 16: base += 0.12
        if educ is not None and educ < 12: base -= 0.10
        if "confidence in financial institutions: a great deal" in text: base += 0.05

    # Welfare framing (B1 condition A)
    elif "spending too little on welfare" in text:
        base = 0.35
        if income is not None and income < 40000: base += 0.10
        if educ is not None and educ < 12: base += 0.05

    # Assistance to poor framing (B1 condition B)
    elif "spending too little on assistance to the poor" in text:
        base = 0.65  # ~30pp framing effect
        if income is not None and income < 40000: base += 0.10
        if educ is not None and educ < 12: base += 0.05

    # Recall mode: slightly more anchored to base rates
    if "statistical analyst" in system_prompt.lower():
        base = base * 0.8 + 0.5 * 0.2  # Pull toward 0.5

    # Add noise proportional to temperature.
    noise = rng.normal(0, 0.08 * (temperature / 0.7))
    p = np.clip(base + noise, 0.01, 0.99)
    return round(float(p), 4)


class MockVLLMClient:
    """Drop-in replacement for VLLMClient that generates predictions from prompt content."""

    def __init__(self, **kwargs):
        self._parse_failures = 0
        self._call_count = 0

    @property
    def parse_failure_count(self) -> int:
        return self._parse_failures

    def query(self, system_prompt: str, user_prompt: str) -> MockLLMResponse:
        self._call_count += 1
        p = _prompt_to_p(system_prompt, user_prompt)
        raw = json.dumps({"p": int(p * 100)})
        return MockLLMResponse(p_hat=p, raw_text=raw, valid=True, retried=False)

    async def query_async(self, system_prompt: str, user_prompt: str) -> MockLLMResponse:
        return self.query(system_prompt, user_prompt)

    async def query_batch_async(self, batch: list[dict]) -> list[dict]:
        results = []
        for item in batch:
            resp = self.query(item["system"], item["user"])
            results.append({"key": item["key"], "response": resp})
        return results

    async def query_at_temperature_async(
        self, system_prompt: str, user_prompt: str, temperature: float,
    ) -> MockLLMResponse:
        self._call_count += 1
        p = _prompt_to_p(system_prompt, user_prompt, temperature)
        raw = json.dumps({"p": int(p * 100)})
        return MockLLMResponse(p_hat=p, raw_text=raw, valid=True, retried=False)


# ── Test runner ───────────────────────────────────────────────────────────────

def run_full_test():
    """Execute the full pipeline with mock LLM and validate everything."""

    cfg = yaml.safe_load(open("config_test.yaml", encoding="utf-8"))

    # Clean previous artifacts.
    for d in ["data/interim", "reports", "reports/figures", "logs"]:
        Path(d).mkdir(parents=True, exist_ok=True)
    for f in Path("data/interim").rglob("*"):
        if f.is_file() and f.name != ".gitkeep":
            f.unlink()
    for f in Path("reports").rglob("*"):
        if f.is_file():
            f.unlink()

    # ── 1. Ingestion ──────────────────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 1: INGESTION")
    from src.gss.ingest import ingest
    raw_path = ingest(cfg["data"]["gss_stata"], cfg["data"]["interim_dir"])
    raw_df = pd.read_parquet(raw_path)
    assert raw_df.shape[0] == 3309, f"Expected 3309 rows, got {raw_df.shape[0]}"
    assert "wordsum" in raw_df.columns
    assert "natfare" in raw_df.columns
    assert "natfarey" in raw_df.columns
    logger.info("  Ingestion OK: %d rows, %d cols", *raw_df.shape)

    # ── 2. Preparation ────────────────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 2: PREPARATION")
    from src.gss.prep import prepare_canonical
    prep = prepare_canonical(raw_path, cfg["data"]["interim_dir"])

    for tag, key in [("A1", "a1_df"), ("A2", "a2_df"), ("A3", "a3_df")]:
        df = getattr(prep, key)
        assert len(df) > 0, f"{tag} is empty"
        logger.info("  %s: %d rows, %d cols", tag, len(df), len(df.columns))

    # Validate no NaN in critical columns per hypothesis.
    for col in ["age_bin", "income_tert", "educ_bin", "gender_bin"]:
        for tag, key in [("A1", "a1_df"), ("A2", "a2_df"), ("A3", "a3_df")]:
            n_nan = getattr(prep, key)[col].isna().sum()
            assert n_nan == 0, f"{tag}.{col} has {n_nan} NaNs"

    assert prep.a1_df["wordsum"].notna().all()
    assert prep.a2_df["notsmart"].notna().all()
    assert prep.a3_df["confinan_level"].notna().all()
    logger.info("  Preparation OK")

    # ── 3. Full pipeline with mock LLM ────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 3: FULL PIPELINE (mock LLM)")

    # Patch VLLMClient and PromptCache.
    import src.phase1.run as run_module
    original_vllm = run_module.VLLMClient
    original_cache_cls = run_module.PromptCache

    class NoOpCache:
        """Cache that always misses, forcing all queries through the mock LLM."""
        def __init__(self, **kwargs): pass
        def get(self, s, u): return None
        def set(self, s, u, p, r, retried): pass
        def close(self): pass

    run_module.VLLMClient = MockVLLMClient
    run_module.PromptCache = NoOpCache

    try:
        from src.phase1.run import run_phase1
        results = run_phase1(prep=prep, cfg=cfg)
    finally:
        run_module.VLLMClient = original_vllm
        run_module.PromptCache = original_cache_cls

    logger.info("  Pipeline completed successfully")

    # ── 4. Validate results dict structure ────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 4: VALIDATE RESULTS STRUCTURE")

    required_keys = [
        "year", "active_hypotheses", "active_type_b", "sample_sizes",
        "n_stab", "metrics", "subgroup_metrics", "interaction_metrics",
        "type_b_results", "h_mem_results", "h_mem_benchmarks",
        "stability_metrics", "stability_raw",
        "residual_trees", "implicit_trees", "outcome_trees",
        "cross_error_tree", "consistency", "merged_dfs", "parse_failures",
    ]
    for k in required_keys:
        assert k in results, f"Missing results key: {k}"
    logger.info("  All required keys present")

    assert results["active_hypotheses"] == ["A1", "A2", "A3"]
    assert results["active_type_b"] == ["B1"]
    assert results["parse_failures"] == 0
    logger.info("  Hypotheses: %s, Type B: %s", results["active_hypotheses"], results["active_type_b"])

    # ── 5. Validate Type A metrics ────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 5: TYPE A METRICS")

    for hyp in ["A1", "A2", "A3"]:
        m = results["metrics"][hyp]
        logger.info("  %s: F1=%.3f AUC=%.3f ECE=%.3f TVD=%.3f σ=%.3f n=%d",
                     hyp, m.get("f1", float("nan")), m.get("auc_roc", float("nan")),
                     m.get("ece", float("nan")), m.get("tvd", float("nan")),
                     m.get("sigma_ratio", float("nan")), m.get("n", 0))

        assert m["n"] > 0, f"{hyp} has 0 valid predictions"
        assert 0 <= m.get("ece", 1) <= 1, f"{hyp} ECE out of range"
        assert 0 <= m.get("tvd", 1) <= 1, f"{hyp} TVD out of range"

        # Check CIs exist and bracket point estimates.
        if not m.get("descriptive_only"):
            for metric in ["auc_roc", "ece", "tvd"]:
                lo = m.get(f"{metric}_ci_lo")
                hi = m.get(f"{metric}_ci_hi")
                pt = m.get(metric)
                if lo is not None and hi is not None and pt is not None:
                    assert lo <= pt <= hi, f"{hyp} {metric} CI doesn't bracket: [{lo}, {pt}, {hi}]"

    # Subgroup metrics.
    for hyp in ["A1", "A2", "A3"]:
        sg = results["subgroup_metrics"].get(hyp)
        if sg is not None:
            assert len(sg) > 0, f"{hyp} subgroup metrics empty"
            assert "subgroup_col" in sg.columns
            assert "tvd" in sg.columns
            logger.info("  %s subgroup metrics: %d rows", hyp, len(sg))

    # Interaction metrics.
    for hyp in ["A1", "A2", "A3"]:
        inter = results["interaction_metrics"].get(hyp)
        if inter is not None:
            assert len(inter) > 0, f"{hyp} interaction metrics empty"
            logger.info("  %s interaction metrics: %d rows", hyp, len(inter))

    logger.info("  Type A metrics OK")

    # ── 6. Validate stability ─────────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 6: STABILITY")

    stab = results["stability_metrics"]
    assert "mean_mad" in stab
    assert "p90_mad" in stab
    assert "share_acceptable" in stab
    assert stab["mean_mad"] >= 0
    logger.info("  Mean MAD=%.2f, p90=%.2f, share_acceptable=%.1f%%",
                stab["mean_mad"], stab["p90_mad"], stab["share_acceptable"] * 100)

    stab_raw = results["stability_raw"]
    assert len(stab_raw) > 0
    n_profiles = stab_raw["id"].nunique()
    n_runs = stab_raw["run"].nunique()
    logger.info("  Raw: %d records, %d profiles × %d runs", len(stab_raw), n_profiles, n_runs)
    assert n_runs == cfg["stability"]["n_runs"]
    logger.info("  Stability OK")

    # ── 7. Validate Type B ────────────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 7: TYPE B")

    b1 = results["type_b_results"]["B1"]
    assert "error" not in b1, f"Type B error: {b1.get('error')}"
    assert b1["n_profiles"] > 0
    logger.info("  B1: n=%d, mean_effect=%.1fpp, share_positive=%.1f%%, ratio=%.2f",
                b1["n_profiles"], b1["mean_effect_pp"], b1["share_positive"] * 100,
                b1["effect_ratio"])

    # The mock LLM should produce a positive framing effect (~30pp).
    assert b1["mean_effect_pp"] > 10, f"Expected positive effect, got {b1['mean_effect_pp']}"
    assert b1["share_positive"] > 0.7, f"Expected majority positive, got {b1['share_positive']}"

    # Effect heterogeneity tree.
    etree = b1.get("effect_tree")
    assert etree is not None, "Missing effect heterogeneity tree"
    assert etree.n_leaves > 0
    assert etree.figure_path and os.path.exists(etree.figure_path)
    logger.info("  Effect tree: %d leaves, worst=%.1fpp", etree.n_leaves, etree.worst_leaf_mean)
    logger.info("  Type B OK")

    # ── 8. Validate H_mem ─────────────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 8: H_MEM")

    hm = results["h_mem_results"]
    assert hm["n_profiles"] > 0
    logger.info("  n=%d, div_low=%.4f, div_high=%.4f, ratio=%.2f",
                hm["n_profiles"], hm["prompt_divergence_low"],
                hm["prompt_divergence_high"], hm["prompt_divergence_ratio"])
    logger.info("  mode_corr=%.3f, σ_sim=%.3f, σ_rec=%.3f",
                hm["mode_correlation"], hm["sigma_ratio_sim"], hm["sigma_ratio_rec"])
    logger.info("  Recall→Coarse=%.4f, Sim→Full=%.4f",
                hm["recall_to_coarse"], hm["sim_to_full"])

    bench = results["h_mem_benchmarks"]
    logger.info("  XGB: coarse_AUC=%.3f, full_AUC=%.3f",
                bench["coarse_auc"], bench["full_auc"])
    assert bench["full_auc"] > 0.5

    # Alignment table.
    align = hm["alignment_by_conflict"]
    assert isinstance(align, pd.DataFrame)
    assert len(align) == 2  # low and high
    logger.info("  Alignment table: %d rows", len(align))

    # Accuracy table.
    acc = hm["accuracy_results"]
    assert len(acc) == 4  # sim, recall, coarse_xgb, full_xgb
    for _, row in acc.iterrows():
        assert 0 <= row["brier_score"] <= 1
    logger.info("  Accuracy table: %d rows, all Brier in [0,1]", len(acc))
    logger.info("  H_mem OK")

    # ── 9. Validate trees ─────────────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 9: TREES")

    for hyp in ["A1", "A2", "A3"]:
        for tree_type, tree_dict in [("residual", results["residual_trees"]),
                                      ("implicit", results["implicit_trees"]),
                                      ("outcome", results["outcome_trees"])]:
            t = tree_dict.get(hyp)
            assert t is not None, f"Missing {tree_type} tree for {hyp}"
            assert t.n_leaves > 0
            assert t.leaf_summary is not None and len(t.leaf_summary) > 0
            assert t.feature_importance is not None and len(t.feature_importance) > 0
            assert os.path.exists(t.figure_path), f"Missing figure: {t.figure_path}"
        logger.info("  %s: 3 trees OK (residual, implicit, outcome)", hyp)

    ct = results["cross_error_tree"]
    assert ct is not None, "Missing cross-error tree"
    assert ct.n_samples > 0
    assert os.path.exists(ct.figure_path)
    logger.info("  Cross-error tree: %d leaves, n=%d", ct.n_leaves, ct.n_samples)
    logger.info("  Trees OK (total: %d trees)", 3 * 3 + 1 + 1)  # 9 Type A + cross + effect

    # ── 10. Validate consistency ──────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 10: CONSISTENCY")

    cons = results["consistency"]
    assert len(cons["pairs"]) == 2  # A1-A2 and A1-A3
    for pair in cons["pairs"]:
        assert pair["n_shared"] > 0
        assert "frobenius_dist" in pair
        logger.info("  %s: n=%d, Frobenius=%.4f", pair["pair"], pair["n_shared"],
                     pair["frobenius_dist"])
    logger.info("  Consistency OK")

    # ── 11. Generate report ───────────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 11: REPORT GENERATION")

    from src.reporting.report_md import generate_report
    report_path = generate_report(results, cfg["output"]["reports_dir"])
    assert os.path.exists(report_path)
    report_text = open(report_path, encoding="utf-8").read()
    logger.info("  Report: %d chars", len(report_text))

    required_sections = [
        "H_stability", "Type A Metrics", "Pre-specified Interaction",
        "Type B", "Welfare Framing", "Effect heterogeneity tree",
        "H_mem", "Simulation vs Memorization", "XGBoost Benchmarks",
        "Prompt Divergence", "Alignment with Benchmark",
        "Decision Tree", "Cross-Hypothesis", "What We Learn",
        "Audit Trail",
    ]
    for section in required_sections:
        assert section in report_text, f"Missing report section: '{section}'"
        logger.info("  ✓ %s", section)

    # ── 12. Validate artifacts ────────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 12: ARTIFACTS")

    art_dir = Path(cfg["data"]["interim_dir"]) / "artifacts_2024"
    assert art_dir.is_dir()
    art_files = sorted(f.name for f in art_dir.iterdir() if f.is_file())
    logger.info("  Artifact directory: %d files", len(art_files))

    # Check critical artifacts exist and are non-empty.
    critical_artifacts = {
        "metrics.json": "json",
        "stability_metrics.json": "json",
        "consistency_summary.json": "json",
        "h_mem_summary.json": "json",
        "type_b_B1_summary.json": "json",
        "h_mem_benchmarks.parquet": "parquet",
        "h_mem_alignment_by_conflict.parquet": "parquet",
        "h_mem_accuracy_results.parquet": "parquet",
        "tree_residual_A1.pkl": "pickle",
        "tree_residual_A2.pkl": "pickle",
        "tree_residual_A3.pkl": "pickle",
        "tree_implicit_A1.pkl": "pickle",
        "tree_outcome_A1.pkl": "pickle",
        "tree_cross_error.pkl": "pickle",
        "tree_effect_heterogeneity_B1.pkl": "pickle",
        "merged_A1.parquet": "parquet",
        "merged_A2.parquet": "parquet",
        "merged_A3.parquet": "parquet",
        "subgroup_metrics_A1.parquet": "parquet",
    }
    for fname, ftype in critical_artifacts.items():
        fpath = art_dir / fname
        assert fpath.exists(), f"Missing artifact: {fname}"
        assert fpath.stat().st_size > 0, f"Empty artifact: {fname}"
        if ftype == "json":
            data = json.loads(fpath.read_text(encoding="utf-8"))
            assert isinstance(data, dict), f"Bad JSON in {fname}"
        elif ftype == "parquet":
            df = pd.read_parquet(fpath)
            assert len(df) > 0, f"Empty parquet: {fname}"
    logger.info("  All %d critical artifacts validated", len(critical_artifacts))

    # Inspect metrics.json content.
    metrics_json = json.loads((art_dir / "metrics.json").read_text())
    for hyp in ["A1", "A2", "A3"]:
        assert hyp in metrics_json, f"Missing {hyp} in metrics.json"
        assert "f1" in metrics_json[hyp]
    logger.info("  metrics.json: 3 hypotheses present with full metric suites")

    # Inspect h_mem_summary.json.
    hm_json = json.loads((art_dir / "h_mem_summary.json").read_text())
    assert "prompt_divergence_ratio" in hm_json
    assert "mode_correlation" in hm_json
    logger.info("  h_mem_summary.json: valid")

    # ── 13. Validate figures ──────────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 13: FIGURES")

    fig_dir = Path(cfg["output"]["figures_dir"])
    fig_files = sorted(f.name for f in fig_dir.iterdir() if f.is_file())
    logger.info("  Figures directory: %d files", len(fig_files))

    expected_figures = {
        "calibration_A1.png", "calibration_A2.png", "calibration_A3.png",
        "tree_residual_A1.png", "tree_residual_A2.png", "tree_residual_A3.png",
        "tree_implicit_A1.png", "tree_implicit_A2.png", "tree_implicit_A3.png",
        "tree_outcome_A1.png", "tree_outcome_A2.png", "tree_outcome_A3.png",
        "tree_cross_hypothesis_error.png",
        "tree_effect_heterogeneity_B1.png",
        "tvd_heatmap_A1.png", "tvd_heatmap_A2.png", "tvd_heatmap_A3.png",
    }
    for fig in expected_figures:
        fpath = fig_dir / fig
        assert fpath.exists(), f"Missing figure: {fig}"
        assert fpath.stat().st_size > 1000, f"Suspiciously small figure: {fig} ({fpath.stat().st_size}b)"
    logger.info("  All %d expected figures present and non-trivial", len(expected_figures))

    # ── 14. Validate audit trail ──────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 14: AUDIT TRAIL")

    audit_path = Path(cfg["data"]["interim_dir"]) / "prompt_audit_trail.parquet"
    assert audit_path.exists(), "Missing audit trail"
    audit_df = pd.read_parquet(audit_path)
    logger.info("  Audit trail: %d records, %d columns", len(audit_df), len(audit_df.columns))

    required_audit_cols = ["id", "hypothesis", "p_hat", "raw_text", "valid",
                           "retried", "system_prompt", "user_prompt"]
    for col in required_audit_cols:
        assert col in audit_df.columns, f"Missing audit column: {col}"

    # Check all hypotheses are present.
    hyps_in_audit = set(audit_df["hypothesis"].unique())
    assert "A1" in hyps_in_audit
    assert "A2" in hyps_in_audit
    assert "A3" in hyps_in_audit
    assert "B1" in hyps_in_audit
    assert "H_mem_recall" in hyps_in_audit or "A1" in hyps_in_audit
    logger.info("  Hypotheses in audit: %s", sorted(hyps_in_audit))

    # Verify prompts are non-empty strings.
    assert (audit_df["system_prompt"].str.len() > 50).all(), "Some system prompts too short"
    assert (audit_df["user_prompt"].str.len() > 50).all(), "Some user prompts too short"

    # Verify B1 has both conditions.
    b1_audit = audit_df[audit_df["hypothesis"] == "B1"]
    if "condition" in b1_audit.columns:
        conditions = set(b1_audit["condition"].unique())
        assert "condition_a" in conditions and "condition_b" in conditions
        logger.info("  B1 audit: both conditions present")

    # Verify recall prompts differ from simulation prompts.
    sim_prompts = set(audit_df[audit_df["hypothesis"] == "A1"]["system_prompt"].unique())
    recall_entries = audit_df[audit_df["hypothesis"] == "H_mem_recall"]
    if len(recall_entries) > 0:
        recall_prompts = set(recall_entries["system_prompt"].unique())
        assert sim_prompts != recall_prompts, "Recall and simulation prompts should differ"
        logger.info("  H_mem recall prompts differ from simulation: ✓")

    # Count total queries.
    n_a1 = len(audit_df[audit_df["hypothesis"] == "A1"])
    n_a2 = len(audit_df[audit_df["hypothesis"] == "A2"])
    n_a3 = len(audit_df[audit_df["hypothesis"] == "A3"])
    n_b1 = len(audit_df[audit_df["hypothesis"] == "B1"])
    n_recall = len(audit_df[audit_df["hypothesis"] == "H_mem_recall"])
    logger.info("  Query counts: A1=%d, A2=%d, A3=%d, B1=%d, H_mem_recall=%d",
                n_a1, n_a2, n_a3, n_b1, n_recall)
    assert n_b1 > n_a1, "B1 should have ~2x queries (two conditions per profile)"
    logger.info("  Audit trail OK")

    # ── 15. Inspect merged DataFrames ─────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 15: MERGED DATAFRAMES")

    for hyp in ["A1", "A2", "A3"]:
        merged = results["merged_dfs"][hyp]
        p_col = f"p_hat_{hyp}"
        r_col = f"residual_{hyp}"
        assert p_col in merged.columns, f"Missing {p_col} in merged {hyp}"
        assert r_col in merged.columns, f"Missing {r_col} in merged {hyp}"

        p_vals = merged[p_col].dropna()
        assert (p_vals >= 0).all() and (p_vals <= 1).all(), f"{hyp} p_hat out of [0,1]"
        assert len(p_vals) > 0.9 * len(merged), f"{hyp} too many NaN p_hats"

        r_vals = merged[r_col].dropna()
        assert (r_vals >= -1).all() and (r_vals <= 1).all(), f"{hyp} residuals out of [-1,1]"

        logger.info("  %s merged: %d rows, p_hat valid=%d, mean_p=%.3f, mean_r=%.3f",
                     hyp, len(merged), len(p_vals), p_vals.mean(), r_vals.mean())
    logger.info("  Merged DataFrames OK")

    # ── 16. Cross-validate predictions vs outcomes ────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 16: PREDICTION QUALITY SPOT-CHECK")

    for hyp, y_col in [("A1", "y_dwelown"), ("A2", "y_satfin"), ("A3", "y_class")]:
        merged = results["merged_dfs"][hyp]
        p_col = f"p_hat_{hyp}"
        valid = merged[[y_col, p_col]].dropna()
        y = valid[y_col].values
        p = valid[p_col].values

        # Mock LLM should produce predictions correlated with outcome (not random).
        from scipy.stats import pointbiserialr
        corr, pval = pointbiserialr(y, p)
        logger.info("  %s: point-biserial r=%.3f (p=%.2e)", hyp, corr, pval)
        assert corr > 0.1, f"{hyp} predictions not correlated with outcomes (r={corr:.3f})"

    logger.info("  Prediction quality OK — mock LLM shows expected signal")

    # ══════════════════════════════════════════════════════════════════════════
    logger.info("=" * 60)
    logger.info("=" * 60)
    logger.info("  ALL 16 TEST STEPS PASSED")
    logger.info("=" * 60)
    logger.info("")
    logger.info("  Summary:")
    logger.info("    Artifacts: %d files in artifacts_2024/", len(art_files))
    logger.info("    Figures:   %d PNG files", len(fig_files))
    logger.info("    Report:    %d chars", len(report_text))
    logger.info("    Audit:     %d prediction records", len(audit_df))
    logger.info("    Total LLM queries simulated: %d",
                n_a1 + n_a2 + n_a3 + n_b1 + n_recall +
                cfg["sampling"]["n_stab"] * cfg["stability"]["n_runs"])
    logger.info("")


if __name__ == "__main__":
    run_full_test()
