import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

from src.gss.prep import prepare_canonical
from src.llm.prompts import render_user_prompt
from src.phase1.h_mem import _encode_for_xgb
from src.phase1.trees import _encode_categoricals


class EncodingConsistencyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        stata_path = Path('/mnt/data/GSS2024.dta')
        if not stata_path.exists():
            raise unittest.SkipTest('GSS2024.dta not available')
        raw_df = pd.read_stata(stata_path, convert_categoricals=False)
        raw_df.columns = raw_df.columns.str.lower()
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch('src.gss.prep.pd.read_parquet', return_value=raw_df.copy()):
                with patch('pandas.DataFrame.to_parquet', return_value=None):
                    prep = prepare_canonical('dummy.parquet', tmpdir)
        cls.prep = prep

        cls.raw_cat = pd.read_stata(stata_path, convert_categoricals=True)
        cls.raw_cat.columns = cls.raw_cat.columns.str.lower()
        cls.raw_num = raw_df

    def test_prompt_label_mappings_match_dataset_value_labels(self):
        pairs = [
            ('region', {1: 'Northeast', 2: 'Midwest', 3: 'South', 4: 'West'}),
            ('partyid', {
                0: 'Strong Democrat', 1: 'Not very strong Democrat',
                2: 'Independent, close to Democrat',
                3: 'Independent (neither, no response)',
                4: 'Independent, close to Republican',
                5: 'Not very strong Republican', 6: 'Strong Republican',
                7: 'Other party',
            }),
            ('relig', {
                1: 'Protestant', 2: 'Catholic', 3: 'Jewish', 4: 'No religion',
                5: 'Other', 6: 'Buddhism', 7: 'Hinduism',
                8: 'Other Eastern religions', 9: 'Muslim/Islam',
                10: 'Orthodox-Christian', 11: 'Christian',
                12: 'Native American', 13: 'Inter-nondenominational',
            }),
            ('notsmart', {
                1: 'almost every day', 2: 'at least once a week', 3: 'a few times a month',
                4: 'a few times a year', 5: 'less than once a year', 6: 'never',
            }),
        ]
        for col, expected in pairs:
            observed = (
                pd.DataFrame({'code': self.raw_num[col], 'label': self.raw_cat[col].astype(str)})
                .dropna()
                .drop_duplicates()
                .sort_values('code')
            )
            observed_map = {int(row.code): row.label for row in observed.itertuples()}
            normalized_observed = {k: v.lower().replace('none', 'no religion') for k, v in observed_map.items()}
            normalized_expected = {k: v.lower() for k, v in expected.items()}
            self.assertEqual(normalized_expected, normalized_observed, col)

    def test_prompt_text_uses_human_readable_labels_for_dataset_codes(self):
        row = self.prep.a2_df.iloc[0].copy()
        prompt = render_user_prompt(row, 'A2')
        self.assertIn('Religion:', prompt)
        self.assertNotRegex(prompt, r'Religion: code \d+')
        self.assertNotIn('New England', prompt)
        self.assertRegex(prompt, r'Region: (Northeast|Midwest|South|West)')
        self.assertIn("Feels 'not smart enough for financial matters':", prompt)
        self.assertNotIn('several times a week', prompt)
        self.assertNotIn('once or twice a month', prompt)

    def test_tree_and_xgb_encoders_are_columnwise_consistent(self):
        cols = ['gender_bin', 'race', 'marital', 'wrkstat', 'region', 'relig', 'partyid', 'polviews']
        df = self.prep.a1_df[cols].head(200).copy()
        X_tree, names = _encode_categoricals(df, cols)
        X_xgb = _encode_for_xgb(df, cols)
        self.assertEqual(names, cols)
        self.assertEqual(list(X_xgb.columns), cols)
        np.testing.assert_allclose(X_tree, X_xgb.to_numpy(dtype=float), equal_nan=True)


if __name__ == '__main__':
    unittest.main()
