import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

from src.gss.prep import prepare_canonical
from src.llm.prompts import get_prompt_feature_cols, render_user_prompt
from src.phase1.h_mem import train_benchmark_models


class FeatureAlignmentTests(unittest.TestCase):
    def test_prompt_feature_registry_uses_aligned_raw_features(self):
        expected = {
            "A1": [
                "age", "gender_bin", "educ_years", "income", "wordsum",
                "race", "marital", "wrkstat", "region", "relig", "partyid", "polviews",
            ],
            "A2": [
                "age", "gender_bin", "educ_years", "income", "wordsum", "notsmart",
                "overconfident_flag",
                "race", "marital", "wrkstat", "region", "relig", "partyid", "polviews",
            ],
            "A3": [
                "age", "gender_bin", "educ_years", "income", "confinan",
                "race", "marital", "wrkstat", "region", "relig", "partyid", "polviews",
            ],
            "B1": [
                "age", "gender_bin", "educ_years", "income", "wordsum",
                "race", "marital", "wrkstat", "region", "relig", "partyid", "polviews",
            ],
        }
        dropped_derived = {
            "age_bin", "educ_bin", "income_tert", "capability_bin",
            "confidence_level", "confinan_level",
        }

        for hyp, cols in expected.items():
            actual = get_prompt_feature_cols(hyp)
            self.assertEqual(actual, cols)
            self.assertTrue(dropped_derived.isdisjoint(actual))

    def test_prompts_render_newly_aligned_full_features(self):
        row = pd.Series({
            "age": 44,
            "gender_bin": "female",
            "educ_years": 16,
            "income": 83000,
            "wordsum": 8,
            "notsmart": 5,
            "overconfident_flag": 1,
            "confinan": 1,
            "race": 2,
            "marital": 1,
            "wrkstat": 1,
            "region": 9,
            "relig": 4,
            "partyid": 0,
            "polviews": 2,
        })

        prompt_a2 = render_user_prompt(row, "A2")
        self.assertIn("Age: 44 years old", prompt_a2)
        self.assertIn("Income: approximately $83,000/year", prompt_a2)
        self.assertIn("Race: Black (code 2)", prompt_a2)
        self.assertIn("Marital status: Married (code 1)", prompt_a2)
        self.assertIn("Work status: Working full time (code 1)", prompt_a2)
        self.assertIn("Party identification: Strong Democrat (code 0)", prompt_a2)
        self.assertIn("Political views: Liberal (code 2)", prompt_a2)
        self.assertIn("Overconfident flag: yes", prompt_a2)
        self.assertNotIn("between 40 and 59", prompt_a2)
        self.assertNotIn("below-average income", prompt_a2)
        self.assertNotIn("financial self-confidence", prompt_a2)

        prompt_a3 = render_user_prompt(row, "A3")
        self.assertIn("Confidence in financial institutions: A great deal (code 1)", prompt_a3)
        self.assertNotIn("moderate", prompt_a3)

    def test_prepare_canonical_preserves_raw_confinan_for_a3(self):
        df = pd.DataFrame({
            "id": [1, 2, 3],
            "ballot": [2, 2, 3],
            "age": [35, 52, 67],
            "sex": [1, 2, 1],
            "educ": [12, 16, 14],
            "degree": [1, 3, 2],
            "realinc": [40000, 90000, 55000],
            "confinan": [1, 2, 3],
            "class": [3, 4, 2],
        })
        with tempfile.TemporaryDirectory() as tmpdir:
            raw_path = Path(tmpdir) / "raw.parquet"
            interim_dir = Path(tmpdir) / "interim"
            interim_dir.mkdir()
            with patch("src.gss.prep.pd.read_parquet", return_value=df.copy()):
                with patch("pandas.DataFrame.to_parquet", return_value=None):
                    prep = prepare_canonical(str(raw_path), str(interim_dir))

        self.assertIn("confinan", prep.a3_df.columns)
        self.assertTrue(prep.a3_df["confinan"].notna().all())
        self.assertEqual(prep.a3_df["confinan"].tolist(), [1, 2, 3])

    def test_h_mem_full_xgb_uses_same_aligned_feature_set(self):
        df = pd.DataFrame({
            "id": list(range(10)),
            "y_dwelown": [0, 1] * 5,
            "age": np.linspace(30, 60, 10),
            "gender_bin": ["male", "female"] * 5,
            "educ_years": [12, 16] * 5,
            "income": np.linspace(30000, 90000, 10),
            "wordsum": [4, 8] * 5,
            "race": [1, 2] * 5,
            "marital": [1, 5] * 5,
            "wrkstat": [1, 4] * 5,
            "region": [1, 9] * 5,
            "relig": [1, 4] * 5,
            "partyid": [0, 6] * 5,
            "polviews": [2, 6] * 5,
            "age_bin": ["<40", "40-59"] * 5,
            "educ_bin": ["mid", "university"] * 5,
            "income_tert": ["low", "high"] * 5,
        })

        def fake_cross_val_predict(model, X, y, cv, method):
            probs = np.linspace(0.2, 0.8, len(X))
            return np.column_stack([1 - probs, probs])

        with patch("src.phase1.h_mem.cross_val_predict", side_effect=fake_cross_val_predict):
            benchmarks = train_benchmark_models(df, "y_dwelown", hypothesis="A1", random_seed=0)

        self.assertEqual(benchmarks["coarse_features_used"], ["age_bin", "gender_bin", "educ_bin", "income_tert"])
        self.assertEqual(benchmarks["full_features_used"], get_prompt_feature_cols("A1"))
        self.assertNotIn("income_tert", benchmarks["full_features_used"])
        self.assertNotIn("age_bin", benchmarks["full_features_used"])


if __name__ == "__main__":
    unittest.main()
