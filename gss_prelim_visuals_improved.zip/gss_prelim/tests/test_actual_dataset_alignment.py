import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

from src.gss.prep import prepare_canonical
from src.llm.prompts import get_prompt_feature_cols, render_user_prompt
from src.phase1.h_mem import train_benchmark_models
from src.phase1.trees import fit_outcome_tree


class ActualDatasetAlignmentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        candidate_paths = [
            Path("/mnt/data/GSS2024.dta"),
            Path("data/raw/GSS2024.dta"),
        ]
        stata_path = next((p for p in candidate_paths if p.exists()), None)
        if stata_path is None:
            raise unittest.SkipTest("GSS2024.dta not available")

        raw_df = pd.read_stata(stata_path, convert_categoricals=False)
        raw_df.columns = raw_df.columns.str.lower()

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("src.gss.prep.pd.read_parquet", return_value=raw_df.copy()):
                with patch("pandas.DataFrame.to_parquet", return_value=None):
                    prep = prepare_canonical("dummy.parquet", tmpdir)

        cls.prep = prep

    def test_a_hypothesis_frames_have_aligned_feature_columns(self):
        expected_frames = {
            "A1": self.prep.a1_df,
            "A2": self.prep.a2_df,
            "A3": self.prep.a3_df,
        }
        for hyp, frame in expected_frames.items():
            cols = get_prompt_feature_cols(hyp)
            self.assertTrue(all(col in frame.columns for col in cols), hyp)
            self.assertTrue(frame[cols].notna().all(axis=1).all(), hyp)

    def test_real_prompts_expose_aligned_raw_features_not_binned_features(self):
        a1_prompt = render_user_prompt(self.prep.a1_df.iloc[0], "A1")
        self.assertIn("Age:", a1_prompt)
        self.assertIn("Income:", a1_prompt)
        self.assertIn("Race:", a1_prompt)
        self.assertIn("Marital status:", a1_prompt)
        self.assertNotIn("between 40 and 59", a1_prompt)
        self.assertNotIn("below-average", a1_prompt)
        self.assertNotIn("capability", a1_prompt.lower())

        a2_prompt = render_user_prompt(self.prep.a2_df.iloc[0], "A2")
        self.assertIn("Feels 'not smart enough for financial matters'", a2_prompt)
        self.assertIn("Overconfident flag:", a2_prompt)
        self.assertNotIn("confidence_level", a2_prompt)

        a3_prompt = render_user_prompt(self.prep.a3_df.iloc[0], "A3")
        self.assertIn("Confidence in financial institutions:", a3_prompt)
        self.assertNotIn("confinan_level", a3_prompt)

    def test_outcome_trees_use_the_same_feature_set_as_the_prompt_registry(self):
        cfg = {"max_depth": 3, "min_samples_leaf": 20, "cv_folds": 3}
        hyp_to_frame = {
            "A1": (self.prep.a1_df.head(300).copy(), "y_dwelown"),
            "A2": (self.prep.a2_df.head(300).copy(), "y_satfin"),
            "A3": (self.prep.a3_df.head(300).copy(), "y_class"),
        }
        with tempfile.TemporaryDirectory() as tmpdir:
            for hyp, (frame, outcome_col) in hyp_to_frame.items():
                feature_cols = get_prompt_feature_cols(hyp)
                tree = fit_outcome_tree(frame, outcome_col, feature_cols, hyp, cfg, tmpdir)
                self.assertEqual(set(tree.feature_importance.index), set(feature_cols), hyp)
                self.assertTrue(set(tree.feature_importance.index).issubset(set(frame.columns)), hyp)

    def test_full_xgboost_uses_same_aligned_feature_registry_on_real_data(self):
        df = self.prep.a1_df.head(200).copy()

        def fake_cross_val_predict(model, X, y, cv, method):
            probs = np.linspace(0.15, 0.85, len(X))
            return np.column_stack([1 - probs, probs])

        with patch("src.phase1.h_mem.cross_val_predict", side_effect=fake_cross_val_predict):
            benchmarks = train_benchmark_models(df, "y_dwelown", hypothesis="A1", random_seed=0)

        self.assertEqual(benchmarks["coarse_features_used"], ["age_bin", "gender_bin", "educ_bin", "income_tert"])
        self.assertEqual(benchmarks["full_features_used"], get_prompt_feature_cols("A1"))
        self.assertIn("income", benchmarks["full_features_used"])
        self.assertNotIn("income_tert", benchmarks["full_features_used"])
        self.assertNotIn("age_bin", benchmarks["full_features_used"])


if __name__ == "__main__":
    unittest.main()
