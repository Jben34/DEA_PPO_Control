"""
Entry point for the GSS 2024 Phase 1 preliminary analysis.

Usage:
    python main.py [--config config.yaml]

Pipeline:
    1. Ingestion (read .dta, write column-pruned parquet)
    2. Data preparation (recodes, derived constructs, ballot-specific parquets)
    3. Phase 1 analysis (LLM queries, metrics + CIs, stability, trees, consistency)
    4. Report generation (markdown + figures)
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import yaml

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)


def load_config(config_path: str) -> dict:
    """Load and return the YAML configuration file."""
    with open(config_path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def main(config_path: str) -> None:
    """Run the full GSS 2024 preliminary analysis pipeline.

    Args:
        config_path: Path to the YAML configuration file.
    """
    cfg = load_config(config_path)

    log_dir = cfg["output"]["logs_dir"]
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    file_handler = logging.FileHandler(f"{log_dir}/run.log", encoding="utf-8")
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
    )
    logging.getLogger().addHandler(file_handler)

    from src.gss.ingest import ingest
    from src.gss.prep import prepare_canonical
    from src.phase1.run import run_phase1
    from src.reporting.report_md import generate_report

    stata_path = cfg["data"]["gss_stata"]
    interim_dir = cfg["data"]["interim_dir"]
    reports_dir = cfg["output"]["reports_dir"]

    # ── 1. Ingestion ────────────────────────────────────────────────────────
    logger.info("=== Step 1: Ingestion ===")
    raw_parquet = ingest(stata_path=stata_path, interim_dir=interim_dir)

    # ── 2. Data preparation ─────────────────────────────────────────────────
    logger.info("=== Step 2: Data preparation ===")
    prep = prepare_canonical(parquet_path=raw_parquet, interim_dir=interim_dir)

    # ── 3. Phase 1 analysis ─────────────────────────────────────────────────
    logger.info("=== Step 3: Phase 1 analysis ===")
    results = run_phase1(prep=prep, cfg=cfg)

    # ── 4. Report generation ────────────────────────────────────────────────
    logger.info("=== Step 4: Report generation ===")
    report_path = generate_report(results=results, reports_dir=reports_dir)
    logger.info("Analysis complete. Report → %s", report_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="GSS 2024 Phase 1 Preliminary LLM Stress Test")
    parser.add_argument(
        "--config", default="config.yaml",
        help="Path to the YAML configuration file (default: config.yaml).",
    )
    args = parser.parse_args()
    main(args.config)
