"""
vLLM client for the GSS preliminary analysis.

Uses vLLM offline inference (in-process engine) instead of the OpenAI-compatible
HTTP server. Preserves the same public interface as the previous client:
single-query sync/async methods, batch async method, one-retry policy on parse
failures, and invalid-response logging.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from vllm import LLM, SamplingParams

logger = logging.getLogger(__name__)


@dataclass
class LLMResponse:
    """Parsed result of a single LLM query."""

    p_hat: float | None     # Predicted probability in [0, 1]; None if parsing failed.
    raw_text: str           # Raw text from the model (for logging).
    valid: bool             # False if both parse attempts failed.
    retried: bool           # True if the retry attempt was triggered.


class VLLMClient:
    """
    Client for in-process vLLM offline inference.

    Public interface is kept compatible with the previous HTTP-backed client so
    the rest of the pipeline does not need to change.

    Notes:
    - The "async" methods are compatibility shims. vLLM offline inference is
      synchronous from the caller's perspective, so these methods simply call
      into the same underlying batch generator.
    - Batching is now real batching via vLLM's offline engine, not asyncio fan-out.
    """

    def __init__(
        self,
        model: str,
        temperature_main: float,
        temperature_retry: float,
        max_tokens: int,
        log_dir: str,
        tensor_parallel_size: int = 1,
        gpu_memory_utilization: float = 0.9,
        max_model_len: int | None = None,
        trust_remote_code: bool = False,
        enforce_eager: bool = False,
        dtype: str = "auto",
        disable_thinking: bool = False,
        max_concurrent: int = 64,  # kept for backward compatibility; unused
    ) -> None:
        """
        Args:
            model: Model name/path understood by vLLM.
            temperature_main: Sampling temperature for primary queries.
            temperature_retry: Temperature for parse-failure retry (should be 0.0).
            max_tokens: Maximum tokens in the completion.
            log_dir: Directory for raw-response failure logs.
            tensor_parallel_size: Number of GPUs for tensor parallelism.
            gpu_memory_utilization: Fraction of GPU memory vLLM may use.
            max_model_len: Optional model context length cap.
            trust_remote_code: Forwarded to vLLM.
            enforce_eager: Forwarded to vLLM; sometimes improves stability.
            dtype: Forwarded to vLLM (e.g. "auto", "float16", "bfloat16").
            disable_thinking: If True, pass Qwen-style chat_template_kwargs with
                enable_thinking=False. Harmlessly ignored by models/templates
                that do not use it.
            max_concurrent: Kept only so existing constructor call sites do not
                break. Unused in offline mode.
        """
        self._model = model
        self._temp_main = temperature_main
        self._temp_retry = temperature_retry
        self._max_tokens = max_tokens
        self._disable_thinking = disable_thinking

        Path(log_dir).mkdir(parents=True, exist_ok=True)
        self._log_dir = Path(log_dir)
        self._parse_failures = 0

        llm_kwargs: dict[str, Any] = {
            "model": model,
            "tensor_parallel_size": tensor_parallel_size,
            "gpu_memory_utilization": gpu_memory_utilization,
            "trust_remote_code": trust_remote_code,
            "enforce_eager": enforce_eager,
            "dtype": dtype,
        }
        if max_model_len is not None:
            llm_kwargs["max_model_len"] = max_model_len

        logger.info(
            "Initializing offline vLLM engine: model=%s, tp=%d, gpu_mem_util=%.2f, "
            "max_model_len=%s, enforce_eager=%s, disable_thinking=%s",
            model,
            tensor_parallel_size,
            gpu_memory_utilization,
            str(max_model_len),
            enforce_eager,
            disable_thinking,
        )
        self._llm = LLM(**llm_kwargs)

    @property
    def parse_failure_count(self) -> int:
        """Total number of prompts that failed both parse attempts."""
        return self._parse_failures

    # ── Synchronous interface ─────────────────────────────────────────────────

    def query(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """
        Send a single stateless query and parse the JSON response.

        Retry policy: on first parse failure, retry once at temperature=0.0
        with a schema reminder appended. On second failure, log and return
        valid=False.
        """
        raw = self._generate_one(system_prompt, user_prompt, self._temp_main)
        p_hat = _parse_p(raw)
        if p_hat is not None:
            return LLMResponse(p_hat=p_hat, raw_text=raw, valid=True, retried=False)

        retry_prompt = (
            user_prompt
            + '\n\nReturn ONLY valid JSON matching exactly this schema: {"p": <integer 0-100>}'
        )
        raw_retry = self._generate_one(system_prompt, retry_prompt, self._temp_retry)
        p_hat_retry = _parse_p(raw_retry)
        if p_hat_retry is not None:
            return LLMResponse(
                p_hat=p_hat_retry, raw_text=raw_retry, valid=True, retried=True
            )

        self._parse_failures += 1
        self._log_failure(raw, raw_retry)
        return LLMResponse(p_hat=None, raw_text=raw, valid=False, retried=True)

    def query_at_temperature(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float,
    ) -> LLMResponse:
        """
        Query at an explicit temperature without the retry policy.

        Used by the stability probe; must not silently fall back to deterministic
        outputs.
        """
        raw = self._generate_one(system_prompt, user_prompt, temperature)
        p_hat = _parse_p(raw)
        if p_hat is not None:
            return LLMResponse(p_hat=p_hat, raw_text=raw, valid=True, retried=False)
        self._parse_failures += 1
        self._log_failure(raw, "")
        return LLMResponse(p_hat=None, raw_text=raw, valid=False, retried=False)

    # ── Async compatibility interface ────────────────────────────────────────

    async def query_async(
        self, system_prompt: str, user_prompt: str
    ) -> LLMResponse:
        """
        Async compatibility shim for a single query with retry policy.
        """
        return self.query(system_prompt, user_prompt)

    async def query_batch_async(
        self,
        requests: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """
        Generate a batch of chat requests and collect results in input order.

        Each request dict must contain "system", "user", and "key".
        Return format is preserved:
            [{"key": ..., "response": LLMResponse}, ...]
        """
        if not requests:
            return []

        # First-pass batch
        conversations = [
            [
                {"role": "system", "content": req["system"]},
                {"role": "user", "content": req["user"]},
            ]
            for req in requests
        ]
        first_raw = self._generate_batch(conversations, self._temp_main)

        first_pass: list[LLMResponse | None] = []
        retry_indices: list[int] = []

        for i, raw in enumerate(first_raw):
            p_hat = _parse_p(raw)
            if p_hat is not None:
                first_pass.append(
                    LLMResponse(p_hat=p_hat, raw_text=raw, valid=True, retried=False)
                )
            else:
                first_pass.append(None)
                retry_indices.append(i)

        # Retry only failed parses
        retry_results: dict[int, LLMResponse] = {}
        if retry_indices:
            retry_conversations = []
            for i in retry_indices:
                retry_prompt = (
                    requests[i]["user"]
                    + '\n\nReturn ONLY valid JSON matching exactly this schema: {"p": <integer 0-100>}'
                )
                retry_conversations.append(
                    [
                        {"role": "system", "content": requests[i]["system"]},
                        {"role": "user", "content": retry_prompt},
                    ]
                )

            retry_raw = self._generate_batch(retry_conversations, self._temp_retry)

            for idx, raw_retry in zip(retry_indices, retry_raw):
                p_hat_retry = _parse_p(raw_retry)
                raw_first = first_raw[idx]
                if p_hat_retry is not None:
                    retry_results[idx] = LLMResponse(
                        p_hat=p_hat_retry,
                        raw_text=raw_retry,
                        valid=True,
                        retried=True,
                    )
                else:
                    self._parse_failures += 1
                    self._log_failure(raw_first, raw_retry)
                    retry_results[idx] = LLMResponse(
                        p_hat=None,
                        raw_text=raw_first,
                        valid=False,
                        retried=True,
                    )

        out: list[dict[str, Any]] = []
        for i, req in enumerate(requests):
            resp = first_pass[i] if first_pass[i] is not None else retry_results[i]
            out.append({"key": req["key"], "response": resp})

        return out

    async def query_at_temperature_async(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float,
    ) -> LLMResponse:
        """
        Async compatibility shim for an explicit-temperature query; no retry.
        """
        return self.query_at_temperature(system_prompt, user_prompt, temperature)

    # ── Private helpers ───────────────────────────────────────────────────────

    def _make_sampling_params(self, temperature: float) -> SamplingParams:
        return SamplingParams(
            temperature=temperature,
            max_tokens=self._max_tokens,
        )

    def _chat_kwargs(self) -> dict[str, Any]:
        """
        Extra kwargs forwarded to vLLM's chat() method.

        Qwen3 supports chat_template_kwargs such as enable_thinking=False in
        server mode; offline chat uses the model's chat template as well, so we
        pass the same toggle here when requested. If the installed vLLM/model
        build does not consume it, it will typically be ignored at template time.
        """
        kwargs: dict[str, Any] = {
            "use_tqdm": False,
        }
        if self._disable_thinking:
            kwargs["chat_template_kwargs"] = {"enable_thinking": False}
        return kwargs

    def _extract_text(self, output: Any) -> str:
        """
        Extract generated text from a vLLM RequestOutput.
        """
        try:
            if output.outputs:
                return output.outputs[0].text or ""
        except Exception:
            pass
        return ""

    def _generate_one(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float,
    ) -> str:
        """
        Generate one chat completion synchronously using offline inference.
        """
        conversations = [
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]
        ]
        outputs = self._generate_batch(conversations, temperature)
        return outputs[0] if outputs else ""

    def _generate_batch(
        self,
        conversations: list[list[dict[str, str]]],
        temperature: float,
    ) -> list[str]:
        """
        Generate a batch of chat completions synchronously using vLLM offline
        inference. Returns raw text in the same order as the inputs.
        """
        try:
            sampling_params = self._make_sampling_params(temperature)
            outputs = self._llm.chat(
                conversations,
                sampling_params=sampling_params,
                **self._chat_kwargs(),
            )
            return [self._extract_text(out) for out in outputs]
        except TypeError as exc:
            # Backward-compat fallback if installed vLLM doesn't accept
            # chat_template_kwargs in chat().
            if "chat_template_kwargs" in str(exc):
                logger.warning(
                    "Installed vLLM version does not accept chat_template_kwargs "
                    "in offline chat(); retrying without them."
                )
                try:
                    sampling_params = self._make_sampling_params(temperature)
                    outputs = self._llm.chat(
                        conversations,
                        sampling_params=sampling_params,
                        use_tqdm=False,
                    )
                    return [self._extract_text(out) for out in outputs]
                except Exception as inner_exc:
                    logger.error("Offline vLLM batch call failed: %s", inner_exc)
                    return [""] * len(conversations)
            logger.error("Offline vLLM batch call failed: %s", exc)
            return [""] * len(conversations)
        except Exception as exc:
            logger.error("Offline vLLM batch call failed: %s", exc)
            return [""] * len(conversations)

    def _log_failure(self, raw_first: str, raw_retry: str) -> None:
        """Append failed responses to the parse-failure log."""
        log_path = self._log_dir / "parse_failures.jsonl"
        record = {"attempt_1": raw_first, "attempt_2": raw_retry}
        with log_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record) + "\n")


def _parse_p(text: str) -> float | None:
    """Extract the probability value from a JSON response string.

    Accepts {"p": N} where N is an integer or float in [0, 100].
    Returns the value as a float in [0, 1], or None on any parse error.

    Robust to thinking-mode outputs: strips <think>...</think> blocks
    before parsing, and on regex fallback takes the last match (the
    final answer) rather than the first.
    """
    text = text.strip()
    if not text:
        return None

    cleaned = re.sub(
        r"<(?:think|thinking|reasoning)>.*?</(?:think|thinking|reasoning)>",
        "",
        text,
        flags=re.DOTALL,
    ).strip()

    try:
        data: Any = json.loads(cleaned)
        if isinstance(data, dict) and "p" in data:
            p = float(data["p"])
            if 0.0 <= p <= 100.0:
                return p / 100.0
    except (json.JSONDecodeError, TypeError, ValueError):
        pass

    matches = re.findall(r'"p"\s*:\s*(\d+(?:\.\d+)?)', cleaned)
    if matches:
        p = float(matches[-1])
        if 0.0 <= p <= 100.0:
            return p / 100.0

    if cleaned != text:
        matches_orig = re.findall(r'"p"\s*:\s*(\d+(?:\.\d+)?)', text)
        if matches_orig:
            p = float(matches_orig[-1])
            if 0.0 <= p <= 100.0:
                return p / 100.0

    return None