"""
Prompt-hash cache backed by SQLite.

Identical prompts produce identical cache keys, so the LLM is never called
twice for the same input.  Disable via config for fresh re-runs.

"""

from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
from pathlib import Path

logger = logging.getLogger(__name__)


class PromptCache:
    """
    SQLite-backed key-value store mapping prompt hashes to LLM responses.

    The cache key is SHA-256(system_prompt + user_prompt).  Stored values
    include the raw response text and the parsed p_hat so the client layer
    can skip re-parsing on cache hits.
    """

    def __init__(self, db_path: str, enabled: bool = True) -> None:
        """
        Args:
            db_path: Path to the SQLite database file.
            enabled: If False, get() always returns None (cache-miss) and
                     set() is a no-op.  Useful for forced fresh runs.
        """
        self._enabled = enabled
        if enabled:
            Path(db_path).parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(db_path, check_same_thread=False)
            self._init_schema()
        else:
            self._conn = None  # type: ignore[assignment]

    def get(self, system_prompt: str, user_prompt: str) -> dict | None:
        """
        Look up a cached response by prompt content.

        Args:
            system_prompt: System instruction used in the call.
            user_prompt: User-facing prompt for this specific profile + question.

        Returns:
            Cached dict with keys {"p_hat", "raw_text", "retried"}, or None on miss.
        """
        if not self._enabled:
            return None
        key = _hash_prompts(system_prompt, user_prompt)
        row = self._conn.execute(
            "SELECT payload FROM cache WHERE key = ?", (key,)
        ).fetchone()
        if row is None:
            return None
        return json.loads(row[0])

    def set(
        self,
        system_prompt: str,
        user_prompt: str,
        p_hat: float | None,
        raw_text: str,
        retried: bool,
    ) -> None:
        """
        Store a response in the cache.

        Args:
            system_prompt: System instruction used in the call.
            user_prompt: User-facing prompt.
            p_hat: Parsed probability in [0, 1], or None if the call failed.
            raw_text: Raw model output text.
            retried: Whether the retry policy was triggered.
        """
        if not self._enabled:
            return
        key = _hash_prompts(system_prompt, user_prompt)
        payload = json.dumps({"p_hat": p_hat, "raw_text": raw_text, "retried": retried})
        self._conn.execute(
            "INSERT OR REPLACE INTO cache (key, payload) VALUES (?, ?)",
            (key, payload),
        )
        self._conn.commit()

    def close(self) -> None:
        """Close the underlying SQLite connection."""
        if self._conn is not None:
            self._conn.close()

    def _init_schema(self) -> None:
        """Create the cache table if it does not already exist."""
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, payload TEXT)"
        )
        self._conn.commit()


def _hash_prompts(system_prompt: str, user_prompt: str) -> str:
    """Compute a deterministic SHA-256 key from both prompt strings."""
    combined = system_prompt + "\x00" + user_prompt
    return hashlib.sha256(combined.encode("utf-8")).hexdigest()
