"""
Prompt templates for the GSS 2024 preliminary analysis.

Handles both Type A (individual prediction) and Type B (experimental
manipulation) prompts. The template is dataset-specific; the question
lines and feature mappings are the only parts that change across datasets.
"""

from __future__ import annotations

import pandas as pd

# ── System prompt ──────────────────────────────────────────────────────────────

SYSTEM_PROMPT = (
    "You are simulating the behavior of a specific survey respondent. "
    "Your task is to predict what this particular person would do or choose, "
    "based on their individual characteristics. "
    "Do NOT give normative advice. Do NOT predict what a typical person would do. "
    "Simulate THIS specific person.\n\n"
    "You MUST respond with valid JSON only, with no surrounding text. "
    'Schema: {"p": <integer from 0 to 100>} '
    "where p is your probability estimate (0 = definitely No, 100 = definitely Yes)."
)

SYSTEM_PROMPT_RECALL = (
    "You are a statistical analyst estimating population-level probabilities. "
    "Based on known population patterns and statistical tendencies, estimate "
    "the probability that an individual with the following characteristics "
    "would have the described outcome. "
    "Rely on broad demographic and statistical patterns rather than "
    "imagining a specific individual.\n\n"
    "You MUST respond with valid JSON only, with no surrounding text. "
    'Schema: {"p": <integer from 0 to 100>} '
    "where p is your probability estimate (0 = definitely No, 100 = definitely Yes)."
)

# ── Type A question lines ─────────────────────────────────────────────────────

_QUESTION_A1 = (
    "How likely is it, on a scale from 0 to 100, that this person owns or is "
    "buying their home (as opposed to renting)? "
    "(0 = definitely rents, 100 = definitely owns)"
)

_QUESTION_A2 = (
    "How likely is it, on a scale from 0 to 100, that this person is pretty "
    "well satisfied with their current financial situation? "
    "(0 = definitely not satisfied, 100 = definitely satisfied)"
)

_QUESTION_A3 = (
    "How likely is it, on a scale from 0 to 100, that this person would identify "
    "as middle class or upper class (rather than working class or lower class)? "
    "(0 = definitely working/lower class, 100 = definitely middle/upper class)"
)

_QUESTIONS: dict[str, str] = {"A1": _QUESTION_A1, "A2": _QUESTION_A2, "A3": _QUESTION_A3}

# ── Type B question lines (B1: welfare framing) ──────────────────────────────

_QUESTION_B1_WELFARE = (
    "How likely is it, on a scale from 0 to 100, that this person thinks "
    "the government is spending too little on welfare? "
    "(0 = definitely does NOT think too little is spent, "
    "100 = definitely thinks too little is spent)"
)

_QUESTION_B1_POOR = (
    "How likely is it, on a scale from 0 to 100, that this person thinks "
    "the government is spending too little on assistance to the poor? "
    "(0 = definitely does NOT think too little is spent, "
    "100 = definitely thinks too little is spent)"
)

_TYPE_B_QUESTIONS: dict[str, dict[str, str]] = {
    "B1": {"condition_a": _QUESTION_B1_WELFARE, "condition_b": _QUESTION_B1_POOR},
}

# ── Label lookup tables ────────────────────────────────────────────────────────

_GENDER_LABELS = {"male": "male", "female": "female"}

_HYPOTHESIS_FEATURE_COLS: dict[str, list[str]] = {
    "A1": [
        "age", "gender_bin", "educ_years", "income", "wordsum",
        "race", "marital", "wrkstat", "region", "relig", "partyid", "polviews",
    ],
    "A2": [
        "age", "gender_bin", "educ_years", "income", "wordsum", "notsmart",
        "overconfident_flag",
        "race", "marital", "wrkstat", "region", "relig", "partyid", "polviews",
    ],
    "A3": [
        "age", "gender_bin", "educ_years", "income", "confinan",
        "race", "marital", "wrkstat", "region", "relig", "partyid", "polviews",
    ],
}
_HYPOTHESIS_FEATURE_COLS["B1"] = list(_HYPOTHESIS_FEATURE_COLS["A1"])

_RACE_LABELS = {1: "White", 2: "Black", 3: "Other"}
_MARITAL_LABELS = {1: "Married", 2: "Widowed", 3: "Divorced", 4: "Separated", 5: "Never married"}
_WRKSTAT_LABELS = {
    1: "Working full time",
    2: "Working part time",
    3: "Has a job but is temporarily not at work",
    4: "Unemployed / laid off / looking for work",
    5: "Retired",
    6: "In school",
    7: "Keeping house",
    8: "Other",
}
_REGION_LABELS = {1: "Northeast", 2: "Midwest", 3: "South", 4: "West"}
_RELIG_LABELS = {
    1: "Protestant",
    2: "Catholic",
    3: "Jewish",
    4: "No religion",
    5: "Other",
    6: "Buddhism",
    7: "Hinduism",
    8: "Other Eastern religions",
    9: "Muslim/Islam",
    10: "Orthodox-Christian",
    11: "Christian",
    12: "Native American",
    13: "Inter-nondenominational",
}
_PARTYID_LABELS = {
    0: "Strong Democrat",
    1: "Not very strong Democrat",
    2: "Independent, close to Democrat",
    3: "Independent (neither, no response)",
    4: "Independent, close to Republican",
    5: "Not very strong Republican",
    6: "Strong Republican",
    7: "Other party",
}
_POLVIEWS_LABELS = {
    1: "Extremely liberal",
    2: "Liberal",
    3: "Slightly liberal",
    4: "Moderate / middle of the road",
    5: "Slightly conservative",
    6: "Conservative",
    7: "Extremely conservative",
}
_CONFINAN_LABELS = {1: "A great deal", 2: "Only some", 3: "Hardly any"}
_NOTSMART_LABELS = {
    1: "almost every day",
    2: "at least once a week",
    3: "a few times a month",
    4: "a few times a year",
    5: "less than once a year",
    6: "never",
}


def _format_code_with_label(value: object, labels: dict[int, str]) -> str:
    """Render a coded survey value as ``label (code X)`` when possible."""
    if pd.isna(value):
        return "unknown"
    code = int(value)
    label = labels.get(code)
    return f"{label} (code {code})" if label is not None else f"code {code}"


def _render_profile_block(row: pd.Series, hypothesis: str) -> list[str]:
    """Build the profile description lines shared by Type A and Type B prompts.

    The rendered variables are kept aligned with the hypothesis-level feature
    registry returned by :func:`get_prompt_feature_cols`. Any variable included
    in the aligned feature set is surfaced to the LLM in human-readable form.
    """
    parts: list[str] = ["This person has the following characteristics:"]
    feature_cols = get_prompt_feature_cols(hypothesis)

    if "age" in feature_cols:
        age_raw = row.get("age")
        if pd.notna(age_raw):
            parts.append(f"- Age: {int(age_raw)} years old")

    if "gender_bin" in feature_cols:
        gender_label = _GENDER_LABELS.get(str(row.get("gender_bin", "")), "unknown gender")
        parts.append(f"- Gender: {gender_label}")

    if "educ_years" in feature_cols:
        educ_raw = row.get("educ_years")
        if pd.notna(educ_raw):
            parts.append(f"- Education: {int(educ_raw)} years of schooling")

    if "income" in feature_cols:
        income_raw = row.get("income")
        if pd.notna(income_raw):
            parts.append(f"- Income: approximately ${int(income_raw):,}/year, inflation-adjusted")

    if "wordsum" in feature_cols:
        wordsum = row.get("wordsum")
        if pd.notna(wordsum):
            parts.append(f"- Vocabulary test (WORDSUM): {int(wordsum)} out of 10")

    if "notsmart" in feature_cols:
        notsmart_raw = row.get("notsmart")
        if pd.notna(notsmart_raw):
            notsmart_desc = _NOTSMART_LABELS.get(int(notsmart_raw), str(int(notsmart_raw)))
            parts.append(
                "- Feels 'not smart enough for financial matters': "
                f"{notsmart_desc} (code {int(notsmart_raw)})"
            )

    if "overconfident_flag" in feature_cols:
        overcflag = row.get("overconfident_flag")
        if pd.notna(overcflag):
            flag_text = "yes" if int(overcflag) == 1 else "no"
            parts.append(f"- Overconfident flag: {flag_text}")

    if "confinan" in feature_cols:
        confinan_raw = row.get("confinan")
        if pd.notna(confinan_raw):
            parts.append(
                "- Confidence in financial institutions: "
                f"{_format_code_with_label(confinan_raw, _CONFINAN_LABELS)}"
            )

    coded_feature_specs = [
        ("race", "Race", _RACE_LABELS),
        ("marital", "Marital status", _MARITAL_LABELS),
        ("wrkstat", "Work status", _WRKSTAT_LABELS),
        ("region", "Region", _REGION_LABELS),
        ("relig", "Religion", _RELIG_LABELS),
        ("partyid", "Party identification", _PARTYID_LABELS),
        ("polviews", "Political views", _POLVIEWS_LABELS),
    ]
    for col, label, mapping in coded_feature_specs:
        if col not in feature_cols:
            continue
        value = row.get(col)
        if pd.isna(value):
            continue
        if mapping:
            rendered = _format_code_with_label(value, mapping)
        else:
            rendered = f"code {int(value)}"
        parts.append(f"- {label}: {rendered}")

    return parts


def render_user_prompt(row: pd.Series, hypothesis: str) -> str:
    """Render a Type A user prompt for a single respondent and hypothesis.

    Args:
        row: A row from a hypothesis-specific canonical DataFrame.
        hypothesis: One of ``"A1"``, ``"A2"``, ``"A3"``.

    Returns:
        Formatted user prompt string ending with the hypothesis question.
    """
    parts = _render_profile_block(row, hypothesis)
    parts.append("")
    parts.append(_QUESTIONS[hypothesis])
    return "\n".join(parts)


def render_type_b_prompts(row: pd.Series, hypothesis: str) -> tuple[str, str]:
    """Render both condition prompts for a Type B hypothesis.

    The profile block is identical across conditions; only the question line
    differs.

    Args:
        row: A row from the source DataFrame.
        hypothesis: Type B identifier (e.g. ``"B1"``).

    Returns:
        Tuple of (condition_a_prompt, condition_b_prompt).
    """
    parts = _render_profile_block(row, hypothesis)
    parts.append("")

    questions = _TYPE_B_QUESTIONS[hypothesis]
    prompt_a = "\n".join(parts + [questions["condition_a"]])
    prompt_b = "\n".join(parts + [questions["condition_b"]])
    return prompt_a, prompt_b


def get_system_prompt(mode: str = "simulation") -> str:
    """Return the system prompt for the given prompting mode.

    Args:
        mode: ``"simulation"`` (default) or ``"recall"``.

    Returns:
        System prompt string.
    """
    if mode == "recall":
        return SYSTEM_PROMPT_RECALL
    return SYSTEM_PROMPT


def get_prompt_feature_cols(hypothesis: str) -> list[str]:
    """Return the aligned feature set for a hypothesis.

    The returned columns are the single source of truth for the variables shown
    in the prompt and used by the hypothesis-specific trees / full benchmark
    models.
    """
    try:
        return list(_HYPOTHESIS_FEATURE_COLS[hypothesis])
    except KeyError as exc:
        raise ValueError(f"Unknown hypothesis: {hypothesis}") from exc
