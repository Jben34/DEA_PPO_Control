"""
Report generator for the GSS 2024 preliminary analysis.

Assembles the final markdown report from all analysis results and figures.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any
import textwrap

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

logger = logging.getLogger(__name__)


_FIGURE_DPI = 180

_DISPLAY_LABELS = {
    "age": "Age",
    "gender_bin": "Gender",
    "educ_years": "Education (years)",
    "income": "Income",
    "wordsum": "Wordsum score",
    "capability_bin": "Perceived capability",
    "confidence_level": "Confidence level",
    "overconfident_flag": "Overconfident",
    "confinan_level": "Financial confidence",
    "race": "Race",
    "marital": "Marital status",
    "wrkstat": "Work status",
    "region": "Region",
    "relig": "Religion",
    "partyid": "Party identification",
    "polviews": "Political views",
    "age_bin": "Age group",
    "income_tert": "Income tertile",
    "educ_bin": "Education group",
}


def _display_label(name: Any) -> str:
    label = _DISPLAY_LABELS.get(str(name), str(name).replace("_", " ").title())
    return textwrap.fill(label, width=18)


def _safe_title_suffix(hyp: str, merged: pd.DataFrame | None = None) -> str:
    if merged is None:
        return hyp
    return f"{hyp} (n={len(merged):,})"


def _style_axes(ax: plt.Axes) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(True, axis="both", alpha=0.18, linewidth=0.8)



def generate_report(
    results: dict[str, Any],
    reports_dir: str,
) -> str:
    """Generate the full GSS Phase 1 preliminary report as a markdown file.

    Args:
        results: Dict returned by run.run_phase1.
        reports_dir: Output directory for the report and figures.

    Returns:
        Path to the written markdown report file.
    """
    Path(reports_dir).mkdir(parents=True, exist_ok=True)
    figures_dir = str(Path(reports_dir) / "figures")
    Path(figures_dir).mkdir(parents=True, exist_ok=True)

    sections: list[str] = [
        _header(results),
        _stability_section(results["stability_metrics"]),
        _metrics_section(results["metrics"], results["subgroup_metrics"]),
        _interaction_section(results.get("interaction_metrics", {})),
        _type_b_section(results.get("type_b_results", {})),
        _h_mem_section(results.get("h_mem_results")),
        _trees_section(results, figures_dir),
        _consistency_section(results["consistency"]),
        _checklist_section(results),
        _parse_failures_section(results["parse_failures"]),
        _audit_trail_note(),
    ]

    report_text = "\n\n".join(sections)
    report_path = Path(reports_dir) / "gss_phase1_prelim_2024.md"
    report_path.write_text(report_text, encoding="utf-8")
    logger.info("Report written → %s", report_path)

    _save_calibration_figures(results, figures_dir)
    _save_subgroup_heatmaps(results, figures_dir)

    return str(report_path)


# ── Report sections ────────────────────────────────────────────────────────────

def _header(results: dict) -> str:
    """Render the report header."""
    hyps = ", ".join(results["active_hypotheses"])
    type_b = ", ".join(results.get("active_type_b", []))
    sizes = ", ".join(f"{h}={n}" for h, n in results["sample_sizes"].items())
    return (
        "# GSS Phase 1 Preliminary Analysis — 2024\n\n"
        f"**Data:** GSS 2024 STATA  \n"
        f"**Type A hypotheses:** {hyps}  \n"
        f"**Type B hypotheses:** {type_b or 'none'}  \n"
        f"**Sample sizes:** {sizes}  \n"
        f"**Stability sample:** n={results['n_stab']}  \n"
    )


def _stability_section(stab: dict) -> str:
    """Render the H_stability section."""
    lines = [
        "## H_stability — Stability Probe\n",
        "| Metric | Value |\n|---|---|\n",
        f"| Mean MAD (pp) | {stab['mean_mad']:.2f} |\n",
        f"| 90th-pct MAD (pp) | {stab['p90_mad']:.2f} |\n",
        f"| Share MAD < 5pp (acceptable) | {stab['share_acceptable']:.1%} |\n",
        f"| Share MAD 5-10pp (moderate) | {stab['share_moderate']:.1%} |\n",
        f"| Share MAD > 10pp (failure) | {stab['share_failed']:.1%} |\n",
    ]
    if stab.get("per_hypothesis"):
        lines.append("\n**Per-hypothesis breakdown**\n\n")
        lines.append("| Hypothesis | Mean MAD | p90 MAD | Share failed |\n|---|---|---|---|\n")
        for hyp, h_stats in stab["per_hypothesis"].items():
            lines.append(
                f"| {hyp} | {h_stats['mean_mad']:.2f} | {h_stats['p90_mad']:.2f} "
                f"| {h_stats['share_failed']:.1%} |\n"
            )
    return "".join(lines)


def _metrics_section(all_metrics: dict[str, dict], subgroup_metrics: dict[str, Any]) -> str:
    """Render the Type A global and subgroup metrics section."""
    lines = ["## Type A Metrics — Global\n\n"]
    lines.append("| Hypothesis | F1 | AUC-ROC | ECE | TVD | Sigma ratio | n |\n")
    lines.append("|---|---|---|---|---|---|---|\n")
    for hyp, m in all_metrics.items():
        lines.append(
            f"| {hyp} | {_fmt(m.get('f1'))} | {_fmt(m.get('auc_roc'))} | "
            f"{_fmt(m.get('ece'))} | {_fmt(m.get('tvd'))} | "
            f"{_fmt(m.get('sigma_ratio'))} | {m.get('n', '—')} |\n"
        )

    lines.append("\n### Subgroup Metrics (TVD + sigma ratio)\n\n")
    for hyp, sg_df in subgroup_metrics.items():
        if isinstance(sg_df, pd.DataFrame) and not sg_df.empty:
            lines.append(f"\n**{hyp}**\n\n")
            lines.append("| Subgroup | Level | TVD | Sigma ratio | n |\n|---|---|---|---|---|\n")
            for _, row in sg_df.iterrows():
                lines.append(
                    f"| {row.get('subgroup_col', '')} | {row.get('subgroup_level', '')} "
                    f"| {_fmt(row.get('tvd'))} | {_fmt(row.get('sigma_ratio'))} "
                    f"| {int(row.get('n', 0))} |\n"
                )
    return "".join(lines)


def _interaction_section(interaction_metrics: dict[str, pd.DataFrame]) -> str:
    """Render the pre-specified interaction metrics section."""
    if not interaction_metrics:
        return ""
    lines = ["## Pre-specified Interaction Metrics\n\n"]
    for hyp, df in interaction_metrics.items():
        if df is None or df.empty:
            continue
        lines.append(f"\n### {hyp}\n\n")
        lines.append(df.to_markdown(index=False) + "\n")
    return "".join(lines)


def _type_b_section(type_b_results: dict[str, dict]) -> str:
    """Render the Type B experimental sensitivity section."""
    if not type_b_results:
        return ""
    lines = ["## Type B — Experimental Sensitivity\n\n"]

    for b_name, res in type_b_results.items():
        if "error" in res:
            lines.append(f"### {b_name}\n\n{res['error']}\n\n")
            continue

        lines.append(f"### {b_name} — Welfare Framing Effect\n\n")
        lines.append("| Metric | Value |\n|---|---|\n")
        lines.append(f"| Profiles tested | {res['n_profiles']} |\n")
        lines.append(f"| Mean effect (pp) | {res['mean_effect_pp']:.1f} |\n")
        lines.append(f"| Median effect (pp) | {res['median_effect_pp']:.1f} |\n")
        lines.append(f"| SD of effect (pp) | {res['sd_effect_pp']:.1f} |\n")
        lines.append(f"| Share positive (expected direction) | {res['share_positive']:.1%} |\n")
        lines.append(f"| Empirical benchmark (pp) | {res['empirical_effect_pp']:.1f} |\n")
        lines.append(f"| LLM / empirical ratio | {res['effect_ratio']:.2f} |\n\n")

        sg_df = res.get("subgroup_effects")
        if isinstance(sg_df, pd.DataFrame) and not sg_df.empty:
            lines.append("**Subgroup heterogeneity**\n\n")
            lines.append("| Subgroup | Level | Mean effect (pp) | n |\n|---|---|---|---|\n")
            for _, row in sg_df.iterrows():
                lines.append(
                    f"| {row['subgroup_col']} | {row['subgroup_level']} "
                    f"| {row['mean_effect_pp']:.1f} | {row['n']} |\n"
                )
            lines.append("\n")

        int_df = res.get("interaction_effects")
        if isinstance(int_df, pd.DataFrame) and not int_df.empty:
            lines.append("**Pre-specified interaction**\n\n")
            lines.append(int_df.to_markdown(index=False) + "\n\n")

        effect_tree = res.get("effect_tree")
        if effect_tree is not None:
            lines.append("**Effect heterogeneity tree**\n\n")
            lines.append(
                f"Largest-effect leaf: {effect_tree.worst_leaf_rule} "
                f"(mean δ={effect_tree.worst_leaf_mean:.1f}pp, n={effect_tree.worst_leaf_n})\n\n"
            )
            lines.append(
                f"Top features: {', '.join(effect_tree.feature_importance.head(3).index.tolist())}\n\n"
            )

    return "".join(lines)


def _h_mem_section(h_mem: dict | None) -> str:
    """Render the H_mem simulation vs memorization probe section."""
    if not h_mem:
        return ""
    lines = [
        "## H_mem — Simulation vs Memorization Probe\n\n",
        "*Preliminary interpretation: the 'full' XGBoost model includes GSS variables "
        "not shown to the LLM (race, marital status, work status, region). This tests "
        "whether prompt framing changes how the LLM leverages parametric knowledge "
        "about unobserved variables — a weaker test than Phase 1 DHS where the full "
        "model will use variables the LLM explicitly receives.*\n\n",
    ]

    lines.append("### XGBoost Benchmarks\n\n")
    lines.append("| Model | AUC | Features |\n|---|---|---|\n")
    lines.append(f"| Coarse (demographics) | {h_mem['coarse_auc']:.3f} | {', '.join(h_mem['coarse_features'])} |\n")
    lines.append(f"| Full (all profile) | {h_mem['full_auc']:.3f} | {', '.join(h_mem['full_features'])} |\n\n")

    lines.append("### Prompt Divergence by Conflict Level\n\n")
    lines.append("| Metric | Value |\n|---|---|\n")
    lines.append(f"| Profiles tested | {h_mem['n_profiles']} |\n")
    lines.append(f"| Divergence (low conflict) | {h_mem['prompt_divergence_low']:.4f} |\n")
    lines.append(f"| Divergence (high conflict) | {h_mem['prompt_divergence_high']:.4f} |\n")
    lines.append(f"| High/low ratio | {h_mem['prompt_divergence_ratio']:.2f} |\n")
    lines.append(f"| Mode correlation (Spearman) | {h_mem['mode_correlation']:.3f} |\n")
    lines.append(f"| Sigma ratio (simulation) | {h_mem['sigma_ratio_sim']:.3f} |\n")
    lines.append(f"| Sigma ratio (recall) | {h_mem['sigma_ratio_rec']:.3f} |\n\n")

    lines.append("**Interpretation:**\n\n")
    ratio = h_mem["prompt_divergence_ratio"]
    if ratio > 1.3:
        lines.append(
            "Divergence is meaningfully higher on high-conflict profiles "
            f"(ratio={ratio:.2f}), suggesting the simulation prompt activates "
            "richer profile reasoning when coarse priors and detailed information disagree.\n\n"
        )
    elif ratio < 0.8:
        lines.append(
            f"Divergence is *lower* on high-conflict profiles (ratio={ratio:.2f}), "
            "which is unexpected and may indicate both modes converge under uncertainty.\n\n"
        )
    else:
        lines.append(
            f"Divergence is similar across conflict levels (ratio={ratio:.2f}), "
            "suggesting prompt framing does not differentially activate richer reasoning "
            "on profiles where it matters most.\n\n"
        )

    lines.append("### Alignment with Benchmark Models\n\n")
    lines.append("| Metric | Value |\n|---|---|\n")
    lines.append(f"| Recall → Coarse distance | {h_mem['recall_to_coarse']:.4f} |\n")
    lines.append(f"| Simulation → Full distance | {h_mem['sim_to_full']:.4f} |\n")
    lines.append(f"| Recall → Full distance | {h_mem['recall_to_full']:.4f} |\n")
    lines.append(f"| Simulation → Coarse distance | {h_mem['sim_to_coarse']:.4f} |\n\n")

    # Alignment by conflict table.
    align_df = h_mem.get("alignment_by_conflict")
    if isinstance(align_df, pd.DataFrame) and not align_df.empty:
        lines.append("### Alignment by Conflict Level\n\n")
        lines.append(align_df.to_markdown(index=False) + "\n\n")

    # Accuracy table.
    acc_df = h_mem.get("accuracy_results")
    if isinstance(acc_df, pd.DataFrame) and not acc_df.empty:
        lines.append("### Predictive Accuracy (vs True Outcomes)\n\n")
        lines.append(acc_df.to_markdown(index=False) + "\n\n")

    return "".join(lines)


def _audit_trail_note() -> str:
    """Render a note about the prompt audit trail."""
    return (
        "## Prompt Audit Trail\n\n"
        "Every LLM prediction is stored with its full system prompt and user prompt "
        "in `data/interim/prompt_audit_trail.parquet`. Each row contains: "
        "`id`, `hypothesis`, `condition` (for Type B), `p_hat`, `raw_text`, "
        "`valid`, `retried`, `system_prompt`, `user_prompt`. "
        "This enables post-hoc tracing of any prediction to the exact prompt that produced it.\n"
    )


def _trees_section(results: dict, figures_dir: str) -> str:
    """Render the decision tree diagnostics section."""
    lines = ["## Decision Tree Diagnostics\n\n"]

    for hyp in results["active_hypotheses"]:
        lines.append(f"\n### {hyp}\n\n")
        r_tree = results["residual_trees"].get(hyp)
        i_tree = results["implicit_trees"].get(hyp)
        o_tree = results["outcome_trees"].get(hyp)

        if r_tree:
            lines.append(
                f"**Residual tree** — worst leaf: {r_tree.worst_leaf_rule} "
                f"(mean residual={r_tree.worst_leaf_mean:.3f}, n={r_tree.worst_leaf_n})\n\n"
            )
            lines.append(f"Top features: {', '.join(r_tree.feature_importance.head(3).index.tolist())}\n\n")
        if i_tree:
            lines.append(
                f"**LLM implicit tree** — top features: "
                f"{', '.join(i_tree.feature_importance.head(3).index.tolist())}\n\n"
            )
        if o_tree and i_tree:
            i_top = set(i_tree.feature_importance.head(3).index)
            o_top = set(o_tree.feature_importance.head(3).index)
            overlap = i_top & o_top
            lines.append(
                f"**Implicit vs outcome tree overlap** — shared top features: "
                f"{overlap if overlap else 'none'}\n\n"
            )

    cross = results.get("cross_error_tree")
    if cross:
        lines.append(
            f"\n### Cross-Hypothesis Error Tree\n\n"
            f"Worst leaf: {cross.worst_leaf_rule} "
            f"(mean |residual|={cross.worst_leaf_mean:.3f}, n={cross.worst_leaf_n})\n\n"
            f"Top features: {', '.join(cross.feature_importance.head(3).index.tolist())}\n\n"
        )
    return "".join(lines)


def _consistency_section(consistency: dict) -> str:
    """Render the cross-hypothesis consistency section."""
    lines = ["## Cross-Hypothesis Internal Consistency\n\n"]
    note = consistency.get("note", "")
    if note:
        lines.append(f"*{note}*\n\n")

    for pair_result in consistency.get("pairs", []):
        pair_name = pair_result.get("pair", "?")
        n = pair_result.get("n_shared", 0)
        frob = pair_result.get("frobenius_dist", float("nan"))
        mad = pair_result.get("mean_abs_off_diag", float("nan"))
        lines.append(f"### Pair {pair_name} (n={n})\n\n")
        lines.append(f"Frobenius distance: {frob:.4f}  \n")
        lines.append(f"Mean abs off-diagonal difference: {mad:.4f}\n\n")

        for dp in pair_result.get("divergent_pairs", []):
            lines.append(
                f"- {dp['h_i']}-{dp['h_j']}: r_llm={dp['r_llm']:.3f}, "
                f"r_data={dp['r_data']:.3f}, Δ={dp['delta']:+.3f} ({dp['direction']})\n"
            )
        lines.append("\n")

    if not consistency.get("pairs"):
        lines.append("No feasible hypothesis pairs for consistency analysis.\n")

    return "".join(lines)


def _checklist_section(results: dict) -> str:
    """Render the 'What we learn' checklist."""
    stab = results["stability_metrics"]
    metrics = results["metrics"]

    stab_ok = stab["share_failed"] < 0.10
    stab_verdict = "Acceptable" if stab_ok else "Reliability issues — see stability section"

    sigma_ratios = {h: m.get("sigma_ratio", float("nan")) for h, m in metrics.items()}
    compressed = [h for h, r in sigma_ratios.items() if not np.isnan(r) and r < 0.5]
    compress_verdict = "No severe compression" if not compressed else f"Compressed for: {', '.join(compressed)}"

    # H_mem verdict
    h_mem = results.get("h_mem_results")
    if h_mem:
        ratio = h_mem.get("prompt_divergence_ratio", float("nan"))
        if not np.isnan(ratio) and ratio > 1.3:
            h_mem_verdict = f"Divergence ratio={ratio:.2f} — simulation prompt shows richer reasoning on conflict profiles"
        else:
            h_mem_verdict = f"Divergence ratio={ratio:.2f} — no clear evidence of differential reasoning"
    else:
        h_mem_verdict = "Not run"

    return (
        "## 'What We Learn' Checklist\n\n"
        "| Question | Verdict |\n|---|---|\n"
        f"| Probability elicitation stable enough? | {stab_verdict} |\n"
        f"| Variance compression (sigma ratio << 1)? | {compress_verdict} |\n"
        f"| Worst-case profile types | See residual tree and cross-error tree sections |\n"
        f"| LLM implicit logic ≈ empirical outcome tree? | See decision tree section |\n"
        f"| Recall vs simulation (H_mem)? | {h_mem_verdict} |\n"
    )


def _parse_failures_section(n_failures: int) -> str:
    """Render the parse failures section."""
    return (
        f"## LLM Parse Failures\n\n"
        f"Total records where both parse attempts failed: **{n_failures}**  \n"
        f"Raw failed responses are logged in `logs/parse_failures.jsonl`.\n"
    )


# ── Figure generators ──────────────────────────────────────────────────────────

_OUTCOME_COL_FOR_HYP = {"A1": "y_dwelown", "A2": "y_satfin", "A3": "y_class"}


def _save_calibration_figures(results: dict, figures_dir: str) -> None:
    """Save polished calibration reliability diagrams for each hypothesis."""
    from sklearn.calibration import calibration_curve

    for hyp in results["active_hypotheses"]:
        merged = results.get("merged_dfs", {}).get(hyp)
        if merged is None:
            continue
        p_col = f"p_hat_{hyp}"
        y_col = _OUTCOME_COL_FOR_HYP.get(hyp)
        if y_col is None or p_col not in merged.columns:
            continue

        valid = merged[[y_col, p_col]].dropna()
        if valid.empty:
            continue

        y = valid[y_col].to_numpy(float)
        p = valid[p_col].clip(0, 1).to_numpy(float)
        try:
            fraction_pos, mean_pred = calibration_curve(y, p, n_bins=10, strategy="uniform")

            fig, ax = plt.subplots(figsize=(7.2, 5.4))
            ax.plot([0, 1], [0, 1], linestyle="--", linewidth=1.5, color="black", label="Perfect calibration")
            ax.plot(
                mean_pred,
                fraction_pos,
                marker="o",
                linewidth=2.0,
                markersize=6,
                label="Observed calibration",
            )
            ax.set_xlim(0, 1)
            ax.set_ylim(0, 1)
            ax.set_xlabel("Mean predicted probability")
            ax.set_ylabel("Observed fraction positive")
            ax.set_title(f"Calibration plot — {_safe_title_suffix(hyp, valid)}", fontsize=13, pad=12)
            _style_axes(ax)
            ax.legend(frameon=False, loc="upper left")

            counts, _ = np.histogram(p, bins=np.linspace(0, 1, 11))
            support_note = (
                f"10 equal-width bins\n"
                f"Non-empty bins: {(counts > 0).sum()} / 10\n"
                f"Mean prediction: {p.mean():.3f}"
            )
            ax.text(
                0.98, 0.04, support_note, transform=ax.transAxes, ha="right", va="bottom",
                fontsize=9, bbox={"boxstyle": "round,pad=0.3", "facecolor": "white", "alpha": 0.9, "edgecolor": "0.8"}
            )

            fig.tight_layout()
            fig.savefig(f"{figures_dir}/calibration_{hyp}.png", dpi=_FIGURE_DPI, bbox_inches="tight")
            plt.close(fig)
        except Exception as exc:
            logger.warning("Calibration figure for %s failed: %s", hyp, exc)


def _save_subgroup_heatmaps(results: dict, figures_dir: str) -> None:
    """Save polished TVD heatmaps across subgroups for each hypothesis."""
    for hyp, sg_df in results.get("subgroup_metrics", {}).items():
        if not isinstance(sg_df, pd.DataFrame) or sg_df.empty:
            continue
        try:
            plot_df = sg_df.copy()
            plot_df["subgroup_col_display"] = plot_df["subgroup_col"].map(_display_label)
            plot_df["subgroup_level_display"] = plot_df["subgroup_level"].astype(str).str.replace("_", " ")
            pivot = plot_df.pivot_table(
                values="tvd", index="subgroup_col_display", columns="subgroup_level_display", aggfunc="first",
            )
            pivot = pivot.loc[pivot.mean(axis=1).sort_values(ascending=False).index]
            fig_w = max(10, 0.9 * max(6, len(pivot.columns)))
            fig_h = max(5.5, 0.7 * max(4, len(pivot.index)))
            fig, ax = plt.subplots(figsize=(fig_w, fig_h))
            hm = sns.heatmap(
                pivot, annot=True, fmt=".3f", cmap="Reds", ax=ax, vmin=0, vmax=0.3,
                linewidths=0.5, linecolor="white", cbar_kws={"label": "Total variation distance"},
                annot_kws={"fontsize": 9},
            )
            ax.set_title(f"Subgroup disparity heatmap — {hyp}", fontsize=13, pad=12)
            ax.set_xlabel("Subgroup level")
            ax.set_ylabel("Subgroup variable")
            ax.tick_params(axis="x", rotation=35, labelsize=9)
            ax.tick_params(axis="y", rotation=0, labelsize=10)
            for tick in ax.get_xticklabels():
                tick.set_horizontalalignment("right")
            cbar = hm.collections[0].colorbar
            cbar.ax.tick_params(labelsize=9)
            cbar.set_label("Total variation distance", fontsize=10)
            fig.text(
                0.01, 0.01,
                "Blank cells indicate subgroup levels without a valid estimate.",
                ha="left", va="bottom", fontsize=9, color="0.35"
            )
            fig.tight_layout(rect=(0, 0.03, 1, 1))
            fig.savefig(f"{figures_dir}/tvd_heatmap_{hyp}.png", dpi=_FIGURE_DPI, bbox_inches="tight")
            plt.close(fig)
        except Exception as exc:
            logger.warning("Subgroup heatmap for %s failed: %s", hyp, exc)


def _fmt(v: float | None) -> str:
    """Format a float metric for markdown tables, handling NaN gracefully."""
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "—"
    return f"{v:.4f}"
