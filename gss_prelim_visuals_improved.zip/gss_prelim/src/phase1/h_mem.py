"""
H_mem — Simulation vs Memorization Probe.

Tests whether LLM predictions rely on population-level recall or
individual-level simulation by:

1. Training two XGBoost benchmarks (coarse demographics-only vs full profile).
2. Identifying high-conflict profiles where the two models disagree.
3. Querying the LLM under recall and simulation prompt framings.
4. Testing whether prompt divergence increases on high-conflict profiles.

In this preliminary analysis, the "full" model uses GSS variables not shown
to the LLM (e.g. race, marital status, work status, region), so the test
measures whether prompt framing changes how the LLM leverages its parametric
knowledge about unobserved variables — a different (weaker) test than Phase 1
DHS where the full model will use variables the LLM explicitly receives.
"""

from __future__ import annotations

import logging
from typing import Any

import numpy as np
import pandas as pd
from sklearn.model_selection import cross_val_predict
from xgboost import XGBClassifier

from ..llm.prompts import get_prompt_feature_cols

logger = logging.getLogger(__name__)

# Feature sets for the two benchmark models.
COARSE_FEATURES = ["age_bin", "gender_bin", "educ_bin", "income_tert"]


def _encode_for_xgb(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    """Label-encode categoricals and fill NaN for XGBoost compatibility.

    Args:
        df: Source DataFrame.
        cols: Columns to encode.

    Returns:
        Encoded DataFrame with only the requested columns.
    """
    out = pd.DataFrame(index=df.index)
    for col in cols:
        if col not in df.columns:
            continue
        s = df[col]
        if s.dtype.name in ("category", "object"):
            out[col] = s.astype("category").cat.codes.replace(-1, np.nan)
        else:
            out[col] = s.astype(float)
    # XGBoost handles NaN natively; no fill needed.
    return out


def train_benchmark_models(
    df: pd.DataFrame,
    outcome_col: str,
    hypothesis: str = "A1",
    random_seed: int = 42,
) -> dict[str, Any]:
    """Train coarse and full XGBoost models and compute conflict scores.

    Both models produce cross-validated predicted probabilities (5-fold)
    to avoid overfitting on the same data used for conflict scoring.

    Args:
        df: Hypothesis-specific DataFrame (e.g. A1) with outcome column.
        outcome_col: Binary outcome column name.
        hypothesis: Hypothesis whose aligned full feature set should be used.
        random_seed: RNG seed for reproducibility.

    Returns:
        Dict with keys:
            coarse_p: Series of coarse model cross-validated predicted probabilities.
            full_p: Series of full model cross-validated predicted probabilities.
            conflict_score: Series of |full_p - coarse_p| per profile.
            conflict_bin: Categorical Series ("low" / "high") split at median.
            coarse_features_used: List of features actually used by the coarse model.
            full_features_used: List of features actually used by the full model.
            coarse_auc: Cross-validated AUC of the coarse model.
            full_auc: Cross-validated AUC of the full model.
    """
    y = df[outcome_col].to_numpy(dtype=int)

    # Coarse model.
    coarse_cols = [c for c in COARSE_FEATURES if c in df.columns]
    X_coarse = _encode_for_xgb(df, coarse_cols)
    coarse_model = XGBClassifier(
        n_estimators=100, max_depth=3, learning_rate=0.1,
        random_state=random_seed, eval_metric="logloss",
        enable_categorical=True,
    )
    coarse_p = cross_val_predict(
        coarse_model, X_coarse, y, cv=5, method="predict_proba",
    )[:, 1]

    # Full model.
    full_feature_spec = get_prompt_feature_cols(hypothesis)
    full_cols = [c for c in full_feature_spec if c in df.columns]
    X_full = _encode_for_xgb(df, full_cols)
    full_model = XGBClassifier(
        n_estimators=200, max_depth=4, learning_rate=0.1,
        random_state=random_seed, eval_metric="logloss",
        enable_categorical=True,
    )
    full_p = cross_val_predict(
        full_model, X_full, y, cv=5, method="predict_proba",
    )[:, 1]

    # Conflict score.
    conflict = np.abs(full_p - coarse_p)
    median_conflict = np.median(conflict)
    conflict_bin = pd.Categorical(
        np.where(conflict >= median_conflict, "high", "low"),
        categories=["low", "high"],
    )

    # Cross-validated AUC for reporting.
    from sklearn.metrics import roc_auc_score
    coarse_auc = float(roc_auc_score(y, coarse_p))
    full_auc = float(roc_auc_score(y, full_p))

    logger.info(
        "H_mem benchmarks: coarse AUC=%.3f (%d features), full AUC=%.3f (%d features), "
        "median conflict=%.3f",
        coarse_auc, len(coarse_cols), full_auc, len(full_cols), median_conflict,
    )

    # Use respondent ID as index for alignment with LLM predictions.
    idx = df["id"] if "id" in df.columns else df.index

    return {
        "coarse_p": pd.Series(coarse_p, index=idx, name="coarse_p"),
        "full_p": pd.Series(full_p, index=idx, name="full_p"),
        "conflict_score": pd.Series(conflict, index=idx, name="conflict_score"),
        "conflict_bin": pd.Series(conflict_bin, index=idx, name="conflict_bin"),
        "coarse_features_used": coarse_cols,
        "full_features_used": full_cols,
        "coarse_auc": coarse_auc,
        "full_auc": full_auc,
    }


def analyse_h_mem(
    sim_predictions: pd.Series,
    recall_predictions: pd.Series,
    benchmarks: dict[str, Any],
    y_true: pd.Series,
) -> dict[str, Any]:
    """Run the full H_mem analysis comparing recall vs simulation modes.

    Args:
        sim_predictions: LLM p_hat under simulation prompt (indexed by profile ID).
        recall_predictions: LLM p_hat under recall prompt (indexed by profile ID).
        benchmarks: Output of train_benchmark_models().
        y_true: Observed binary outcomes (indexed by profile ID).

    Returns:
        Dict of H_mem analysis results.
    """
    # Align all series on common index.
    common = sim_predictions.dropna().index.intersection(
        recall_predictions.dropna().index
    )
    sim = sim_predictions.loc[common].astype(float)
    rec = recall_predictions.loc[common].astype(float)
    coarse_p = benchmarks["coarse_p"].loc[common].astype(float)
    full_p = benchmarks["full_p"].loc[common].astype(float)
    conflict = benchmarks["conflict_bin"].loc[common]
    y = y_true.loc[common].astype(float)

    n = len(common)
    logger.info("H_mem analysis: %d profiles with both prompt modes.", n)

    # ── 6.1 Prompt divergence ────────────────────────────────────────────────
    prompt_div = (sim - rec).abs()
    div_low = float(prompt_div[conflict == "low"].mean())
    div_high = float(prompt_div[conflict == "high"].mean())
    div_ratio = div_high / div_low if div_low > 1e-6 else float("nan")

    # ── 6.2 Alignment with benchmark models ──────────────────────────────────
    # Distance from recall predictions to coarse model.
    recall_to_coarse = (rec - coarse_p).abs().mean()
    # Distance from simulation predictions to full model.
    sim_to_full = (sim - full_p).abs().mean()
    # Also compute the cross distances for comparison.
    recall_to_full = (rec - full_p).abs().mean()
    sim_to_coarse = (sim - coarse_p).abs().mean()

    # ── 6.2 by conflict level ────────────────────────────────────────────────
    alignment_by_conflict: list[dict] = []
    for level in ["low", "high"]:
        mask = conflict == level
        if mask.sum() < 10:
            continue
        alignment_by_conflict.append({
            "conflict_level": level,
            "n": int(mask.sum()),
            "recall_to_coarse": float((rec[mask] - coarse_p[mask]).abs().mean()),
            "sim_to_full": float((sim[mask] - full_p[mask]).abs().mean()),
            "recall_to_full": float((rec[mask] - full_p[mask]).abs().mean()),
            "sim_to_coarse": float((sim[mask] - coarse_p[mask]).abs().mean()),
            "prompt_divergence": float(prompt_div[mask].mean()),
        })

    # ── 7. Accuracy analysis using true outcomes ─────────────────────────────
    from sklearn.metrics import brier_score_loss

    accuracy_results: list[dict] = []
    for label, preds in [("simulation", sim), ("recall", rec),
                          ("coarse_xgb", coarse_p), ("full_xgb", full_p)]:
        brier = float(brier_score_loss(y, preds))
        mae = float((preds - y).abs().mean())
        accuracy_results.append({
            "model": label, "brier_score": brier, "mae": mae, "n": n,
        })

    # Accuracy by conflict level.
    accuracy_by_conflict: list[dict] = []
    for level in ["low", "high"]:
        mask = conflict == level
        if mask.sum() < 10:
            continue
        for label, preds in [("simulation", sim), ("recall", rec)]:
            brier = float(brier_score_loss(y[mask], preds[mask]))
            mae = float((preds[mask] - y[mask]).abs().mean())
            accuracy_by_conflict.append({
                "conflict_level": level, "model": label,
                "brier_score": brier, "mae": mae, "n": int(mask.sum()),
            })

    # ── Sigma ratio comparison ───────────────────────────────────────────────
    sigma_sim = float(np.std(sim))
    sigma_rec = float(np.std(rec))
    sigma_y = float(np.std(y))
    sigma_ratio_sim = sigma_sim / sigma_y if sigma_y > 1e-9 else float("nan")
    sigma_ratio_rec = sigma_rec / sigma_y if sigma_y > 1e-9 else float("nan")

    # ── Profile-level correlation between modes ──────────────────────────────
    from scipy.stats import spearmanr
    mode_corr, _ = spearmanr(sim, rec)

    return {
        "n_profiles": n,
        "prompt_divergence_low": div_low,
        "prompt_divergence_high": div_high,
        "prompt_divergence_ratio": div_ratio,
        "recall_to_coarse": float(recall_to_coarse),
        "sim_to_full": float(sim_to_full),
        "recall_to_full": float(recall_to_full),
        "sim_to_coarse": float(sim_to_coarse),
        "alignment_by_conflict": pd.DataFrame(alignment_by_conflict),
        "accuracy_results": pd.DataFrame(accuracy_results),
        "accuracy_by_conflict": pd.DataFrame(accuracy_by_conflict),
        "sigma_ratio_sim": sigma_ratio_sim,
        "sigma_ratio_rec": sigma_ratio_rec,
        "mode_correlation": float(mode_corr),
        "coarse_auc": benchmarks["coarse_auc"],
        "full_auc": benchmarks["full_auc"],
        "coarse_features": benchmarks["coarse_features_used"],
        "full_features": benchmarks["full_features_used"],
    }
