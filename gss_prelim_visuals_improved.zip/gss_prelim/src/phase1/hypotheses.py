"""
Hypothesis registry for the GSS 2024 preliminary analysis.

Type A hypotheses (individual prediction vs ground truth):
    A1 — Capability gradient → homeownership (DWELOWN).
    A2 — Overconfidence interaction → financial satisfaction (SATFIN).
    A3 — Trust effect → subjective class (CLASS).

Type B hypothesis (experimental sensitivity to prompt manipulation):
    B1 — Welfare framing effect (NATFARE vs NATFAREY).

Ballot structure:
    Ballot 1 (WORDSUM + NOTSMART):  A1, A2
    Ballot 2 (WORDSUM + CONFINAN):  A1, A3
    Ballot 3 (NOTSMART + CONFINAN): A3 only
    B1 runs on the A1 sample (universal + WORDSUM, broadest coverage).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class HypothesisSpec:
    """Complete specification for one Type A hypothesis.

    Attributes:
        name: Short identifier used as a key everywhere.
        outcome_col: Column holding the binary outcome.
        data_key: Key into PrepResult for the hypothesis-specific DataFrame.
        confirmatory_expectation: Plain-language expected direction of effect.
        pre_specified_interaction: Pair of canonical columns for the
            confirmatory interaction subgroup.
        interaction_label: Human-readable name for the interaction.
    """

    name: str
    outcome_col: str
    data_key: str
    confirmatory_expectation: str
    pre_specified_interaction: tuple[str, str]
    interaction_label: str


@dataclass(frozen=True)
class TypeBSpec:
    """Specification for one Type B (experimental sensitivity) hypothesis.

    Attributes:
        name: Short identifier.
        data_key: Key into PrepResult for the source DataFrame.
        condition_a_label: Human-readable label for condition A.
        condition_b_label: Human-readable label for condition B.
        expected_direction: Which condition should produce higher p_hat.
        empirical_effect_pp: Approximate empirical effect size in percentage
            points (from GSS ground truth), for magnitude comparison.
        pre_specified_interaction: Pair of columns for heterogeneity analysis.
        interaction_label: Human-readable name for the interaction.
    """

    name: str
    data_key: str
    condition_a_label: str
    condition_b_label: str
    expected_direction: str
    empirical_effect_pp: float
    pre_specified_interaction: tuple[str, str]
    interaction_label: str


# ── Type A hypotheses ─────────────────────────────────────────────────────────

A1 = HypothesisSpec(
    name="A1",
    outcome_col="y_dwelown",
    data_key="a1_df",
    confirmatory_expectation=(
        "Predicted homeownership probability increases with capability "
        "(higher WORDSUM → higher p_hat)."
    ),
    pre_specified_interaction=("income_tert", "capability_bin"),
    interaction_label="Income × Capability",
)

A2 = HypothesisSpec(
    name="A2",
    outcome_col="y_satfin",
    data_key="a2_df",
    confirmatory_expectation=(
        "Within low-capability profiles, higher financial self-confidence "
        "(overconfidence) should not monotonically increase financial "
        "satisfaction. Misalignment patterns are the diagnostic target."
    ),
    pre_specified_interaction=("overconfident_flag", "income_tert"),
    interaction_label="Overconfidence × Income",
)

A3 = HypothesisSpec(
    name="A3",
    outcome_col="y_class",
    data_key="a3_df",
    confirmatory_expectation=(
        "Trust in financial institutions has a conditional effect on "
        "perceived class position; direction is empirical."
    ),
    pre_specified_interaction=("confinan_level", "educ_bin"),
    interaction_label="Trust × Education",
)

HYPOTHESIS_REGISTRY: dict[str, HypothesisSpec] = {"A1": A1, "A2": A2, "A3": A3}

# ── Type B hypothesis ─────────────────────────────────────────────────────────

B1 = TypeBSpec(
    name="B1",
    data_key="a1_df",
    condition_a_label="welfare",
    condition_b_label="assistance to the poor",
    expected_direction=(
        "Condition B ('assistance to the poor') should produce higher "
        "predicted support than condition A ('welfare'), matching the ~32pp "
        "empirical effect in the GSS (NATFARE vs NATFAREY)."
    ),
    empirical_effect_pp=32.0,
    pre_specified_interaction=("income_tert", "educ_bin"),
    interaction_label="Income × Education",
)

TYPE_B_REGISTRY: dict[str, TypeBSpec] = {"B1": B1}

# ── Universal marginal subgroup splits ────────────────────────────────────────

UNIVERSAL_SUBGROUP_SPLITS: list[tuple[str, str]] = [
    ("age_bin", "Age"),
    ("income_tert", "Income"),
    ("educ_bin", "Education"),
    ("capability_bin", "Capability"),
    ("gender_bin", "Gender"),
]
