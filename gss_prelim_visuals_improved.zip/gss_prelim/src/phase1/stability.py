"""
Stability probe (H_stability) for the GSS 2024 preliminary analysis.

Runs R repeated queries per profile using identical prompts and reports
per-profile MAD, distribution across instability thresholds, and the
90th-percentile MAD. Stability is a precondition for all other analyses.

Temperature must not be 0.0: that would produce artificially deterministic
outputs and defeat the purpose of the probe.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING, Callable

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from ..llm.vllm_client import VLLMClient
    from ..phase1.hypotheses import HypothesisSpec

logger = logging.getLogger(__name__)

MAD_ACCEPTABLE = 5.0   # pp — acceptable stability
MAD_MODERATE = 10.0    # pp — moderate instability (flagged)


def run_stability_probe(
    stab_df: pd.DataFrame,
    active_hypotheses: dict[str, "HypothesisSpec"],
    client: "VLLMClient",
    n_runs: int,
    query_interval_seconds: float,
    temperature: float,
    render_fn: Callable,
    system_prompt: str,
) -> pd.DataFrame:
    """Run the H_stability probe on a stratified subsample.

    Each profile × hypothesis combination is queried n_runs times with
    identical prompts. Runs are issued sequentially with a minimum
    inter-run pause. Within each run all pairs are sent concurrently
    via query_at_temperature_async (no retry policy).

    Args:
        stab_df: Stratified subsample from the canonical parquet.
        active_hypotheses: Hypothesis specs to probe.
        client: Configured VLLMClient.
        n_runs: Repeated queries per profile.
        query_interval_seconds: Minimum pause between consecutive runs.
        temperature: Sampling temperature (must not be 0.0).
        render_fn: Prompt rendering callable (render_user_prompt signature).
        system_prompt: Constant system prompt string.

    Returns:
        Long-format DataFrame: id, hypothesis, run, p_hat, valid.
    """
    prompt_list: list[dict] = []
    for _, row in stab_df.iterrows():
        profile_id = row.get("id", row.name)
        for hyp_name in active_hypotheses:
            user_prompt = render_fn(row, hyp_name)
            prompt_list.append({
                "profile_id": profile_id,
                "hypothesis": hyp_name,
                "system": system_prompt,
                "user": user_prompt,
            })

    async def _run_one_pass(run_idx: int) -> list[dict]:
        """Fire all (profile × hypothesis) pairs for one run concurrently.

        Uses query_at_temperature_async (no retry policy) so the explicit
        temperature is honoured and parse-failure retries at temp=0.0
        do not suppress real stochastic variation.
        """
        async def _one(p: dict) -> dict:
            resp = await client.query_at_temperature_async(
                p["system"], p["user"], temperature,
            )
            return {
                "id": p["profile_id"],
                "hypothesis": p["hypothesis"],
                "run": run_idx,
                "p_hat": resp.p_hat,
                "valid": resp.valid,
            }

        return list(await asyncio.gather(*[_one(p) for p in prompt_list]))

    all_records: list[dict] = []
    for run_idx in range(n_runs):
        if run_idx > 0:
            time.sleep(query_interval_seconds)
        logger.info("Stability probe: run %d / %d ...", run_idx + 1, n_runs)
        records = asyncio.run(_run_one_pass(run_idx))
        all_records.extend(records)

    return pd.DataFrame(all_records)


def compute_stability_metrics(stability_df: pd.DataFrame) -> dict:
    """Aggregate stability results into spec-required metrics.

    MAD is computed in probability-point (pp) units (0-100 scale).

    Args:
        stability_df: Output of run_stability_probe (long format).

    Returns:
        Dict with mean_mad, p90_mad, share thresholds, per-hypothesis
        breakdown, and per-profile MAD Series.
    """
    df = stability_df[stability_df["valid"]].copy()
    df["p_pp"] = df["p_hat"] * 100.0

    profile_hyp_mad = (
        df.groupby(["id", "hypothesis"])["p_pp"]
        .apply(lambda x: float(np.mean(np.abs(x - x.mean()))))
        .reset_index(name="mad_pp")
    )

    def _threshold_shares(mad_series: pd.Series) -> dict:
        n = len(mad_series)
        if n == 0:
            return {
                "mean_mad": float("nan"), "p90_mad": float("nan"),
                "share_acceptable": float("nan"), "share_moderate": float("nan"),
                "share_failed": float("nan"),
            }
        return {
            "mean_mad": float(mad_series.mean()),
            "p90_mad": float(mad_series.quantile(0.90)),
            "share_acceptable": float((mad_series < MAD_ACCEPTABLE).mean()),
            "share_moderate": float(
                ((mad_series >= MAD_ACCEPTABLE) & (mad_series <= MAD_MODERATE)).mean()
            ),
            "share_failed": float((mad_series > MAD_MODERATE).mean()),
        }

    global_stats = _threshold_shares(profile_hyp_mad["mad_pp"])
    per_hyp: dict[str, dict] = {
        str(hyp): _threshold_shares(grp["mad_pp"])
        for hyp, grp in profile_hyp_mad.groupby("hypothesis")
    }
    per_profile = profile_hyp_mad.groupby("id")["mad_pp"].mean()

    return {**global_stats, "per_hypothesis": per_hyp, "per_profile": per_profile}
