"""
Decision tree framework for the GSS preliminary analysis.

Implements the four tree types specified in §8 of the GSS prelim spec
(per §8 of the GSS prelim spec):

    Residual tree          — Signed residual ~ prompt features.
    LLM implicit tree      — Raw p_hat ~ prompt features.
    GSS outcome tree       — Observed y ~ full GSS feature set.
    Cross-hypothesis error — Mean |residual| per profile ~ union of prompt features.

All trees share the same CART hyperparameters with cost-complexity pruning.
Feature sets are strictly controlled: residual and implicit trees see only
what the LLM saw; the outcome tree sees the full GSS feature set.


"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any
import math

import matplotlib
matplotlib.use("Agg")  # Non-interactive backend for server environments.
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import cross_val_score
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor, plot_tree

logger = logging.getLogger(__name__)


_FIGURE_DPI = 180

_TREE_LABELS = {
    "age": "Age",
    "gender_bin": "Gender",
    "educ_years": "Education (years)",
    "income": "Income",
    "wordsum": "Wordsum score",
    "capability_bin": "Perceived capability",
    "confidence_level": "Confidence level",
    "overconfident_flag": "Overconfident",
    "confinan_level": "Financial confidence",
    "race": "Race",
    "marital": "Marital status",
    "wrkstat": "Work status",
    "region": "Region",
    "relig": "Religion",
    "partyid": "Party identification",
    "polviews": "Political views",
    "age_bin": "Age group",
    "income_tert": "Income tertile",
    "educ_bin": "Education group",
}


def _pretty_feature_name(name: str) -> str:
    return _TREE_LABELS.get(name, name.replace("_", " ").title())


def _infer_tree_subtitle(tree: Any) -> str:
    criterion = getattr(tree, "criterion", "")
    depth = getattr(tree, "get_depth", lambda: None)()
    leaves = getattr(tree, "get_n_leaves", lambda: None)()
    pieces = []
    if criterion:
        pieces.append(f"Criterion: {criterion}")
    if depth is not None:
        pieces.append(f"Depth: {depth}")
    if leaves is not None:
        pieces.append(f"Leaves: {leaves}")
    return " • ".join(pieces)



@dataclass
class TreeResult:
    """Fitted tree with its summary statistics."""

    tree_type: str               # "residual", "implicit", "outcome", "cross_error"
    hypothesis: str              # Hypothesis name, or "global" for cross-error tree.
    n_samples: int
    n_leaves: int
    worst_leaf_rule: str         # Text description of the worst-case leaf.
    worst_leaf_mean: float       # Mean of the target in the worst leaf.
    worst_leaf_n: int
    leaf_summary: pd.DataFrame   # One row per leaf.
    feature_importance: pd.Series
    figure_path: str | None      # Path to the saved tree figure, if saved.
    fitted_tree: Any = field(default=None)  # Fitted sklearn estimator (for pickling / replay).


def _select_alpha(
    X: np.ndarray,
    y: np.ndarray,
    is_classifier: bool,
    cv_folds: int,
    max_depth: int,
    min_samples_leaf: int,
) -> float:
    """
    Select the cost-complexity pruning alpha via cross-validation.

    Fits an unpruned tree to get the candidate alphas, then evaluates each
    via CV and picks the largest alpha that does not meaningfully hurt
    performance.

    Args:
        X: Feature matrix.
        y: Target vector.
        is_classifier: True for classification trees, False for regression.
        cv_folds: Number of CV folds.
        max_depth: Tree depth constraint.
        min_samples_leaf: Minimum leaf size.

    Returns:
        Selected ccp_alpha value.
    """
    TreeClass = DecisionTreeClassifier if is_classifier else DecisionTreeRegressor
    base = TreeClass(max_depth=max_depth, min_samples_leaf=min_samples_leaf, random_state=42)
    path = base.cost_complexity_pruning_path(X, y)
    alphas = path.ccp_alphas[:-1]  # Exclude last alpha (trivial tree).

    if len(alphas) == 0:
        return 0.0

    scoring = "f1" if is_classifier else "neg_mean_squared_error"
    best_alpha = 0.0
    best_score = -np.inf

    for alpha in alphas:
        tree = TreeClass(
            max_depth=max_depth,
            min_samples_leaf=min_samples_leaf,
            ccp_alpha=alpha,
            random_state=42,
        )
        try:
            scores = cross_val_score(tree, X, y, cv=cv_folds, scoring=scoring)
            mean_score = scores.mean()
            if mean_score > best_score:
                best_score = mean_score
                best_alpha = alpha
        except Exception:
            continue

    return float(best_alpha)


def _fit_regression_tree(
    X: np.ndarray,
    y: np.ndarray,
    feature_names: list[str],
    max_depth: int,
    min_samples_leaf: int,
    cv_folds: int,
) -> DecisionTreeRegressor:
    """Fit a CART regression tree with cross-validated cost-complexity pruning."""
    alpha = _select_alpha(X, y, False, cv_folds, max_depth, min_samples_leaf)
    tree = DecisionTreeRegressor(
        max_depth=max_depth,
        min_samples_leaf=min_samples_leaf,
        ccp_alpha=alpha,
        random_state=42,
    )
    tree.fit(X, y)
    return tree


def _fit_classification_tree(
    X: np.ndarray,
    y: np.ndarray,
    max_depth: int,
    min_samples_leaf: int,
    cv_folds: int,
) -> DecisionTreeClassifier:
    """Fit a CART classification tree with cross-validated cost-complexity pruning."""
    alpha = _select_alpha(X, y, True, cv_folds, max_depth, min_samples_leaf)
    tree = DecisionTreeClassifier(
        max_depth=max_depth,
        min_samples_leaf=min_samples_leaf,
        ccp_alpha=alpha,
        random_state=42,
    )
    tree.fit(X, y)
    return tree


def _extract_leaf_paths(tree: Any, feature_names: list[str]) -> dict[int, str]:
    """
    Extract the decision path (rule string) for every leaf node.

    Walks the binary tree structure using children_left / children_right arrays.
    Returns a dict mapping leaf_node_id -> human-readable rule string.
    """
    t = tree.tree_
    children_left = t.children_left
    children_right = t.children_right
    feature = t.feature
    threshold = t.threshold

    leaf_paths: dict[int, str] = {}

    def _recurse(node: int, conditions: list[str]) -> None:
        if children_left[node] == children_right[node]:
            leaf_paths[node] = " AND ".join(conditions) if conditions else "(root)"
            return
        fname = feature_names[feature[node]] if feature[node] >= 0 else "?"
        thresh = threshold[node]
        _recurse(children_left[node], conditions + [f"{fname} <= {thresh:.3g}"])
        _recurse(children_right[node], conditions + [f"{fname} > {thresh:.3g}"])

    _recurse(0, [])
    return leaf_paths


def _leaf_summary(
    tree: Any,
    X: np.ndarray,
    y: np.ndarray,
    feature_names: list[str],
    is_classifier: bool,
) -> tuple[pd.DataFrame, str, float, int]:
    """
    Build a per-leaf summary table with decision paths and identify the
    worst-case leaf.

    For regression trees: worst leaf = max |mean|.
    For classification trees: worst leaf = max misclassification rate.

    Returns:
        (summary_df, worst_leaf_rule, worst_leaf_mean, worst_leaf_n)
    """
    leaf_ids = tree.apply(X)
    leaf_paths = _extract_leaf_paths(tree, feature_names)

    rows = []
    for leaf_id in np.unique(leaf_ids):
        mask = leaf_ids == leaf_id
        y_leaf = y[mask]
        rows.append({
            "leaf_id": leaf_id,
            "n": int(mask.sum()),
            "mean": float(np.mean(y_leaf)),
            "std": float(np.std(y_leaf)),
            "abs_mean": float(abs(np.mean(y_leaf))),
            "rule": leaf_paths.get(leaf_id, "unknown"),
        })
    summary = pd.DataFrame(rows).sort_values("abs_mean", ascending=False)

    worst = summary.iloc[0]
    worst_rule = (
        f"Leaf {int(worst['leaf_id'])}: {worst['rule']} "
        f"(n={int(worst['n'])}, mean={worst['mean']:.3f})"
    )
    return summary, worst_rule, float(worst["mean"]), int(worst["n"])


def _encode_categoricals(
    df: pd.DataFrame, cols: list[str]
) -> tuple[np.ndarray, list[str]]:
    """
    Label-encode categorical / string columns for sklearn input.

    Returns the feature matrix and a matching list of feature names.
    """
    parts: list[pd.Series] = []
    names: list[str] = []
    for col in cols:
        if col not in df.columns:
            continue
        s = df[col]
        if s.dtype.name in ("category", "object"):
            encoded = s.astype("category").cat.codes.astype(float)
            encoded[s.isna()] = np.nan
            parts.append(encoded)
        else:
            parts.append(s.astype(float))
        names.append(col)

    if not parts:
        raise ValueError("No usable feature columns found.")

    X = pd.concat(parts, axis=1).to_numpy(dtype=float)
    return X, names


def _save_figure(tree: Any, feature_names: list[str], title: str, path: str) -> None:
    """Render and save a presentation-ready tree diagram as PNG."""
    try:
        depth = max(1, tree.get_depth())
        leaves = max(2, tree.get_n_leaves())
        fig_w = min(30, max(16, 3.2 * depth + 4))
        fig_h = min(18, max(8, 1.35 * math.sqrt(leaves) + 5))

        pretty_names = [_pretty_feature_name(name) for name in feature_names]
        fig, ax = plt.subplots(figsize=(fig_w, fig_h))
        plot_tree(
            tree,
            feature_names=pretty_names,
            filled=True,
            rounded=True,
            impurity=True,
            proportion=False,
            precision=2,
            ax=ax,
            fontsize=max(9, 13 - depth // 2),
        )
        ax.set_title(title, fontsize=15, pad=16, loc="left")
        subtitle = _infer_tree_subtitle(tree)
        if subtitle:
            ax.text(0.0, 1.01, subtitle, transform=ax.transAxes, ha="left", va="bottom", fontsize=10, color="0.35")
        fig.text(
            0.01, 0.01,
            "Node colors indicate the model prediction level within each split.",
            ha="left", va="bottom", fontsize=9, color="0.35"
        )
        fig.tight_layout(rect=(0, 0.03, 1, 0.98))
        fig.savefig(path, dpi=_FIGURE_DPI, bbox_inches="tight")
        plt.close(fig)
    except Exception as exc:
        logger.warning("Failed to save tree figure %s: %s", path, exc)


# ── Public tree-fitting functions ──────────────────────────────────────────────

def fit_residual_tree(
    df: pd.DataFrame,
    outcome_col: str,
    p_hat_col: str,
    prompt_feature_cols: list[str],
    hypothesis: str,
    tree_cfg: dict,
    figures_dir: str,
) -> TreeResult:
    """
    Fit a regression tree on the signed residual (p_hat − y).

    Features are restricted to the prompt feature set — only what the LLM saw
    can explain the LLM's errors.

    Args:
        df: DataFrame with outcome and p_hat columns.
        outcome_col: Binary outcome column name.
        p_hat_col: Predicted probability column name.
        prompt_feature_cols: Columns included in the LLM prompt for this hypothesis.
        hypothesis: Hypothesis name (for labelling).
        tree_cfg: Dict with max_depth, min_samples_leaf, cv_folds.
        figures_dir: Directory for saving the tree PNG.

    Returns:
        TreeResult with ``fitted_tree`` set to the sklearn estimator.
    """
    sub = df[[outcome_col, p_hat_col] + prompt_feature_cols].dropna()
    y_true = sub[outcome_col].to_numpy(float)
    p_hat = sub[p_hat_col].to_numpy(float)
    residuals = p_hat - y_true

    X, names = _encode_categoricals(sub, prompt_feature_cols)
    valid_mask = ~np.isnan(X).any(axis=1)
    X, residuals = X[valid_mask], residuals[valid_mask]

    tree = _fit_regression_tree(
        X, residuals, names,
        tree_cfg["max_depth"], tree_cfg["min_samples_leaf"], tree_cfg["cv_folds"],
    )
    summary, worst_rule, worst_mean, worst_n = _leaf_summary(tree, X, residuals, names, False)
    importance = pd.Series(tree.feature_importances_, index=names).sort_values(ascending=False)

    fig_path = f"{figures_dir}/tree_residual_{hypothesis}.png"
    _save_figure(tree, names, f"Residual Tree — {hypothesis}", fig_path)

    return TreeResult(
        tree_type="residual", hypothesis=hypothesis,
        n_samples=len(X), n_leaves=tree.get_n_leaves(),
        worst_leaf_rule=worst_rule, worst_leaf_mean=worst_mean, worst_leaf_n=worst_n,
        leaf_summary=summary, feature_importance=importance,
        figure_path=fig_path, fitted_tree=tree,
    )


def fit_implicit_decision_tree(
    df: pd.DataFrame,
    p_hat_col: str,
    prompt_feature_cols: list[str],
    hypothesis: str,
    tree_cfg: dict,
    figures_dir: str,
) -> TreeResult:
    """
    Fit a regression tree on raw p_hat to reverse-engineer the LLM's decision logic.

    Args:
        df: DataFrame with p_hat and prompt feature columns.
        p_hat_col: Predicted probability column (continuous target).
        prompt_feature_cols: Columns in the LLM prompt for this hypothesis.
        hypothesis: Hypothesis name.
        tree_cfg: Tree hyperparameters.
        figures_dir: Directory for figures.

    Returns:
        TreeResult with ``fitted_tree`` set to the sklearn estimator.
    """
    sub = df[[p_hat_col] + prompt_feature_cols].dropna()
    p_hat = sub[p_hat_col].to_numpy(float)
    X, names = _encode_categoricals(sub, prompt_feature_cols)
    valid_mask = ~np.isnan(X).any(axis=1)
    X, p_hat = X[valid_mask], p_hat[valid_mask]

    tree = _fit_regression_tree(
        X, p_hat, names,
        tree_cfg["max_depth"], tree_cfg["min_samples_leaf"], tree_cfg["cv_folds"],
    )
    summary, worst_rule, worst_mean, worst_n = _leaf_summary(tree, X, p_hat, names, False)
    importance = pd.Series(tree.feature_importances_, index=names).sort_values(ascending=False)

    fig_path = f"{figures_dir}/tree_implicit_{hypothesis}.png"
    _save_figure(tree, names, f"LLM Implicit Decision Tree — {hypothesis}", fig_path)

    return TreeResult(
        tree_type="implicit", hypothesis=hypothesis,
        n_samples=len(X), n_leaves=tree.get_n_leaves(),
        worst_leaf_rule=worst_rule, worst_leaf_mean=worst_mean, worst_leaf_n=worst_n,
        leaf_summary=summary, feature_importance=importance,
        figure_path=fig_path, fitted_tree=tree,
    )


def fit_outcome_tree(
    df: pd.DataFrame,
    outcome_col: str,
    full_feature_cols: list[str],
    hypothesis: str,
    tree_cfg: dict,
    figures_dir: str,
) -> TreeResult:
    """
    Fit a classification tree on the observed GSS outcome using the full feature set.

    Variables selected that are absent from the prompt feature set identify
    predictors the simulation is blind to.

    Args:
        df: DataFrame with outcome and all available GSS features.
        outcome_col: Binary outcome column.
        full_feature_cols: All theoretically relevant GSS columns (including
            variables never shown to the LLM).
        hypothesis: Hypothesis name.
        tree_cfg: Tree hyperparameters.
        figures_dir: Directory for figures.

    Returns:
        TreeResult with ``fitted_tree`` set to the sklearn estimator.
    """
    # Only use features with sufficient non-NaN coverage in this hypothesis frame.
    # Ballot-specific columns may be entirely NaN for some hypothesis subsets.
    usable_cols = [
        c for c in full_feature_cols
        if c in df.columns and df[c].notna().mean() >= 0.5
    ]
    if not usable_cols:
        logger.warning("No usable features for outcome tree (%s).", hypothesis)
        # Return a minimal tree on the full dataset.
        usable_cols = [c for c in full_feature_cols if c in df.columns and df[c].notna().any()]

    sub = df[[outcome_col] + usable_cols].dropna()
    y = sub[outcome_col].to_numpy(int)
    X, names = _encode_categoricals(sub, usable_cols)
    valid_mask = ~np.isnan(X).any(axis=1)
    X, y = X[valid_mask], y[valid_mask]

    tree = _fit_classification_tree(
        X, y,
        tree_cfg["max_depth"], tree_cfg["min_samples_leaf"], tree_cfg["cv_folds"],
    )
    summary, worst_rule, worst_mean, worst_n = _leaf_summary(tree, X, y.astype(float), names, True)
    importance = pd.Series(tree.feature_importances_, index=names).sort_values(ascending=False)

    fig_path = f"{figures_dir}/tree_outcome_{hypothesis}.png"
    _save_figure(tree, names, f"GSS Outcome Tree — {hypothesis}", fig_path)

    return TreeResult(
        tree_type="outcome", hypothesis=hypothesis,
        n_samples=len(X), n_leaves=tree.get_n_leaves(),
        worst_leaf_rule=worst_rule, worst_leaf_mean=worst_mean, worst_leaf_n=worst_n,
        leaf_summary=summary, feature_importance=importance,
        figure_path=fig_path, fitted_tree=tree,
    )


def fit_cross_hypothesis_error_tree(
    df: pd.DataFrame,
    residual_cols: dict[str, str],
    all_prompt_feature_cols: list[str],
    tree_cfg: dict,
    figures_dir: str,
    min_hypotheses: int = 2,
) -> TreeResult | None:
    """
    Fit a regression tree on mean |residual| across all Type A hypotheses.

    Identifies profile types that are systematically hard across the entire
    hypothesis set.

    Args:
        df: DataFrame with a residual column per hypothesis and prompt features.
        residual_cols: Mapping {hypothesis_name: residual_column_name}.
        all_prompt_feature_cols: Union of prompt feature sets across all hypotheses.
        tree_cfg: Tree hyperparameters.
        figures_dir: Directory for figures.
        min_hypotheses: Minimum hypotheses with non-NaN residuals to include a
            profile.

    Returns:
        TreeResult with ``fitted_tree`` set, or None if insufficient data.
    """
    residual_frame = df[list(residual_cols.values())].copy()
    mean_abs_residual = residual_frame.abs().mean(axis=1)
    n_valid = residual_frame.notna().sum(axis=1)
    include_mask = n_valid >= min_hypotheses

    if include_mask.sum() < tree_cfg["min_samples_leaf"] * 2:
        logger.warning("Insufficient profiles for cross-hypothesis error tree.")
        return None

    sub = df[include_mask].copy()
    target = mean_abs_residual[include_mask].to_numpy(float)

    # Only use features with sufficient non-NaN coverage in the included profiles.
    # Ballot-specific columns (e.g. confinan_level, overconfident_flag) may be NaN
    # for entire ballot subsets; including them would drop most rows.
    usable_cols = [
        c for c in all_prompt_feature_cols
        if c in sub.columns and sub[c].notna().mean() >= 0.5
    ]
    if not usable_cols:
        logger.warning("No usable feature columns for cross-hypothesis error tree.")
        return None

    X, names = _encode_categoricals(sub, usable_cols)
    valid_mask = ~np.isnan(X).any(axis=1) & ~np.isnan(target)
    X, target = X[valid_mask], target[valid_mask]

    tree = _fit_regression_tree(
        X, target, names,
        tree_cfg["max_depth"], tree_cfg["min_samples_leaf"], tree_cfg["cv_folds"],
    )
    summary, worst_rule, worst_mean, worst_n = _leaf_summary(tree, X, target, names, False)
    importance = pd.Series(tree.feature_importances_, index=names).sort_values(ascending=False)

    fig_path = f"{figures_dir}/tree_cross_hypothesis_error.png"
    _save_figure(tree, names, "Cross-Hypothesis Error Tree", fig_path)

    return TreeResult(
        tree_type="cross_error", hypothesis="global",
        n_samples=len(X), n_leaves=tree.get_n_leaves(),
        worst_leaf_rule=worst_rule, worst_leaf_mean=worst_mean, worst_leaf_n=worst_n,
        leaf_summary=summary, feature_importance=importance,
        figure_path=fig_path, fitted_tree=tree,
    )
