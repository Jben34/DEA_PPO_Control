"""
Type A evaluation metrics for the GSS preliminary analysis.

Implements the five-metric suite specified in §7 of the GSS prelim spec
(per §7 of the GSS prelim spec).  Each metric targets a
distinct failure mode; together they give a non-redundant diagnostic profile.

All functions operate on numpy/pandas arrays and return plain Python scalars
or dicts.  

Metric      Failure mode detected
──────────  ─────────────────────────────────────────────────────────
F1          Threshold-level classification error (threshold fixed at 0.5)
AUC-ROC     Discriminative failure independent of threshold
ECE         Miscalibration (stated probability ≠ empirical frequency)
TVD         Distributional shape mismatch within a (sub)group
Sigma ratio Central-tendency compression (most common LLM failure mode)

Bootstrap CIs (§7.4):
- 95% percentile CIs, B=2000 resamples, on all five core metrics.
- For subgroup comparisons the CI is on the difference (cell − complement),
  not on the cell-level metric directly.
- Cells with n < CI_MIN_N are reported but flagged as descriptive_only=True;
  their CIs are NaN.
- LLM stochasticity (H_stability MAD) is reported separately and is never
  folded into these metric CIs.
"""

from __future__ import annotations

import logging
from functools import partial
from typing import Any, Callable

import numpy as np
import pandas as pd
from sklearn.metrics import f1_score, roc_auc_score

logger = logging.getLogger(__name__)

# Minimum n for any metric computation (absolute floor).
_METRIC_MIN_N = 20
# Minimum n for CI computation; below this metrics are flagged descriptive_only.
CI_MIN_N = 50


# ── Core metric functions ──────────────────────────────────────────────────────

def compute_f1(y_true: np.ndarray, p_hat: np.ndarray, threshold: float = 0.5) -> float:
    """
    Binary F1 at a fixed classification threshold.

    Args:
        y_true: Observed binary outcomes (0/1).
        p_hat: Predicted probabilities in [0, 1].
        threshold: Decision threshold (spec fixes this at 0.5).

    Returns:
        F1 score, or NaN if the computation is not possible.
    """
    y_pred = (p_hat >= threshold).astype(int)
    if len(np.unique(y_true)) < 2:
        return float("nan")
    return float(f1_score(y_true, y_pred, zero_division=0))


def compute_auc_roc(y_true: np.ndarray, p_hat: np.ndarray) -> float:
    """
    AUC-ROC: rank-ordering quality independent of decision threshold.

    Args:
        y_true: Observed binary outcomes.
        p_hat: Predicted probabilities.

    Returns:
        AUC-ROC score, or NaN if there is only one class in y_true.
    """
    if len(np.unique(y_true)) < 2:
        return float("nan")
    return float(roc_auc_score(y_true, p_hat))


def compute_ece(
    y_true: np.ndarray,
    p_hat: np.ndarray,
    n_bins: int = 10,
) -> float:
    """
    Expected Calibration Error using equal-width bins on [0, 1].

    For each bin b:  ECE += (n_b / N) * |mean(p_hat)_b - mean(y)_b|

    Implemented directly to guarantee correct bin-count weighting and to avoid
    the alignment issues that arise when calibration_curve silently drops empty
    bins.

    Args:
        y_true: Observed binary outcomes.
        p_hat: Predicted probabilities.
        n_bins: Number of equal-width calibration bins.

    Returns:
        ECE in [0, 1], or NaN if computation fails.
    """
    try:
        bin_edges = np.linspace(0.0, 1.0, n_bins + 1)
        bin_idx = np.clip(np.digitize(p_hat, bin_edges[1:-1]), 0, n_bins - 1)
        ece = 0.0
        n = len(y_true)
        for b in range(n_bins):
            mask = bin_idx == b
            n_b = mask.sum()
            if n_b == 0:
                continue
            ece += (n_b / n) * abs(float(np.mean(p_hat[mask])) - float(np.mean(y_true[mask])))
        return float(ece)
    except Exception as exc:
        logger.debug("ECE computation failed: %s", exc)
        return float("nan")


def compute_tvd(y_true: np.ndarray, p_hat: np.ndarray) -> float:
    """
    Total Variation Distance between the predicted and observed distributions.

    For binary outcomes, TVD = |mean(p_hat) − mean(y_true)|.

    Args:
        y_true: Observed binary outcomes.
        p_hat: Predicted probabilities.

    Returns:
        TVD in [0, 1].
    """
    return float(abs(np.mean(p_hat) - np.mean(y_true)))


def compute_sigma_ratio(y_true: np.ndarray, p_hat: np.ndarray) -> float:
    """
    Sigma ratio: std(p_hat) / std(y_true).

    Diagnoses central-tendency compression (ratio << 1) or over-dispersion (> 1).

    Args:
        y_true: Observed binary outcomes.
        p_hat: Predicted probabilities.

    Returns:
        Sigma ratio, or NaN if std(y_true) ≈ 0.
    """
    sigma_llm = float(np.std(p_hat))
    sigma_data = float(np.std(y_true.astype(float)))
    if sigma_data < 1e-9:
        return float("nan")
    return sigma_llm / sigma_data


# ── Bootstrap CI helpers ───────────────────────────────────────────────────────

def _bootstrap_ci(
    y_true: np.ndarray,
    p_hat: np.ndarray,
    metric_fn: Callable[[np.ndarray, np.ndarray], float],
    n_bootstrap: int,
    rng: np.random.Generator,
) -> tuple[float, float]:
    """
    95% percentile bootstrap CI for a scalar metric (2.5th–97.5th percentile).

    Args:
        y_true: Observed outcomes.
        p_hat: Predicted probabilities.
        metric_fn: Function (y_true, p_hat) -> float.
        n_bootstrap: Number of bootstrap resamples.
        rng: NumPy random generator (caller controls seed for reproducibility).

    Returns:
        (ci_lo, ci_hi) tuple; NaN on insufficient valid bootstrap draws.
    """
    n = len(y_true)
    boot_vals: list[float] = []
    for _ in range(n_bootstrap):
        idx = rng.integers(0, n, size=n)
        try:
            v = metric_fn(y_true[idx], p_hat[idx])
            if not np.isnan(v):
                boot_vals.append(v)
        except Exception:
            continue
    if len(boot_vals) < max(10, n_bootstrap // 100):
        return float("nan"), float("nan")
    arr = np.array(boot_vals)
    return float(np.percentile(arr, 2.5)), float(np.percentile(arr, 97.5))


def _bootstrap_diff_ci(
    y_cell: np.ndarray,
    p_cell: np.ndarray,
    y_comp: np.ndarray,
    p_comp: np.ndarray,
    metric_fn: Callable[[np.ndarray, np.ndarray], float],
    n_bootstrap: int,
    rng: np.random.Generator,
) -> tuple[float, float]:
    """
    95% percentile bootstrap CI on (metric_cell − metric_complement).

    Cell and complement are resampled independently on each iteration.

    Args:
        y_cell, p_cell: Outcome and predictions for the target subgroup cell.
        y_comp, p_comp: Outcome and predictions for the complement (all other rows).
        metric_fn: Scalar metric function.
        n_bootstrap: Number of resamples.
        rng: NumPy random generator.

    Returns:
        (ci_lo, ci_hi) on the difference; NaN on insufficient valid draws.
    """
    n_c, n_k = len(y_cell), len(y_comp)
    diffs: list[float] = []
    for _ in range(n_bootstrap):
        ic = rng.integers(0, n_c, size=n_c)
        ik = rng.integers(0, n_k, size=n_k)
        try:
            vc = metric_fn(y_cell[ic], p_cell[ic])
            vk = metric_fn(y_comp[ik], p_comp[ik])
            if not (np.isnan(vc) or np.isnan(vk)):
                diffs.append(vc - vk)
        except Exception:
            continue
    if len(diffs) < max(10, n_bootstrap // 100):
        return float("nan"), float("nan")
    arr = np.array(diffs)
    return float(np.percentile(arr, 2.5)), float(np.percentile(arr, 97.5))


def _metric_fns(n_bins_ece: int) -> list[tuple[str, Callable]]:
    """Return the ordered list of (name, fn) pairs for the five core metrics."""
    return [
        ("f1", compute_f1),
        ("auc_roc", compute_auc_roc),
        ("ece", partial(compute_ece, n_bins=n_bins_ece)),
        ("tvd", compute_tvd),
        ("sigma_ratio", compute_sigma_ratio),
    ]


def _nan_ci_block(metric_names: list[str], suffix: str = "") -> dict[str, float]:
    """Return NaN entries for all CI keys."""
    return {
        f"{name}{suffix}": float("nan")
        for name in metric_names
        for suffix in (f"{suffix}_ci_lo", f"{suffix}_ci_hi")
        if True  # evaluated below
    }


# ── Per-hypothesis full metric suite ──────────────────────────────────────────

def compute_all_metrics(
    y_true: np.ndarray,
    p_hat: np.ndarray,
    n_bins_ece: int = 10,
    min_n: int = _METRIC_MIN_N,
    n_bootstrap: int = 2000,
    rng_seed: int = 0,
) -> dict[str, Any]:
    """
    Compute the full five-metric suite with 95% bootstrap CIs.

    Returns NaN for all metrics if the sample is below min_n.  Returns point
    estimates but no CIs (ci=NaN, descriptive_only=True) for samples below
    CI_MIN_N.

    Args:
        y_true: Observed binary outcomes.
        p_hat: Predicted probabilities.
        n_bins_ece: Number of ECE calibration bins.
        min_n: Absolute floor; returns all-NaN below this.
        n_bootstrap: Bootstrap resamples for CIs (0 to skip CI computation).
        rng_seed: RNG seed for bootstrap reproducibility.

    Returns:
        Dict with keys: f1, auc_roc, ece, tvd, sigma_ratio (point estimates),
        {metric}_ci_lo / {metric}_ci_hi (95% CIs), n, descriptive_only.
    """
    metric_names = ["f1", "auc_roc", "ece", "tvd", "sigma_ratio"]
    nan_cis = {k: float("nan") for name in metric_names for k in (f"{name}_ci_lo", f"{name}_ci_hi")}

    mask = ~(np.isnan(y_true) | np.isnan(p_hat))
    y_true, p_hat = y_true[mask], p_hat[mask]

    if len(y_true) < min_n:
        result: dict[str, Any] = {k: float("nan") for k in metric_names}
        result.update(nan_cis)
        result["n"] = int(len(y_true))
        result["descriptive_only"] = True
        return result

    fns = _metric_fns(n_bins_ece)
    result = {
        "f1": compute_f1(y_true, p_hat),
        "auc_roc": compute_auc_roc(y_true, p_hat),
        "ece": compute_ece(y_true, p_hat, n_bins=n_bins_ece),
        "tvd": compute_tvd(y_true, p_hat),
        "sigma_ratio": compute_sigma_ratio(y_true, p_hat),
        "n": int(len(y_true)),
        "descriptive_only": len(y_true) < CI_MIN_N,
    }

    if len(y_true) >= CI_MIN_N and n_bootstrap > 0:
        rng = np.random.default_rng(rng_seed)
        for name, fn in fns:
            lo, hi = _bootstrap_ci(y_true, p_hat, fn, n_bootstrap, rng)
            result[f"{name}_ci_lo"] = lo
            result[f"{name}_ci_hi"] = hi
    else:
        result.update(nan_cis)

    return result


# ── Subgroup evaluation ────────────────────────────────────────────────────────

def compute_subgroup_metrics(
    df: pd.DataFrame,
    outcome_col: str,
    p_hat_col: str,
    subgroup_col: str,
    n_bins_ece: int = 10,
    min_n: int = _METRIC_MIN_N,
    n_bootstrap: int = 2000,
    rng_seed: int = 0,
) -> pd.DataFrame:
    """
    Compute the full metric suite for each level of a subgroup column.

    Each cell also receives a CI on the difference (cell metric − complement
    metric) for all five core metrics, as specified in §7.4.

    Args:
        df: DataFrame with outcome, p_hat, and subgroup columns.
        outcome_col: Name of the binary outcome column.
        p_hat_col: Name of the predicted probability column.
        subgroup_col: Categorical column defining the subgroup splits.
        n_bins_ece: ECE bins.
        min_n: Minimum per-group n for metric reporting.
        n_bootstrap: Bootstrap resamples (0 to skip CIs).
        rng_seed: RNG seed for reproducibility.

    Returns:
        DataFrame with one row per subgroup level, columns for each metric,
        CI bounds, diff CI bounds, subgroup metadata, and descriptive_only flag.
    """
    metric_names = ["f1", "auc_roc", "ece", "tvd", "sigma_ratio"]
    fns = _metric_fns(n_bins_ece)
    rng = np.random.default_rng(rng_seed)

    rows = []
    for level, grp in df.groupby(subgroup_col, observed=True):
        y = grp[outcome_col].to_numpy(dtype=float)
        p = grp[p_hat_col].to_numpy(dtype=float)
        metrics = compute_all_metrics(
            y, p,
            n_bins_ece=n_bins_ece,
            min_n=min_n,
            n_bootstrap=n_bootstrap,
            rng_seed=rng_seed,
        )

        # Complement = all rows not in this cell.
        comp = df.loc[~df.index.isin(grp.index)]
        y_comp = comp[outcome_col].to_numpy(dtype=float)
        p_comp = comp[p_hat_col].to_numpy(dtype=float)

        # Filter NaN before diff CI.
        m1 = ~(np.isnan(y) | np.isnan(p))
        m2 = ~(np.isnan(y_comp) | np.isnan(p_comp))

        if (
            m1.sum() >= CI_MIN_N
            and m2.sum() >= CI_MIN_N
            and n_bootstrap > 0
        ):
            for name, fn in fns:
                lo, hi = _bootstrap_diff_ci(
                    y[m1], p[m1], y_comp[m2], p_comp[m2], fn, n_bootstrap, rng
                )
                metrics[f"{name}_diff_ci_lo"] = lo
                metrics[f"{name}_diff_ci_hi"] = hi
        else:
            for name in metric_names:
                metrics[f"{name}_diff_ci_lo"] = float("nan")
                metrics[f"{name}_diff_ci_hi"] = float("nan")

        metrics["subgroup_col"] = subgroup_col
        metrics["subgroup_level"] = str(level)
        rows.append(metrics)

    return pd.DataFrame(rows)


def compute_interaction_metrics(
    df: pd.DataFrame,
    outcome_col: str,
    p_hat_col: str,
    col_a: str,
    col_b: str,
    n_bins_ece: int = 10,
    min_n: int = _METRIC_MIN_N,
    n_bootstrap: int = 2000,
    rng_seed: int = 0,
) -> pd.DataFrame:
    """
    Compute the full metric suite for each cell of a two-way interaction.

    Args:
        df: DataFrame with outcome, p_hat, and subgroup columns.
        outcome_col: Binary outcome column name.
        p_hat_col: Predicted probability column name.
        col_a: First interaction axis (categorical).
        col_b: Second interaction axis (categorical).
        n_bins_ece: ECE bins.
        min_n: Minimum per-cell n.
        n_bootstrap: Bootstrap resamples (0 to skip CIs).
        rng_seed: RNG seed.

    Returns:
        DataFrame with one row per (col_a level, col_b level) with metric
        columns, CI bounds, and descriptive_only flag.
    """
    rows = []
    for (level_a, level_b), grp in df.groupby([col_a, col_b], observed=True):
        y = grp[outcome_col].to_numpy(dtype=float)
        p = grp[p_hat_col].to_numpy(dtype=float)
        metrics = compute_all_metrics(
            y, p,
            n_bins_ece=n_bins_ece,
            min_n=min_n,
            n_bootstrap=n_bootstrap,
            rng_seed=rng_seed,
        )
        metrics[col_a] = str(level_a)
        metrics[col_b] = str(level_b)
        rows.append(metrics)
    return pd.DataFrame(rows)
