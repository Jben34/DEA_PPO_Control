"""
Artifact persistence for the GSS 2024 Phase 1 preliminary analysis.

Saves all derived analytical objects so the analysis layer is fully
replayable without re-querying the LLM.
"""

from __future__ import annotations

import json
import logging
import pickle
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .trees import TreeResult

logger = logging.getLogger(__name__)


def save_artifacts(results: dict[str, Any], interim_dir: str) -> None:
    """Persist all derived analytical artifacts under a versioned subdirectory.

    Args:
        results: Return value of run_phase1().
        interim_dir: Base interim data directory.
    """
    base = Path(interim_dir) / "artifacts_2024"
    base.mkdir(parents=True, exist_ok=True)

    # ── Metrics ───────────────────────────────────────────────────────────────
    (base / "metrics.json").write_text(
        json.dumps(results["metrics"], indent=2, default=_json_default),
        encoding="utf-8",
    )

    for hyp, df in results.get("subgroup_metrics", {}).items():
        df.to_parquet(base / f"subgroup_metrics_{hyp}.parquet", index=False)

    for hyp, df in results.get("interaction_metrics", {}).items():
        df.to_parquet(base / f"interaction_metrics_{hyp}.parquet", index=False)

    # ── Stability ─────────────────────────────────────────────────────────────
    stab = dict(results["stability_metrics"])
    per_profile = stab.pop("per_profile", None)
    (base / "stability_metrics.json").write_text(
        json.dumps(
            {**{k: v for k, v in stab.items() if k != "per_hypothesis"},
             "per_hypothesis": results["stability_metrics"].get("per_hypothesis", {})},
            indent=2,
            default=_json_default,
        ),
        encoding="utf-8",
    )
    if per_profile is not None:
        per_profile.to_frame("mad_pp").to_parquet(base / "stability_per_profile.parquet")

    # ── Trees ─────────────────────────────────────────────────────────────────
    for hyp, tree_result in results.get("residual_trees", {}).items():
        _save_tree_result(tree_result, base, f"residual_{hyp}")
    for hyp, tree_result in results.get("implicit_trees", {}).items():
        _save_tree_result(tree_result, base, f"implicit_{hyp}")
    for hyp, tree_result in results.get("outcome_trees", {}).items():
        _save_tree_result(tree_result, base, f"outcome_{hyp}")
    if results.get("cross_error_tree") is not None:
        _save_tree_result(results["cross_error_tree"], base, "cross_error")

    # ── Type B ─────────────────────────────────────────────────────────────────
    for b_name, b_result in results.get("type_b_results", {}).items():
        scalar = {k: v for k, v in b_result.items() if isinstance(v, (int, float, str, bool))}
        (base / f"type_b_{b_name}_summary.json").write_text(
            json.dumps(scalar, indent=2, default=_json_default), encoding="utf-8",
        )
        for key in ("subgroup_effects", "interaction_effects"):
            df = b_result.get(key)
            if isinstance(df, pd.DataFrame) and not df.empty:
                df.to_parquet(base / f"type_b_{b_name}_{key}.parquet", index=False)
        effect_tree = b_result.get("effect_tree")
        if effect_tree is not None:
            _save_tree_result(effect_tree, base, f"effect_heterogeneity_{b_name}")

    # ── Consistency ───────────────────────────────────────────────────────────
    cons = results["consistency"]
    # Save scalar-only summary (filter out DataFrames and Series at all levels).
    def _is_json_safe(v: Any) -> bool:
        return isinstance(v, (int, float, str, bool, type(None)))

    cons_scalar = {k: v for k, v in cons.items() if _is_json_safe(v)}
    cons_scalar["pairs"] = []
    for pair_result in cons.get("pairs", []):
        pair_scalar = {k: v for k, v in pair_result.items() if _is_json_safe(v)}
        cons_scalar["pairs"].append(pair_scalar)
    (base / "consistency_summary.json").write_text(
        json.dumps(cons_scalar, indent=2, default=_json_default), encoding="utf-8",
    )
    # Save DataFrames from each pair separately.
    for pair_result in cons.get("pairs", []):
        pair_tag = pair_result.get("pair", "unknown")
        for key in ("r_llm", "r_data", "inconsistency_scores", "inconsistency_flags"):
            val = pair_result.get(key)
            if isinstance(val, pd.DataFrame):
                val.to_parquet(base / f"consistency_{key}_{pair_tag}.parquet")
            elif isinstance(val, pd.Series):
                val.to_frame(key).to_parquet(base / f"consistency_{key}_{pair_tag}.parquet")

    # ── Per-hypothesis merged frames ─────────────────────────────────────────
    for hyp, df in results.get("merged_dfs", {}).items():
        df.to_parquet(base / f"merged_{hyp}.parquet", index=False)

    # ── H_mem ─────────────────────────────────────────────────────────────────
    h_mem = results.get("h_mem_results")
    if h_mem:
        scalar = {k: v for k, v in h_mem.items() if isinstance(v, (int, float, str, bool, type(None), list))}
        (base / "h_mem_summary.json").write_text(
            json.dumps(scalar, indent=2, default=_json_default), encoding="utf-8",
        )
        for key in ("alignment_by_conflict", "accuracy_results", "accuracy_by_conflict"):
            df = h_mem.get(key)
            if isinstance(df, pd.DataFrame) and not df.empty:
                df.to_parquet(base / f"h_mem_{key}.parquet", index=False)

    h_mem_bench = results.get("h_mem_benchmarks")
    if h_mem_bench:
        bench_df = pd.DataFrame({
            "coarse_p": h_mem_bench["coarse_p"],
            "full_p": h_mem_bench["full_p"],
            "conflict_score": h_mem_bench["conflict_score"],
            "conflict_bin": h_mem_bench["conflict_bin"],
        })
        bench_df.to_parquet(base / "h_mem_benchmarks.parquet", index=False)

    logger.info("Artifacts saved → %s", base)


def _save_tree_result(tree_result: TreeResult, base: Path, tag: str) -> None:
    """Pickle the TreeResult and write the leaf summary as parquet."""
    with open(base / f"tree_{tag}.pkl", "wb") as fh:
        pickle.dump(tree_result, fh)
    if tree_result.leaf_summary is not None and len(tree_result.leaf_summary) > 0:
        tree_result.leaf_summary.to_parquet(base / f"tree_{tag}_leaves.parquet", index=False)


def _json_default(obj: Any) -> Any:
    """Fallback JSON serializer for numpy scalars."""
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.ndarray,)):
        return obj.tolist()
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")
