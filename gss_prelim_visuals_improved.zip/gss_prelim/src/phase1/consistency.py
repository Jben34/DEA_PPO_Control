"""
Cross-hypothesis internal consistency analysis.

Implements the cross-hypothesis internal consistency analysis.

Tests whether the LLM's prediction co-occurrence structure across hypotheses
matches the empirical co-occurrence structure in the GSS data.  A genuine
behavioral simulator should reproduce not just per-hypothesis accuracy but
the joint behavioral distribution.

Key outputs:
    R_llm           — Spearman correlation matrix of LLM p_hat values.
    R_data          — Spearman correlation matrix of observed outcomes.
    Frobenius dist  — ||R_llm − R_data||_F  (global consistency score).
    Divergent pairs — Top-N hypothesis pairs by |R_llm − R_data|.
    Inconsistency flags — Profiles with high residual variance across hypotheses.


"""

from __future__ import annotations

import logging

import numpy as np
import pandas as pd
from scipy import stats

logger = logging.getLogger(__name__)


def compute_consistency(
    predictions_wide: pd.DataFrame,
    outcomes_wide: pd.DataFrame,
    over_clustering_threshold: float,
    independence_failure_threshold: float,
    top_n_pairs: int,
    inconsistency_flag_quantile: float,
) -> dict:
    """
    Full cross-hypothesis consistency analysis.

    Args:
        predictions_wide: DataFrame with one column per hypothesis containing p_hat
            (float [0,1]) and one row per profile.
        outcomes_wide: DataFrame with one column per hypothesis containing the observed
            binary outcome (0/1) and one row per profile (same index as predictions_wide).
        over_clustering_threshold: Δ ≥ this value → over-clustering.
        independence_failure_threshold: Δ ≤ this value → independence failure.
        top_n_pairs: Number of most divergent hypothesis pairs to report.
        inconsistency_flag_quantile: Profiles above this quantile of residual-std
            are flagged as inconsistently simulated.

    Returns:
        Dict with keys:
            r_llm           — Spearman correlation matrix (DataFrame).
            r_data          — Spearman correlation matrix (DataFrame).
            frobenius_dist  — Global consistency score (float).
            mean_abs_off_diag — Companion interpretability statistic (float).
            divergent_pairs — List of dicts describing the top-N divergent pairs.
            inconsistency_scores — Per-profile inconsistency score (Series).
            inconsistency_flags  — Boolean Series (True = flagged).
    """
    hypotheses = list(predictions_wide.columns)

    # ── Step 1: Correlation matrices ──────────────────────────────────────────
    r_llm = _spearman_matrix(predictions_wide)
    r_data = _spearman_matrix(outcomes_wide)

    # ── Step 2: Frobenius distance ────────────────────────────────────────────
    diff = r_llm.to_numpy() - r_data.to_numpy()
    frobenius = float(np.sqrt(np.sum(diff ** 2)))
    # Off-diagonal elements only (the diagonal is always 1.0).
    n = len(hypotheses)
    if n > 1:
        off_diag_mask = ~np.eye(n, dtype=bool)
        mean_abs_off_diag = float(np.mean(np.abs(diff[off_diag_mask])))
    else:
        mean_abs_off_diag = float("nan")

    # ── Step 3: Divergent pairs ───────────────────────────────────────────────
    divergent_pairs = _find_divergent_pairs(
        r_llm, r_data, hypotheses,
        over_clustering_threshold, independence_failure_threshold, top_n_pairs,
    )

    # ── Step 4: Profile-level inconsistency flags ─────────────────────────────
    # Residual = p_hat − y for each (profile × hypothesis).
    # Std of residuals across hypotheses measures inconsistency.
    residuals = predictions_wide.to_numpy() - outcomes_wide.to_numpy()
    residual_std = np.nanstd(residuals, axis=1)
    inconsistency_scores = pd.Series(residual_std, index=predictions_wide.index, name="inconsistency_score")
    threshold = float(np.nanquantile(residual_std, inconsistency_flag_quantile))
    inconsistency_flags = inconsistency_scores >= threshold

    return {
        "r_llm": r_llm,
        "r_data": r_data,
        "frobenius_dist": frobenius,
        "mean_abs_off_diag": mean_abs_off_diag,
        "divergent_pairs": divergent_pairs,
        "inconsistency_scores": inconsistency_scores,
        "inconsistency_flags": inconsistency_flags,
    }


# ── Internal helpers ───────────────────────────────────────────────────────────

def _spearman_matrix(wide_df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute pairwise Spearman correlation matrix across columns.

    Missing values are excluded pairwise (scipy.stats.spearmanr default).
    """
    cols = list(wide_df.columns)
    n = len(cols)
    mat = np.eye(n)

    for i in range(n):
        for j in range(i + 1, n):
            col_i = wide_df.iloc[:, i].dropna()
            col_j = wide_df.iloc[:, j].dropna()
            shared_idx = col_i.index.intersection(col_j.index)
            if len(shared_idx) < 10:
                mat[i, j] = mat[j, i] = float("nan")
                continue
            rho, _ = stats.spearmanr(col_i[shared_idx], col_j[shared_idx])
            mat[i, j] = mat[j, i] = float(rho)

    return pd.DataFrame(mat, index=cols, columns=cols)


def _find_divergent_pairs(
    r_llm: pd.DataFrame,
    r_data: pd.DataFrame,
    hypotheses: list[str],
    over_threshold: float,
    under_threshold: float,
    top_n: int,
) -> list[dict]:
    """
    Identify the top-N hypothesis pairs by absolute correlation difference.

    Each pair is labelled as over-clustering, independence-failure, or consistent.
    """
    pairs = []
    n = len(hypotheses)
    for i in range(n):
        for j in range(i + 1, n):
            h_i, h_j = hypotheses[i], hypotheses[j]
            llm_val = float(r_llm.iloc[i, j])
            data_val = float(r_data.iloc[i, j])
            if np.isnan(llm_val) or np.isnan(data_val):
                continue
            delta = llm_val - data_val
            if delta >= over_threshold:
                direction = "over-clustering"
            elif delta <= under_threshold:
                direction = "independence-failure"
            else:
                direction = "consistent"
            pairs.append({
                "h_i": h_i, "h_j": h_j,
                "r_llm": llm_val, "r_data": data_val,
                "delta": delta, "abs_delta": abs(delta),
                "direction": direction,
            })

    # Sort by absolute delta and keep top N.
    pairs.sort(key=lambda x: x["abs_delta"], reverse=True)
    return pairs[:top_n]
