"""
Phase 1 orchestrator for the GSS 2024 preliminary analysis.

Coordinates the full pipeline:
    1. Draw stratified samples per hypothesis (ballot-aware).
    2. Query the LLM for all Type A (profile × hypothesis) pairs.
    3. Query the LLM for Type B pairs (two conditions per profile).
    4. Compute per-hypothesis metrics with bootstrap CIs and subgroup breakdowns.
    5. Run the stability probe (H_stability).
    6. Fit decision trees per hypothesis.
    7. Run cross-hypothesis internal consistency (pairwise by ballot overlap).
    8. Persist all derived artifacts including the full prompt audit trail.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from ..gss.prep import PrepResult
from ..llm.cache import PromptCache
from ..llm.prompts import (
    get_prompt_feature_cols,
    get_system_prompt,
    render_type_b_prompts,
    render_user_prompt,
)
from ..llm.vllm_client import VLLMClient
from ..phase1.artifacts import save_artifacts
from ..phase1.consistency import compute_consistency
from ..phase1.h_mem import analyse_h_mem, train_benchmark_models
from ..phase1.hypotheses import (
    HYPOTHESIS_REGISTRY,
    TYPE_B_REGISTRY,
    UNIVERSAL_SUBGROUP_SPLITS,
    HypothesisSpec,
    TypeBSpec,
)
from ..phase1.metrics import (
    compute_all_metrics,
    compute_interaction_metrics,
    compute_subgroup_metrics,
)
from ..phase1.stability import compute_stability_metrics, run_stability_probe
from ..phase1.trees import (
    fit_cross_hypothesis_error_tree,
    fit_implicit_decision_tree,
    fit_outcome_tree,
    fit_residual_tree,
)

logger = logging.getLogger(__name__)


def draw_stratified_sample(
    df: pd.DataFrame,
    n: int,
    strat_cols: list[str],
    random_seed: int,
) -> pd.DataFrame:
    """Draw a stratified random sample maintaining proportional representation.

    Args:
        df: Source DataFrame.
        n: Target total sample size.
        strat_cols: Columns to stratify on.
        random_seed: RNG seed for reproducibility.

    Returns:
        Sampled DataFrame (may be smaller than n if the source is small).
    """
    if len(df) <= n:
        logger.info("Source size (%d) <= n=%d, using all rows.", len(df), n)
        return df.copy()

    rng = np.random.default_rng(random_seed)
    usable_strat = [c for c in strat_cols if c in df.columns]
    valid = df.dropna(subset=usable_strat).copy() if usable_strat else df.copy()
    if not usable_strat:
        return valid.sample(n=min(n, len(valid)), random_state=random_seed).reset_index(drop=True)

    strat_key = valid[usable_strat].astype(str).apply(lambda r: "_".join(r), axis=1)
    strata, counts = np.unique(strat_key, return_counts=True)
    total = counts.sum()

    indices: list[int] = []
    for stratum, count in zip(strata, counts):
        alloc = max(1, round(n * count / total))
        stratum_idx = valid.index[strat_key == stratum].tolist()
        chosen = rng.choice(stratum_idx, size=min(alloc, len(stratum_idx)), replace=False)
        indices.extend(chosen.tolist())

    # Rounding and the max(1,...) floor can cause overshoot.  Trim to exactly n.
    unique_indices = sorted(set(indices))
    if len(unique_indices) > n:
        unique_indices = rng.choice(unique_indices, size=n, replace=False).tolist()
        unique_indices.sort()

    return valid.loc[unique_indices].reset_index(drop=True)


# ── Type A query ──────────────────────────────────────────────────────────────

def _query_type_a(
    hyp_df: pd.DataFrame,
    hyp_name: str,
    client: VLLMClient,
    cache: PromptCache,
    system_prompt: str,
) -> pd.DataFrame:
    """Query the LLM for all profiles in a Type A hypothesis.

    Returns a DataFrame with columns: id, hypothesis, p_hat, raw_text, valid,
    retried, system_prompt, user_prompt (full audit trail).
    """
    request_meta: list[dict] = []
    for _, row in hyp_df.iterrows():
        profile_id = row.get("id", row.name)
        user_prompt = render_user_prompt(row, hyp_name)
        request_meta.append({
            "id": profile_id, "hypothesis": hyp_name,
            "system": system_prompt, "user": user_prompt,
        })

    hits, misses = _cache_split(request_meta, cache)

    logger.info("%s: %d cache hits, %d misses to batch.", hyp_name, len(hits), len(misses))

    miss_results = _batch_misses(misses, client, cache) if misses else {}

    records = [hits[i] if i in hits else miss_results[i] for i in range(len(request_meta))]
    return pd.DataFrame(records)


# ── Type B query ──────────────────────────────────────────────────────────────

def _query_type_b(
    source_df: pd.DataFrame,
    b_spec: TypeBSpec,
    client: VLLMClient,
    cache: PromptCache,
    system_prompt: str,
) -> pd.DataFrame:
    """Query the LLM under both conditions for a Type B hypothesis.

    Each profile is queried twice (condition A and condition B) using identical
    profile blocks but different question lines.

    Returns a long-format DataFrame with columns: id, hypothesis, condition,
    p_hat, raw_text, valid, retried, system_prompt, user_prompt.
    """
    request_meta: list[dict] = []
    for _, row in source_df.iterrows():
        profile_id = row.get("id", row.name)
        prompt_a, prompt_b = render_type_b_prompts(row, b_spec.name)
        for condition, user_prompt in [("condition_a", prompt_a), ("condition_b", prompt_b)]:
            request_meta.append({
                "id": profile_id, "hypothesis": b_spec.name,
                "condition": condition,
                "system": system_prompt, "user": user_prompt,
            })

    hits, misses = _cache_split(request_meta, cache)

    logger.info(
        "%s: %d cache hits, %d misses to batch.",
        b_spec.name, len(hits), len(misses),
    )

    miss_results = _batch_misses(misses, client, cache) if misses else {}

    records = [hits[i] if i in hits else miss_results[i] for i in range(len(request_meta))]
    return pd.DataFrame(records)


# ── Cache and batch helpers ───────────────────────────────────────────────────

def _cache_split(
    request_meta: list[dict], cache: PromptCache,
) -> tuple[dict[int, dict], list[dict]]:
    """Split requests into cache hits and misses.

    Returns:
        (hits_dict, misses_list) where hits_dict maps request index to record dict.
    """
    hits: dict[int, dict] = {}
    misses: list[dict] = []
    for i, req in enumerate(request_meta):
        cached = cache.get(req["system"], req["user"])
        if cached is not None:
            hits[i] = {
                **{k: v for k, v in req.items() if k not in ("system", "user")},
                "p_hat": cached.get("p_hat"),
                "raw_text": cached.get("raw_text", ""),
                "valid": cached.get("p_hat") is not None,
                "retried": cached.get("retried", False),
                "system_prompt": req["system"],
                "user_prompt": req["user"],
            }
        else:
            misses.append({"index": i, **req})
    return hits, misses


def _batch_misses(
    misses: list[dict],
    client: VLLMClient,
    cache: PromptCache,
) -> dict[int, dict]:
    """Fire all cache misses concurrently and write results to cache.

    Returns:
        Dict mapping request index to record dict.
    """
    batch = [{"system": m["system"], "user": m["user"], "key": m["index"]} for m in misses]
    raw_results = asyncio.run(client.query_batch_async(batch))
    results: dict[int, dict] = {}
    for r in raw_results:
        orig_index: int = r["key"]
        resp = r["response"]
        req = next(m for m in misses if m["index"] == orig_index)
        cache.set(req["system"], req["user"], resp.p_hat, resp.raw_text, resp.retried)
        results[orig_index] = {
            **{k: v for k, v in req.items() if k not in ("system", "user", "index")},
            "p_hat": resp.p_hat,
            "raw_text": resp.raw_text,
            "valid": resp.valid,
            "retried": resp.retried,
            "system_prompt": req["system"],
            "user_prompt": req["user"],
        }
    return results


# ── Type B analysis ───────────────────────────────────────────────────────────

def _analyse_type_b(
    b_preds: pd.DataFrame,
    source_df: pd.DataFrame,
    b_spec: TypeBSpec,
    tree_cfg: dict[str, Any],
    figures_dir: str,
) -> dict[str, Any]:
    """Compute Type B effect metrics and fit an effect heterogeneity tree.

    The effect heterogeneity tree is a CART regression tree fitted on the
    per-profile effect size δ_k = p_hat(condition_b) − p_hat(condition_a).
    It identifies which profile features modulate sensitivity to the
    experimental manipulation.

    Args:
        b_preds: Long-format predictions with condition column.
        source_df: Source profile DataFrame (for subgroup and feature columns).
        b_spec: Type B hypothesis specification.
        tree_cfg: Tree hyperparameters (max_depth, min_samples_leaf, cv_folds).
        figures_dir: Directory for saving tree figures.

    Returns:
        Dict of Type B analysis results including the effect heterogeneity tree.
    """
    # Pivot to wide: one row per profile, columns for each condition.
    valid = b_preds[b_preds["valid"]].copy()
    wide = valid.pivot_table(index="id", columns="condition", values="p_hat", aggfunc="first")
    if "condition_a" not in wide.columns or "condition_b" not in wide.columns:
        return {"error": "Missing conditions in Type B predictions."}

    wide = wide.dropna(subset=["condition_a", "condition_b"])
    wide["effect"] = (wide["condition_b"] - wide["condition_a"]) * 100  # in pp

    # Merge subgroup columns from source.
    profile_data = source_df.set_index("id")
    wide = wide.join(profile_data, how="left")

    # Global effect.
    mean_effect = float(wide["effect"].mean())
    median_effect = float(wide["effect"].median())
    sd_effect = float(wide["effect"].std())
    n_profiles = len(wide)

    # Direction check.
    share_positive = float((wide["effect"] > 0).mean())

    # Empirical comparison.
    empirical_pp = b_spec.empirical_effect_pp
    ratio = mean_effect / empirical_pp if empirical_pp != 0 else float("nan")

    # Subgroup heterogeneity.
    subgroup_effects: list[dict] = []
    for col, label in UNIVERSAL_SUBGROUP_SPLITS:
        if col not in wide.columns:
            continue
        for level, grp in wide.groupby(col, observed=True):
            if len(grp) < 10:
                continue
            subgroup_effects.append({
                "subgroup_col": col, "subgroup_level": str(level),
                "mean_effect_pp": float(grp["effect"].mean()),
                "n": len(grp),
            })

    # Pre-specified interaction heterogeneity.
    col_a, col_b = b_spec.pre_specified_interaction
    interaction_effects: list[dict] = []
    if col_a in wide.columns and col_b in wide.columns:
        for (la, lb), grp in wide.groupby([col_a, col_b], observed=True):
            if len(grp) < 10:
                continue
            interaction_effects.append({
                col_a: str(la), col_b: str(lb),
                "mean_effect_pp": float(grp["effect"].mean()),
                "n": len(grp),
            })

    # ── Effect heterogeneity tree ─────────────────────────────────────────────
    # Regression tree on δ_k using the prompt feature set for this hypothesis.
    # Identifies which profile features modulate sensitivity to the manipulation.
    prompt_cols = get_prompt_feature_cols(b_spec.name)
    wide_reset = wide.reset_index()
    effect_tree = _fit_effect_heterogeneity_tree(
        wide_reset, prompt_cols, b_spec.name, tree_cfg, figures_dir,
    )

    return {
        "name": b_spec.name,
        "n_profiles": n_profiles,
        "mean_effect_pp": mean_effect,
        "median_effect_pp": median_effect,
        "sd_effect_pp": sd_effect,
        "share_positive": share_positive,
        "empirical_effect_pp": empirical_pp,
        "effect_ratio": ratio,
        "subgroup_effects": pd.DataFrame(subgroup_effects) if subgroup_effects else pd.DataFrame(),
        "interaction_effects": pd.DataFrame(interaction_effects) if interaction_effects else pd.DataFrame(),
        "effect_tree": effect_tree,
    }


# ── Main orchestrator ─────────────────────────────────────────────────────────

def run_phase1(
    prep: PrepResult,
    cfg: dict[str, Any],
) -> dict[str, Any]:
    """Execute the full Phase 1 analysis pipeline.

    Args:
        prep: PrepResult from prepare_canonical().
        cfg: Parsed YAML configuration dict.

    Returns:
        Dict of all analytical results for report generation and artifact persistence.
    """
    Path(cfg["output"]["figures_dir"]).mkdir(parents=True, exist_ok=True)
    Path(cfg["output"]["logs_dir"]).mkdir(parents=True, exist_ok=True)
    Path(cfg["data"]["interim_dir"]).mkdir(parents=True, exist_ok=True)

    system_prompt = get_system_prompt()
    active_hyps = HYPOTHESIS_REGISTRY
    active_b = TYPE_B_REGISTRY

    # ── 1. Sampling ───────────────────────────────────────────────────────────
    hyp_dfs: dict[str, pd.DataFrame] = {}
    for hyp_name, hyp_spec in active_hyps.items():
        source = getattr(prep, hyp_spec.data_key)
        sampled = draw_stratified_sample(
            source, n=cfg["sampling"]["n_main"],
            strat_cols=cfg["sampling"]["strat_cols"],
            random_seed=cfg["sampling"]["random_seed"],
        )
        hyp_dfs[hyp_name] = sampled
        logger.info("%s sample: n=%d (from %d).", hyp_name, len(sampled), len(source))

    # B1 shares the A1 sample.
    for b_name, b_spec in active_b.items():
        if b_spec.data_key == "a1_df" and "A1" in hyp_dfs:
            hyp_dfs[b_name] = hyp_dfs["A1"]
        else:
            source = getattr(prep, b_spec.data_key)
            hyp_dfs[b_name] = draw_stratified_sample(
                source, n=cfg["sampling"]["n_main"],
                strat_cols=cfg["sampling"]["strat_cols"],
                random_seed=cfg["sampling"]["random_seed"],
            )

    # Stability probe: draw from A1.
    stab_strat = cfg["sampling"].get("strat_cols_stability", cfg["sampling"]["strat_cols"])
    usable_stab = [c for c in stab_strat if c in hyp_dfs["A1"].columns]
    stab_df = draw_stratified_sample(
        hyp_dfs["A1"], n=cfg["sampling"]["n_stab"],
        strat_cols=usable_stab,
        random_seed=cfg["sampling"]["random_seed"] + 1,
    )
    logger.info("Stability sample: n=%d.", len(stab_df))

    # ── 2. LLM client and cache ──────────────────────────────────────────────
    client = VLLMClient(
        model=cfg["llm"]["model"],
        temperature_main=cfg["llm"]["temperature_main"],
        temperature_retry=cfg["llm"]["temperature_retry"],
        max_tokens=cfg["llm"]["max_tokens"],
        log_dir=cfg["output"]["logs_dir"],
        tensor_parallel_size=cfg["llm"].get("tensor_parallel_size", 1),
        gpu_memory_utilization=cfg["llm"].get("gpu_memory_utilization", 0.9),
        max_model_len=cfg["llm"].get("max_model_len"),
        trust_remote_code=cfg["llm"].get("trust_remote_code", False),
        enforce_eager=cfg["llm"].get("enforce_eager", False),
        dtype=cfg["llm"].get("dtype", "auto"),
        disable_thinking=cfg["llm"].get("disable_thinking", False),
        max_concurrent=cfg["llm"].get("max_concurrent", 64),
    )
    cache = PromptCache(db_path=cfg["cache"]["db_path"], enabled=cfg["cache"]["enabled"])

    # ── 3a. Type A predictions ───────────────────────────────────────────────
    all_predictions: dict[str, pd.DataFrame] = {}
    merged_dfs: dict[str, pd.DataFrame] = {}

    for hyp_name, hyp_spec in active_hyps.items():
        preds = _query_type_a(hyp_dfs[hyp_name], hyp_name, client, cache, system_prompt)
        all_predictions[hyp_name] = preds

        merged = hyp_dfs[hyp_name].copy()
        preds_indexed = preds.set_index("id")
        merged[f"p_hat_{hyp_name}"] = merged["id"].map(preds_indexed["p_hat"])
        merged_dfs[hyp_name] = merged

    # ── 3b. Type B predictions ───────────────────────────────────────────────
    type_b_results: dict[str, dict] = {}
    for b_name, b_spec in active_b.items():
        logger.info("Running Type B: %s ...", b_name)
        b_preds = _query_type_b(hyp_dfs[b_name], b_spec, client, cache, system_prompt)
        all_predictions[b_name] = b_preds
        type_b_results[b_name] = _analyse_type_b(
            b_preds, hyp_dfs[b_name], b_spec,
            tree_cfg=cfg["trees"], figures_dir=cfg["output"]["figures_dir"],
        )
        logger.info(
            "%s: mean effect=%.1fpp, empirical=%.1fpp, ratio=%.2f",
            b_name,
            type_b_results[b_name].get("mean_effect_pp", float("nan")),
            b_spec.empirical_effect_pp,
            type_b_results[b_name].get("effect_ratio", float("nan")),
        )

    # ── 3c. H_mem — Simulation vs Memorization Probe ────────────────────────
    logger.info("Running H_mem on A1 hypothesis...")
    h_mem_hyp = "A1"
    h_mem_outcome = active_hyps[h_mem_hyp].outcome_col
    h_mem_df = hyp_dfs[h_mem_hyp]

    # Train XGBoost benchmarks and compute conflict scores.
    h_mem_benchmarks = train_benchmark_models(
        h_mem_df, h_mem_outcome, hypothesis=h_mem_hyp,
        random_seed=cfg["sampling"]["random_seed"],
    )

    # Simulation predictions already collected in step 3a.
    sim_preds = merged_dfs[h_mem_hyp].set_index("id")[f"p_hat_{h_mem_hyp}"]

    # Recall predictions: re-query all A1 profiles under recall framing.
    recall_system = get_system_prompt(mode="recall")
    recall_preds_df = _query_type_a(
        h_mem_df, h_mem_hyp, client, cache, recall_system,
    )
    # Tag recall predictions distinctly for audit trail.
    recall_preds_df = recall_preds_df.copy()
    recall_preds_df["hypothesis"] = "H_mem_recall"
    all_predictions["H_mem_recall"] = recall_preds_df
    recall_preds = recall_preds_df.set_index("id")["p_hat"]

    h_mem_results = analyse_h_mem(
        sim_predictions=sim_preds,
        recall_predictions=recall_preds,
        benchmarks=h_mem_benchmarks,
        y_true=h_mem_df.set_index("id")[h_mem_outcome],
    )
    logger.info(
        "H_mem: div_low=%.3f, div_high=%.3f, ratio=%.2f, mode_corr=%.3f",
        h_mem_results["prompt_divergence_low"],
        h_mem_results["prompt_divergence_high"],
        h_mem_results["prompt_divergence_ratio"],
        h_mem_results["mode_correlation"],
    )

    # ── 4. Per-hypothesis metrics (Type A) ───────────────────────────────────
    n_bootstrap = cfg["metrics"].get("n_bootstrap", 2000)
    rng_seed = cfg["sampling"]["random_seed"]
    all_metrics: dict[str, dict] = {}
    all_subgroup_metrics: dict[str, pd.DataFrame] = {}
    all_interaction_metrics: dict[str, pd.DataFrame] = {}

    for hyp_name, hyp_spec in active_hyps.items():
        merged = merged_dfs[hyp_name]
        p_col = f"p_hat_{hyp_name}"
        y_col = hyp_spec.outcome_col

        valid_rows = merged[[y_col, p_col]].dropna()
        y = valid_rows[y_col].to_numpy(float)
        p = valid_rows[p_col].to_numpy(float)

        all_metrics[hyp_name] = compute_all_metrics(
            y, p, n_bins_ece=cfg["metrics"]["ece_bins"],
            min_n=cfg["metrics"]["min_subgroup_n"],
            n_bootstrap=n_bootstrap, rng_seed=rng_seed,
        )

        subgroup_rows = []
        for col, _ in UNIVERSAL_SUBGROUP_SPLITS:
            if col not in merged.columns:
                continue
            sg = compute_subgroup_metrics(
                merged, y_col, p_col, col,
                n_bins_ece=cfg["metrics"]["ece_bins"],
                min_n=cfg["metrics"]["min_subgroup_n"],
                n_bootstrap=n_bootstrap, rng_seed=rng_seed,
            )
            subgroup_rows.append(sg)
        if subgroup_rows:
            all_subgroup_metrics[hyp_name] = pd.concat(subgroup_rows, ignore_index=True)

        col_a, col_b = hyp_spec.pre_specified_interaction
        if col_a in merged.columns and col_b in merged.columns:
            all_interaction_metrics[hyp_name] = compute_interaction_metrics(
                merged, y_col, p_col, col_a, col_b,
                n_bins_ece=cfg["metrics"]["ece_bins"],
                min_n=cfg["metrics"]["min_subgroup_n"],
                n_bootstrap=n_bootstrap, rng_seed=rng_seed,
            )

    # ── 5. Stability probe ───────────────────────────────────────────────────
    logger.info("Running stability probe (H_stability) on A1 subset...")
    stab_hyps = {"A1": active_hyps["A1"]}
    stability_raw = run_stability_probe(
        stab_df=stab_df, active_hypotheses=stab_hyps, client=client,
        n_runs=cfg["stability"]["n_runs"],
        query_interval_seconds=cfg["stability"]["query_interval_seconds"],
        temperature=cfg["stability"]["temperature"],
        render_fn=render_user_prompt, system_prompt=system_prompt,
    )
    stability_metrics = compute_stability_metrics(stability_raw)
    stab_path = Path(cfg["data"]["interim_dir"]) / "stability_raw.parquet"
    stability_raw.to_parquet(str(stab_path), index=False)

    # ── 6. Decision trees ────────────────────────────────────────────────────
    tree_cfg = cfg["trees"]
    figures_dir = cfg["output"]["figures_dir"]
    residual_trees: dict[str, Any] = {}
    implicit_trees: dict[str, Any] = {}
    outcome_trees: dict[str, Any] = {}
    residual_col_map: dict[str, str] = {}

    for hyp_name, hyp_spec in active_hyps.items():
        merged = merged_dfs[hyp_name]
        p_col = f"p_hat_{hyp_name}"
        y_col = hyp_spec.outcome_col
        r_col = f"residual_{hyp_name}"
        merged[r_col] = merged[p_col] - merged[y_col].astype(float)
        residual_col_map[hyp_name] = r_col
        merged_dfs[hyp_name] = merged

        prompt_cols = get_prompt_feature_cols(hyp_name)
        residual_trees[hyp_name] = fit_residual_tree(
            merged, y_col, p_col, prompt_cols, hyp_name, tree_cfg, figures_dir,
        )
        implicit_trees[hyp_name] = fit_implicit_decision_tree(
            merged, p_col, prompt_cols, hyp_name, tree_cfg, figures_dir,
        )
        outcome_trees[hyp_name] = fit_outcome_tree(
            merged, y_col, prompt_cols, hyp_name, tree_cfg, figures_dir,
        )

    # Cross-hypothesis error tree.
    cross_df = _build_cross_hypothesis_frame(merged_dfs, active_hyps)
    cross_residual_cols = {h: f"residual_{h}" for h in active_hyps if f"residual_{h}" in cross_df.columns}
    all_prompt_cols = list({
        col for h in active_hyps for col in get_prompt_feature_cols(h)
    })
    cross_error_tree = fit_cross_hypothesis_error_tree(
        cross_df, cross_residual_cols, all_prompt_cols, tree_cfg, figures_dir,
    ) if len(cross_residual_cols) >= 2 else None

    # ── 7. Cross-hypothesis consistency ──────────────────────────────────────
    logger.info("Computing cross-hypothesis consistency...")
    consistency_results = _compute_pairwise_consistency(
        merged_dfs, active_hyps, cfg["consistency"],
    )

    cache.close()

    # ── 8. Save audit trail ──────────────────────────────────────────────────
    audit_frames = []
    for name, pred_df in all_predictions.items():
        audit_frames.append(pred_df)
    if audit_frames:
        audit_df = pd.concat(audit_frames, ignore_index=True)
        audit_path = Path(cfg["data"]["interim_dir"]) / "prompt_audit_trail.parquet"
        audit_df.to_parquet(str(audit_path), index=False)
        logger.info("Prompt audit trail saved → %s (%d records)", audit_path, len(audit_df))

    results: dict[str, Any] = {
        "year": 2024,
        "year_tag": "2024",
        "active_hypotheses": list(active_hyps.keys()),
        "active_type_b": list(active_b.keys()),
        "sample_sizes": {h: len(df) for h, df in hyp_dfs.items()},
        "n_stab": len(stab_df),
        "metrics": all_metrics,
        "subgroup_metrics": all_subgroup_metrics,
        "interaction_metrics": all_interaction_metrics,
        "type_b_results": type_b_results,
        "h_mem_results": h_mem_results,
        "h_mem_benchmarks": h_mem_benchmarks,
        "stability_metrics": stability_metrics,
        "stability_raw": stability_raw,
        "residual_trees": residual_trees,
        "implicit_trees": implicit_trees,
        "outcome_trees": outcome_trees,
        "cross_error_tree": cross_error_tree,
        "consistency": consistency_results,
        "merged_dfs": merged_dfs,
        "parse_failures": client.parse_failure_count,
    }

    save_artifacts(results, cfg["data"]["interim_dir"])
    return results


# ── Internal helpers ──────────────────────────────────────────────────────────

def _build_cross_hypothesis_frame(
    merged_dfs: dict[str, pd.DataFrame],
    active_hyps: dict[str, HypothesisSpec],
) -> pd.DataFrame:
    """Merge per-hypothesis residuals into a single frame joined on respondent ID.

    Only respondents present in >=2 hypothesis DataFrames are retained.
    Feature columns are carried from whichever hypothesis DataFrame contains
    each respondent (using the first available value per ID when frames overlap).
    """
    # Collect residual/prediction columns per hypothesis.
    residual_frames: list[pd.DataFrame] = []
    for hyp_name, hyp_spec in active_hyps.items():
        df = merged_dfs[hyp_name]
        r_col = f"residual_{hyp_name}"
        p_col = f"p_hat_{hyp_name}"
        cols = ["id"] + [c for c in [r_col, p_col, hyp_spec.outcome_col] if c in df.columns]
        residual_frames.append(df[cols].set_index("id"))

    combined = residual_frames[0].join(residual_frames[1:], how="outer")

    # Carry feature columns: collect from all hypothesis DataFrames, using the
    # first non-NaN value per ID for each column (handles ballot splits).
    all_feature_cols: set[str] = set()
    for df in merged_dfs.values():
        all_feature_cols.update(c for c in df.columns if c not in combined.columns and c != "id")

    for col in sorted(all_feature_cols):
        series_parts = []
        for df in merged_dfs.values():
            if col in df.columns:
                series_parts.append(df.set_index("id")[col])
        if series_parts:
            merged_col = series_parts[0]
            for s in series_parts[1:]:
                merged_col = merged_col.combine_first(s)
            combined[col] = merged_col

    combined = combined.reset_index()

    # Keep only respondents with >= 2 residual columns non-NaN.
    residual_cols = [f"residual_{h}" for h in active_hyps if f"residual_{h}" in combined.columns]
    n_valid = combined[residual_cols].notna().sum(axis=1)
    return combined[n_valid >= 2].reset_index(drop=True)


def _fit_effect_heterogeneity_tree(
    wide_df: pd.DataFrame,
    prompt_feature_cols: list[str],
    hypothesis: str,
    tree_cfg: dict[str, Any],
    figures_dir: str,
) -> Any:
    """Fit a regression tree on the per-profile effect size δ_k.

    Identifies which profile features modulate sensitivity to the
    experimental manipulation. The two leaves of primary interest are the
    largest-effect leaf (most sensitive profiles) and the smallest/negative
    leaf (least sensitive or reversed).

    Args:
        wide_df: DataFrame with an 'effect' column (pp) and profile features.
        prompt_feature_cols: Feature columns visible to the LLM for this hypothesis.
        hypothesis: Hypothesis name for labelling.
        tree_cfg: Tree hyperparameters (max_depth, min_samples_leaf, cv_folds).
        figures_dir: Directory for saving tree figures.

    Returns:
        TreeResult from trees.py, or None if insufficient data.
    """
    from ..phase1.trees import (
        TreeResult,
        _encode_categoricals,
        _fit_regression_tree,
        _leaf_summary,
        _save_figure,
    )

    if "effect" not in wide_df.columns:
        return None

    sub = wide_df[["effect"] + [c for c in prompt_feature_cols if c in wide_df.columns]].dropna()
    if len(sub) < tree_cfg["min_samples_leaf"] * 2:
        logger.warning("Insufficient data for effect heterogeneity tree (%s).", hypothesis)
        return None

    target = sub["effect"].to_numpy(float)
    feature_cols = [c for c in prompt_feature_cols if c in sub.columns]
    X, names = _encode_categoricals(sub, feature_cols)
    valid_mask = ~np.isnan(X).any(axis=1) & ~np.isnan(target)
    X, target = X[valid_mask], target[valid_mask]

    tree = _fit_regression_tree(
        X, target, names,
        tree_cfg["max_depth"], tree_cfg["min_samples_leaf"], tree_cfg["cv_folds"],
    )
    summary, worst_rule, worst_mean, worst_n = _leaf_summary(tree, X, target, names, False)
    importance = pd.Series(tree.feature_importances_, index=names).sort_values(ascending=False)

    fig_path = f"{figures_dir}/tree_effect_heterogeneity_{hypothesis}.png"
    _save_figure(tree, names, f"Effect Heterogeneity Tree — {hypothesis}", fig_path)

    return TreeResult(
        tree_type="effect_heterogeneity", hypothesis=hypothesis,
        n_samples=len(X), n_leaves=tree.get_n_leaves(),
        worst_leaf_rule=worst_rule, worst_leaf_mean=worst_mean, worst_leaf_n=worst_n,
        leaf_summary=summary, feature_importance=importance,
        figure_path=fig_path, fitted_tree=tree,
    )


def _compute_pairwise_consistency(
    merged_dfs: dict[str, pd.DataFrame],
    active_hyps: dict[str, HypothesisSpec],
    consistency_cfg: dict[str, Any],
) -> dict[str, Any]:
    """Compute cross-hypothesis consistency on ballot-overlapping respondent pairs."""
    pairs: list[dict] = []
    for h_a, h_b in [("A1", "A2"), ("A1", "A3")]:
        result = _pair_consistency(merged_dfs, active_hyps, h_a, h_b, consistency_cfg)
        if result is not None:
            pairs.append(result)
    return {"pairs": pairs, "note": "A2-A3 pair not feasible (no shared ballot)."}


def _pair_consistency(
    merged_dfs: dict[str, pd.DataFrame],
    active_hyps: dict[str, HypothesisSpec],
    h_a: str, h_b: str,
    consistency_cfg: dict[str, Any],
) -> dict[str, Any] | None:
    """Compute consistency metrics for a single hypothesis pair."""
    df_a = merged_dfs[h_a].set_index("id")
    df_b = merged_dfs[h_b].set_index("id")
    shared_ids = df_a.index.intersection(df_b.index)
    if len(shared_ids) < 30:
        logger.warning("Pair %s-%s: only %d shared, skipping.", h_a, h_b, len(shared_ids))
        return None

    pred_wide = pd.DataFrame({
        h_a: df_a.loc[shared_ids, f"p_hat_{h_a}"],
        h_b: df_b.loc[shared_ids, f"p_hat_{h_b}"],
    })
    out_wide = pd.DataFrame({
        h_a: df_a.loc[shared_ids, active_hyps[h_a].outcome_col].astype(float),
        h_b: df_b.loc[shared_ids, active_hyps[h_b].outcome_col].astype(float),
    })

    result = compute_consistency(
        pred_wide, out_wide,
        over_clustering_threshold=consistency_cfg["over_clustering_threshold"],
        independence_failure_threshold=consistency_cfg["independence_failure_threshold"],
        top_n_pairs=consistency_cfg["top_n_divergent_pairs"],
        inconsistency_flag_quantile=consistency_cfg["inconsistency_flag_quantile"],
    )
    result["pair"] = f"{h_a}-{h_b}"
    result["n_shared"] = len(shared_ids)
    return result
