"""
GSS 2024 data preparation.

Reads the raw interim parquet produced by ingest.py, constructs all derived
variables (bins, capability index, overconfidence flag, binary outcomes), and
writes three ballot-specific canonical parquets — one per hypothesis subset.

The 2024 GSS uses a three-ballot split rotation:
    Ballot 1 (WORDSUM + NOTSMART):  can run A1, A2
    Ballot 2 (WORDSUM + CONFINAN):  can run A1, A3
    Ballot 3 (NOTSMART + CONFINAN): can run A3 only

No missing-code inference is required: pyreadstat converts all STATA
extended missing values (.i, .n, .d, .r, .s) to NaN on read.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


@dataclass
class PrepResult:
    """Container for the three ballot-specific canonical DataFrames."""

    # Per-hypothesis DataFrames (rows with complete features + outcome).
    a1_df: pd.DataFrame
    a2_df: pd.DataFrame
    a3_df: pd.DataFrame

    # Full canonical frame (union of all rows; per-hypothesis columns may be NaN).
    full_df: pd.DataFrame

    # Ballot membership for each row in full_df.
    ballot_col: str = "ballot"

    # Paths to saved parquet files.
    paths: dict[str, str] = field(default_factory=dict)


# ── Derived-variable builders ─────────────────────────────────────────────────

def _make_age_bin(age: pd.Series) -> pd.Categorical:
    """Bin continuous age into three analysis groups."""
    return pd.cut(age, bins=[0, 39, 59, 200], labels=["<40", "40-59", "60+"], right=True)


def _make_income_tert(income: pd.Series) -> pd.Categorical:
    """Assign income tertiles (single wave, no cross-wave confound)."""
    valid = income.dropna()
    if len(valid) < 3:
        return pd.Series(pd.NA, index=income.index, dtype="category")
    return pd.qcut(income, q=3, labels=["low", "mid", "high"], duplicates="drop")


def _make_educ_bin(educ_years: pd.Series, degree: pd.Series | None) -> pd.Categorical:
    """Map education to three bins, falling back per-row from DEGREE to EDUC years.

    Uses DEGREE (0=LT HS, 1=HS, 2=JC, 3=BA, 4=Grad) where available.
    For rows where DEGREE is missing, falls back to EDUC years (<12 / 12-15 / 16+).
    """
    degree_map = {0: "low", 1: "mid", 2: "mid", 3: "university", 4: "university"}
    educ_bins = pd.cut(
        educ_years, bins=[0, 11, 15, 99],
        labels=["low", "mid", "university"], right=True,
    )
    if degree is not None and degree.notna().any():
        from_degree = degree.map(degree_map)
        return from_degree.where(from_degree.notna(), educ_bins).astype("category")
    return educ_bins


def _make_capability_bin(wordsum: pd.Series) -> pd.Categorical:
    """Split WORDSUM at the median into below/above capability bins."""
    median = wordsum.median()
    return pd.Categorical(
        np.where(wordsum < median, "below_median", "above_median"),
        categories=["below_median", "above_median"],
    )


def _make_confidence_bin(notsmart: pd.Series) -> pd.Categorical:
    """Map NOTSMART frequency to a confidence level.

    NOTSMART: 1=almost every day … 6=never (frequency of feeling 'not smart
    enough for financial matters'). Higher values mean more confident.
    """
    return pd.cut(
        notsmart, bins=[0, 2, 4, 6],
        labels=["low", "mid", "high"], right=True,
    )


def _make_overconfident_flag(
    notsmart: pd.Series, wordsum: pd.Series,
) -> pd.Series:
    """Flag respondents who are confident (NOTSMART 5-6) but low-capability.

    Returns integer Series: 1 = overconfident, 0 = not.
    """
    median = wordsum.median()
    confident = notsmart >= 5
    low_cap = wordsum < median
    flag = (confident & low_cap).astype("Int64")
    flag[notsmart.isna() | wordsum.isna()] = pd.NA
    return flag


def _make_confinan_level(confinan: pd.Series) -> pd.Categorical:
    """Map CONFINAN (1=great deal, 2=only some, 3=hardly any) to levels."""
    return confinan.map({1: "high", 2: "mid", 3: "low"}).astype("category")


def _make_y_dwelown(dwelown: pd.Series) -> pd.Series:
    """Binarise DWELOWN: 1=own/buying, 0=rents or other."""
    return dwelown.map({1: 1, 2: 0, 3: 0}).astype("Int64")


def _make_y_satfin(satfin: pd.Series) -> pd.Series:
    """Binarise SATFIN: 1=pretty well satisfied, 0=more-or-less / not at all."""
    return satfin.map({1: 1, 2: 0, 3: 0}).astype("Int64")


def _make_y_class(cls: pd.Series) -> pd.Series:
    """Binarise CLASS: 1=middle/upper, 0=lower/working. Code 5 (no class) → NaN."""
    return cls.map({1: 0, 2: 0, 3: 1, 4: 1}).astype("Int64")


# ── Main preparation function ────────────────────────────────────────────────

def prepare_canonical(
    parquet_path: str,
    interim_dir: str,
) -> PrepResult:
    """Build canonical analysis-ready DataFrames from the raw interim parquet.

    Steps:
        1. Construct universal axis bins.
        2. Construct capability, confidence, trust, and overconfidence variables.
        3. Binarise outcome variables.
        4. Partition into per-hypothesis DataFrames by ballot availability.
        5. Write canonical parquets.

    Args:
        parquet_path: Path to the raw interim parquet from ingest().
        interim_dir: Output directory for the canonical parquets.

    Returns:
        PrepResult with per-hypothesis DataFrames and file paths.
    """
    df = pd.read_parquet(parquet_path)

    # ── 1. Universal axes ────────────────────────────────────────────────────
    out = pd.DataFrame(index=df.index)
    out["id"] = df["id"]
    out["ballot"] = df["ballot"].astype("Int64") if "ballot" in df.columns else pd.NA
    out["age"] = df["age"]
    out["sex"] = df["sex"]
    out["educ_years"] = df["educ"]
    out["degree"] = df["degree"] if "degree" in df.columns else None
    out["income"] = df["realinc"]

    out["age_bin"] = _make_age_bin(out["age"])
    out["income_tert"] = _make_income_tert(out["income"])
    out["educ_bin"] = _make_educ_bin(
        out["educ_years"], df["degree"] if "degree" in df.columns else None,
    )
    out["gender_bin"] = df["sex"].map({1: "male", 2: "female"}).astype("category")

    # ── 2. Capability / confidence / trust ───────────────────────────────────
    if "wordsum" in df.columns:
        out["wordsum"] = df["wordsum"]
        mask_ws = df["wordsum"].notna()
        if mask_ws.any():
            cap_full = pd.Series(pd.NA, index=df.index, dtype="object")
            cap_values = _make_capability_bin(df.loc[mask_ws, "wordsum"])
            cap_full.loc[mask_ws] = cap_values.astype(str)
            out["capability_bin"] = cap_full.astype("category")
        else:
            out["capability_bin"] = pd.Series(pd.NA, index=df.index, dtype="category")
    else:
        out["wordsum"] = np.nan
        out["capability_bin"] = pd.Series(pd.NA, index=df.index, dtype="category")

    if "notsmart" in df.columns:
        out["notsmart"] = df["notsmart"]
        mask_ns = df["notsmart"].notna()
        if mask_ns.any():
            conf_full = pd.Series(pd.NA, index=df.index, dtype="object")
            conf_values = _make_confidence_bin(df.loc[mask_ns, "notsmart"])
            conf_full.loc[mask_ns] = conf_values.astype(str)
            out["confidence_level"] = conf_full.astype("category")
        else:
            out["confidence_level"] = pd.Series(pd.NA, index=df.index, dtype="category")
    else:
        out["notsmart"] = np.nan
        out["confidence_level"] = pd.Series(pd.NA, index=df.index, dtype="category")

    if "wordsum" in df.columns and "notsmart" in df.columns:
        out["overconfident_flag"] = _make_overconfident_flag(df["notsmart"], df["wordsum"])
    else:
        out["overconfident_flag"] = pd.NA

    if "confinan" in df.columns:
        out["confinan"] = df["confinan"]
        out["confinan_level"] = _make_confinan_level(df["confinan"])
    else:
        out["confinan"] = np.nan
        out["confinan_level"] = pd.NA

    # ── 3. Outcomes ──────────────────────────────────────────────────────────
    out["y_dwelown"] = _make_y_dwelown(df["dwelown"]) if "dwelown" in df.columns else pd.NA
    out["y_satfin"] = _make_y_satfin(df["satfin"]) if "satfin" in df.columns else pd.NA
    out["y_class"] = _make_y_class(df["class"]) if "class" in df.columns else pd.NA

    # ── 4. Outcome-tree passthrough columns ──────────────────────────────────
    for col in ["race", "marital", "wrkstat", "region", "relig", "partyid", "polviews"]:
        if col in df.columns:
            out[col] = df[col]

    # ── 5. Type B empirical benchmarks (NATFARE/NATFAREY) ──────────────────
    for col in ["natfare", "natfarey"]:
        if col in df.columns:
            out[col] = df[col]

    # ── 6. Survey-design columns ─────────────────────────────────────────────
    for col in ["wtssnrps", "wtssps", "vstrat", "vpsu"]:
        if col in df.columns:
            out[col] = df[col]

    # ── 6. Partition by hypothesis requirements ──────────────────────────────
    # Restrict each hypothesis frame to complete cases on the exact aligned
    # feature set used downstream by prompt rendering, hypothesis-specific
    # trees, and the full XGBoost benchmark. This guarantees that every sampled
    # profile exposes the same information that the associated models receive.
    from ..llm.prompts import get_prompt_feature_cols

    def _complete_case_mask(feature_cols: list[str], outcome_col: str) -> pd.Series:
        required = [c for c in feature_cols + [outcome_col] if c in out.columns]
        return out[required].notna().all(axis=1)

    mask_a1 = _complete_case_mask(get_prompt_feature_cols("A1"), "y_dwelown")
    a1_df = out.loc[mask_a1].reset_index(drop=True)

    mask_a2 = _complete_case_mask(get_prompt_feature_cols("A2"), "y_satfin")
    a2_df = out.loc[mask_a2].reset_index(drop=True)

    mask_a3 = _complete_case_mask(get_prompt_feature_cols("A3"), "y_class")
    a3_df = out.loc[mask_a3].reset_index(drop=True)

    logger.info(
        "Canonical frames: A1 n=%d, A2 n=%d, A3 n=%d, full n=%d",
        len(a1_df), len(a2_df), len(a3_df), len(out),
    )

    # ── 7. Write ─────────────────────────────────────────────────────────────
    paths: dict[str, str] = {}
    for tag, frame in [("A1", a1_df), ("A2", a2_df), ("A3", a3_df), ("full", out)]:
        p = Path(interim_dir) / f"gss_2024_{tag}.parquet"
        frame.to_parquet(str(p), index=False)
        paths[tag] = str(p)

    return PrepResult(a1_df=a1_df, a2_df=a2_df, a3_df=a3_df, full_df=out, paths=paths)
