"""
GSS 2024 STATA data ingestion.

Reads the .dta file via pyreadstat and writes a column-pruned parquet for
downstream processing. STATA extended missing codes (.i, .n, .d, .r, .s)
are converted to NaN automatically by pyreadstat.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import pandas as pd
import pyreadstat

logger = logging.getLogger(__name__)

# Columns extracted from the .dta file.
_UNIVERSAL = ["year", "id", "age", "sex", "educ", "degree", "realinc"]
_CAPABILITY = ["wordsum", "notsmart"]
_TRUST = ["confinan"]
_OUTCOMES = ["satfin", "dwelown", "class"]
_TYPE_B_EMPIRICAL = ["natfare", "natfarey"]
_DESIGN = ["ballot", "form", "wtssnrps", "wtssps", "vstrat", "vpsu"]
_OUTCOME_TREE_EXTRAS = [
    "race", "marital", "wrkstat", "region",
    "relig", "partyid", "polviews",
]


def ingest(stata_path: str, interim_dir: str) -> str:
    """Read the GSS 2024 STATA file and write a column-pruned parquet.

    Args:
        stata_path: Path to the GSS2024.dta file.
        interim_dir: Directory for the output parquet file.

    Returns:
        Path to the written parquet file.
    """
    Path(interim_dir).mkdir(parents=True, exist_ok=True)
    out_path = Path(interim_dir) / "gss_2024_raw.parquet"

    wanted = set(
        _UNIVERSAL + _CAPABILITY + _TRUST + _OUTCOMES + _TYPE_B_EMPIRICAL
        + _DESIGN + _OUTCOME_TREE_EXTRAS
    )
    df, meta = pyreadstat.read_dta(stata_path)
    # STATA files have lowercase column names; normalise to lowercase.
    df.columns = df.columns.str.lower()
    available = [c for c in wanted if c in df.columns]
    missing = wanted - set(available)
    if missing:
        logger.warning("Columns not found in .dta: %s", sorted(missing))

    df = df[available].copy()
    df.to_parquet(str(out_path), index=False)
    logger.info(
        "Ingested GSS 2024 STATA → %s  (%d rows, %d cols)",
        out_path, len(df), len(available),
    )
    return str(out_path)
